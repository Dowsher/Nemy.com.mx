plugins {
    id("com.android.library") version "9.5.0" apply false
    id("com.android.application") version "9.5.0" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.21" apply false
}
