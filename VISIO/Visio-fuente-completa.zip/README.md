# Visio · ecosistema Nemy

Aplicaciones Android y Wear OS para registrar señales, explorar el historial, etiquetar consumos y corregir falsos positivos. Incluye firmware ESP32-S3 para activar un LED ante nuevas detecciones experimentales. Datos locales y enlaces Bluetooth.

## Contenido

| Carpeta | Contenido |
| --- | --- |
| `phone/` | Código de Visio Mobile 0.4.1-pilot |
| `app/` | Código de Visio Wear 0.3.0-pilot |
| `core/` | Protocolos, señales, ventanas de registro y reglas compartidas |
| `esp32s3-led/` | Código de VisioLED 0.1.0, ESP-IDF 5.5.2 |
| `firmware/VisioLED-XIAO/` | Binarios de la placa XIAO ESP32-S3, flash de 8 MB |
| `scripts/` y `tools/` | Compilación, conexión, descarga y análisis |

Las gráficas permiten zoom, recorrido temporal, selección de puntos y marcas de consumos confirmados. El historial incluye promedios por minuto, lecturas retenidas y mediciones manuales de 30 segundos. El modo compacto conserva resúmenes y segmentos relevantes. La interfaz usa tema oscuro, verde y gris.

Guía: [APP-TELEFONO.md](APP-TELEFONO.md). Estado: [ESTADO.md](ESTADO.md). Firmware: [esp32s3-led/README.md](esp32s3-led/README.md).

## Compilar Android

Usar Android Studio, su JDK 21, Android SDK Platform 37, Build-Tools 36 y Platform-Tools. El wrapper fija Gradle y las dependencias del proyecto. `scripts/entorno.ps1` configura JDK/SDK solo para la consola actual.

```powershell
. .\scripts\entorno.ps1
.\gradlew.bat :phone:assembleDebug :app:assembleDebug
```

APK generadas: `phone/build/outputs/apk/debug/phone-debug.apk` y `app/build/outputs/apk/debug/app-debug.apk`.

El Samsung Health Sensor SDK 1.4.1 está en `app/libs/` en esta copia local y **está excluido de Git**. Al clonar el repositorio en otra computadora, descargarlo desde el [portal oficial de Samsung](https://developer.samsung.com/health/sensor/overview.html), aceptar sus términos y colocar un único `.aar` en esa carpeta. Consultar `SDK-PROVENIENCIA.txt`. Sin ese SDK se puede compilar la variante de movimiento con `-PmotionOnly=true`, que no incluye los sensores de salud Samsung.

Para los sensores Samsung, el reloj necesita Health Sensor Service y su modo de desarrollador habilitado. Esta entrega es un piloto; distribuir con ese SDK requiere atender sus condiciones. No se incluye código del ejemplo propietario de Samsung.

## Código y distribución

Esta copia se publica como parte del repositorio de Nemy. Incluye código, documentación y firmware; excluye APK, datos personales, credenciales, claves privadas y el SDK propietario de Samsung. `ENTREGA.json` conserva metadatos históricos de los dispositivos y la entrega original. No se ha asignado una licencia de código abierto.

## Límites del piloto

Las alertas usan reglas experimentales, no un modelo entrenado ni un diagnóstico. No prueban que hubo consumo. Las correcciones se conservan para entrenamiento posterior. El pulso/IBI requieren contacto y calidad válida; EDA no estuvo disponible en el reloj utilizado. La prueba completa de gesto real → alerta → LED y las pruebas largas quedan a cargo del usuario.
