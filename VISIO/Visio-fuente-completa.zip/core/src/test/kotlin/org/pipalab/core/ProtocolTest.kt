package org.pipalab.core
import org.junit.Assert.*
import org.junit.Test

class ProtocolTest {
    @Test fun csvRoundTripsQuotedMultilineSensorFields() {
        val values=listOf("123","1,2","\"texto\"","dos\nlíneas","","[800,810]")
        assertEquals(listOf(values,values),Csv.rows((Csv.line(values)+"\r\n"+Csv.line(values)+"\n").reader()).toList())
    }
    @Test fun csvRejectsTruncatedQuotedRow() {
        assertThrows(IllegalArgumentException::class.java){Csv.rows("a,\"unfinished".reader()).toList()}
    }
    @Test fun fragmentationWorksForSmallAndLargeMtu() {
        val data=ByteArray(100_003){(it%251).toByte()}
        for(mtu in listOf(23,247,517)) {
            val a=LocalProtocol.Assembler(); var result:ByteArray?=null
            for(p in LocalProtocol.packets(data,mtu)) { assertTrue(p.size<=mtu-3); a.accept(p)?.let{result=it} }
            assertArrayEquals(data,result)
        }
    }
    @Test fun untrustedLengthIsRejected() {
        assertThrows(IllegalArgumentException::class.java){LocalProtocol.Assembler().accept(byteArrayOf(1,127,127,127,127))}
    }
    @Test fun mutualAuthenticationRejectsDifferentKey() {
        val key=LocalProtocol.random(); val c=LocalProtocol.random(); val s=LocalProtocol.random()
        assertArrayEquals(c,LocalProtocol.verifyHello(key,LocalProtocol.hello(key,c)))
        assertArrayEquals(s,LocalProtocol.verifyReply(key,c,LocalProtocol.reply(key,c,s)))
        assertThrows(IllegalArgumentException::class.java){LocalProtocol.verifyHello(LocalProtocol.random(),LocalProtocol.hello(key,c))}
    }
    @Test fun encryptedExchangeRejectsTamperReplayAndReconnectReplay() {
        val key=LocalProtocol.random(); val c=LocalProtocol.random(); val s=LocalProtocol.random()
        val phone=SecureSession(key,c,s,true); val watch=SecureSession(key,c,s,false)
        val packet=phone.encrypt("datos confidenciales, \n[1,2,3]")
        assertFalse(packet.toString(Charsets.UTF_8).contains("confidenciales"))
        assertEquals("datos confidenciales, \n[1,2,3]",watch.decrypt(packet))
        assertThrows(IllegalArgumentException::class.java){watch.decrypt(packet)}
        assertEquals("reply",phone.decrypt(watch.encrypt("reply")))
        val damaged=phone.encrypt("next").also{it[it.lastIndex]=(it.last().toInt() xor 1).toByte()}
        assertThrows(Exception::class.java){watch.decrypt(damaged)}
        assertEquals("after tamper",watch.decrypt(phone.encrypt("after tamper")))
        val newWatch=SecureSession(key,LocalProtocol.random(),s,false)
        assertThrows(Exception::class.java){newWatch.decrypt(phone.encrypt("old session"))}
    }
    @Test fun stationarySignalsDoNotTriggerAndTwoHeldRaisesDo() {
        val d=GestureDetector(); var t=1_000_000_000L; val alerts=mutableListOf<GestureDetector.Candidate>()
        fun feed(seconds:Int,angle:Double,gyro:Double) {
            repeat(seconds*50) { t+=20_000_000; d.gyro(t,gyro,0.0,0.0)
                d.accel(t,9.81*kotlin.math.sin(angle),0.0,9.81*kotlin.math.cos(angle))?.let{alerts.add(it)} }
        }
        assertEquals(-1,d.stage(t))
        feed(60,0.0,0.0); assertTrue(d.calibrated()); assertTrue(alerts.isEmpty());assertEquals(0,d.stage(t))
        repeat(2) { feed(1,1.2,.8);assertEquals(1,d.stage(t));feed(3,1.2,0.0);feed(1,0.0,.8);feed(3,0.0,0.0) }
        assertEquals(1,alerts.size); assertEquals(2,alerts.single().gestures)
        assertEquals(2,d.stage(t));assertEquals(-1,d.stage(t+11_000_000_000L))
        repeat(2) { feed(1,1.2,.8);feed(3,1.2,0.0);feed(1,0.0,.8);feed(3,0.0,0.0) }
        assertEquals("Cooldown prevents duplicate prompts",1,alerts.size)
    }
}
