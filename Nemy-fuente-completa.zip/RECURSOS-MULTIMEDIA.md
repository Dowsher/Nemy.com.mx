# Recursos de video

Los MP4 se alojan en Nemy y se omiten del paquete para mantener ligero el repositorio. Para probarlos localmente, coloca archivos compatibles en `public/media/` con estos nombres:

- `nemy-recaidas.mp4`: episodio 01 sobre recaídas.
- `nemy-pasajero-conductor.mp4`: episodio 02.
- `nemy-anestesia-emocional.mp4`: episodio 03.

Las imágenes de portada están incluidas. El sitio publicado sirve los videos desde Nemy, sin depender de GitHub para la reproducción.
