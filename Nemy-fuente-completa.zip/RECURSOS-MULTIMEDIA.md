# Recursos de video

El código de Nemy usa dos videos que se sirven desde la plataforma publicada. Los MP4 se omiten de este paquete de fuente para mantener el repositorio ligero.

Para probarlos en una instalación local, coloca archivos MP4 compatibles en `public/media/` con estos nombres:

- `nemy-recaidas.mp4`: episodio 01 sobre recaídas.
- `nemy-pasajero-conductor.mp4`: episodio 02, El pasajero y el conductor.

Las imágenes de portada sí están incluidas. En producción, los videos se sirven desde Nemy; el sitio no depende de GitHub para reproducirlos.
