# DTR-GA v2 — Régimen dinámico de tratamiento personalizado para trastorno por uso de metanfetamina

Optimizador evolutivo multiobjetivo (NSGA-II) de **Regímenes Dinámicos de Tratamiento** (DTR) sobre un
**simulador estadístico calibrado con ensayos clínicos**, con un **motor clínico determinista** que impone
contraindicaciones, triaje y componentes obligatorios. Entrada: un perfil clínico, conductual y de entorno
del sujeto. Salida: el conjunto mínimo de elementos que el sujeto requiere, en qué etapa y bajo qué regla
de decisión, con resultados esperados, incertidumbre y análisis de necesidad de cada componente.

> Herramienta de **apoyo a la decisión para revisión clínica**. No es una prescripción ni un dispositivo
> médico validado. Toda decisión requiere evaluación presencial, consentimiento informado y juicio del equipo tratante.

## Uso rápido

```bash
pip install numpy matplotlib          # matplotlib es opcional (gráfica)
python dtr_main.py --autoprueba        # 38 pruebas de integridad (~10 s)
python dtr_main.py --plantilla perfil.json    # plantilla documentada de entrada
python dtr_main.py ejemplos/caso_A_complejo.json            # corrida completa (~2 min)
python dtr_main.py ejemplos/caso_A_complejo.json --rapido   # iteración rápida (~20 s)
```

Opciones: `--salida DIR`, `--generaciones N` (120), `--poblacion N` (96), `--semilla S`,
`--modo-investigacion` (habilita fármacos con evidencia nula), `--ignorar-interlock` (solo investigación),
`--recalibrar` (ignora la caché `calibracion_cache.json`; tarda ~1 min).

Salida en `resultados_<id>/`: `plan_<id>.md` (reporte clínico), `plan_<id>.json` (todo, para integrar con
otra app) y `curvas_abstinencia.png`. Con alertas urgentes (riesgo suicida alto, psicosis activa, síntomas
cardiacos agudos) el sistema **no genera plan ambulatorio**: escribe `interlock_<id>.md` y sale con código 2.

## Arquitectura

| Capa | Archivo | Qué hace |
|---|---|---|
| 0 | `dtr_base.py` | Diseño temporal, base de evidencia (17 componentes con OR, IC95, grado, costos, horas, EA), esquema del perfil (68 campos) |
| 1 | `dtr_clinico.py` | Motor clínico determinista: contraindicaciones de ficha técnica, interlock, obligatorios (reducción de daños, tamizajes), severidad por dimensión e índice de nivel de atención (inspirado en ASAM 4ª ed.), priors de riesgo personalizados |
| 2 | `dtr_calibracion.py` | Calibración por emulación de ensayos: intercepto y dependencia de estado ← ADAPT-2 placebo + recaída post-tratamiento; heterogeneidad entre personas ← verosimilitud de ADAPT-2 etapa 2; cada OR publicada → efecto semanal condicional. Promedio de 7 modelos ponderado por verosimilitud |
| 3 | `dtr_simulador.py` | Gemelo estadístico del sujeto: Monte Carlo semanal (36 semanas) con ramas adaptativas, abandono, suspensión por EA, eventos graves, costo y horas. Estimadores Rao-Blackwell |
| 4 | `dtr_optimizador.py` | NSGA-II (3 objetivos) con reparación de restricciones + búsqueda local memética |
| 5 | `dtr_analisis.py` | Re-evaluación fuera de muestra (40 000 trayectorias/régimen), régimen mínimo suficiente, ablación, adición, sensibilidad, robustez estructural |
| 6 | `dtr_reporte.py` | Reporte Markdown + JSON + gráfica |

### El régimen (genoma)

Siete paquetes: etapa 1 (semanas 1-6) y, para etapas 2-4, un paquete si el sujeto **respondió** y otro si
**no respondió** en la etapa previa. Responder = ≥ 3 de 4 antidopings negativos en las 2 últimas semanas
de la etapa (criterio de ADAPT-2). Cada paquete fija el nivel de cada componente permitido (p. ej.,
bupropión 0/150/300/450 mg; MC estándar o de alta magnitud). Restricciones duras: lo que el motor clínico
permite, presupuesto y horas por semana, máximo de fármacos simultáneos y **no abandono terapéutico** (las
ramas *no responde* nunca reciben menos intensidad que la etapa 1).

### Objetivos (minimizar)

1. −P(abstinencia sostenida en semanas 33-36): durabilidad, 12 semanas después del programa.
2. −% de semanas abstinentes (1-36): beneficio acumulado.
3. Costo planeado del régimen (lo que cuesta si el sujeto lo completa). Se usa el costo planeado y no el
   esperado porque este último premiaría a los regímenes que provocan abandono: quien abandona deja de pagar.

Los eventos adversos graves se reportan y desempatan la selección final.

### Selección final

Entre los regímenes factibles **no-inferiores** al de máxima eficacia (margen: el menor entre 2 puntos y
10% relativo), se elige el más barato; los empates se resuelven por menos componentes y luego por menor
riesgo. Ese es el **conjunto mínimo suficiente**. La ablación clasifica cada componente como ESENCIAL,
CONTRIBUYE o MARGINAL.

## Qué cambió respecto al algoritmo original y por qué

| Original | Problema | v2 |
|---|---|---|
| "Gemelo digital" con constantes neuroquímicas (dopamina tónica, glutamato, CPF) | Sin base empírica ni forma de medirlas: no se puede calibrar ni falsar | Modelo de resultados medidos (antidoping semanal, el desenlace que aceptan FDA y los ensayos) calibrado contra ADAPT-2 y metaanálisis |
| Sinergias "ocultas" (rTMS+MC+NAC, etc.) | Inventadas | Solo una interacción: BUP×NTX, anclada a ADAPT-2 y declarada como reconciliación, no como sinergia demostrada |
| Crioterapia, NAC y modafinilo como pilares | Sin evidencia (crioterapia) o con ECA negativos (NAC, modafinilo) | Crioterapia eliminada; NAC y modafinilo solo con `--modo-investigacion` |
| Sin contraindicaciones | Podía recomendar bupropión a alguien con convulsiones | Motor clínico determinista con interlock |
| Un paciente genérico fijo | Sin personalización | Perfil de 68 campos → modificadores, mecanismos y priors de riesgo |
| Matriz fija de 12 semanas | No es un DTR: no se adapta a la respuesta | Reglas de decisión por respuesta en 4 etapas + 12 semanas de seguimiento |
| Suma ponderada arbitraria como aptitud | Mezcla unidades; pesos sin justificar | Frente de Pareto + análisis de decisión explícito |
| Evaluación determinista única | Ignora la incertidumbre | Monte Carlo con incertidumbre de parámetros y estructural, re-evaluación fuera de muestra |
| "Probabilidad de remisión" = 100 − riesgo medio | No es la probabilidad de nada medible | P(abstinencia sostenida) definida operativamente |

## Validación

- Reproduce ADAPT-2 etapa 1 (placebo 3.4%, BUP+NTX-XR 16.5%) y la recaída post-tratamiento (~60% a 12 meses).
- Etapa 2 de ADAPT-2 (no respondedores re-aleatorizados) dentro del IC95 publicado en los 7 modelos.
- Prueba externa no usada para calibrar: MC+CRA vs no tratar da OR ≈ 2.9-3.2 de abstinencia al final del
  tratamiento (NMA de De Crescenzo 2018: 2.84, IC95 1.24-6.51).
- Pruebas de reglas clínicas, restricciones, monotonía, determinismo y ordenamiento no dominado.

## Supuestos que más pesan (ver la sección 7 del reporte)

- R² = 0.30: fracción de la heterogeneidad entre personas que explica el perfil. Se puede ajustar con
  `contexto.r2_perfil`, y el reporte prueba 0.15 y 0.45.
- Los términos de riesgo del perfil son priors de experto, con saturación para factores correlacionados.
- Persistencia de efectos por clase y recaída post-tratamiento aproximada.
- Costos ilustrativos: reemplazarlos con `contexto.costos_mxn`. La naltrexona XR se asume no disponible
  en México (`contexto.niveles_no_disponibles`).

## Extender

- **Nuevo componente:** añadir un `Componente` en `dtr_base.py` con OR e IC95 de su mejor evidencia; la
  calibración lo convierte sola (borrar la caché).
- **Nueva contraindicación:** añadir una regla en `evaluar_clinico()`.
- **Integración:** el JSON de salida trae régimen, métricas, ablación y curva semanal. El perfil puede
  venir de otro sistema; `tept_complejo`, por ejemplo, desde una evaluación de trauma.
