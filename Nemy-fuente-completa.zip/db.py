"""SQLite persistence with application-level encryption for health and identities."""
import contextlib
import hashlib
import json
import os
from pathlib import Path
import sqlite3
from cryptography.fernet import Fernet

class Database:
    def __init__(self, data_dir=None, key_file=None):
        self.directory=Path(data_dir or os.environ.get("TRAZA_DATA_DIR", Path(__file__).parent / "work" / "data"))
        self.directory.mkdir(parents=True,exist_ok=True)
        self.path=self.directory / "db.sqlite"
        key_path=Path(key_file or os.environ.get("TRAZA_KEY_FILE", self.directory / "data.key"))
        if not key_path.exists():
            key_path.parent.mkdir(parents=True,exist_ok=True)
            fd=os.open(key_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            with os.fdopen(fd,"wb") as f: f.write(Fernet.generate_key())
        self.cipher=Fernet(key_path.read_bytes().strip())
        with self.connection() as con:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, username_hash TEXT UNIQUE NOT NULL, username_enc TEXT NOT NULL, password TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('admin','clinician','participant')), must_change INTEGER NOT NULL DEFAULT 1, mfa_secret TEXT, mfa_pending TEXT, mfa_enabled INTEGER NOT NULL DEFAULT 0, last_totp INTEGER NOT NULL DEFAULT -1, disabled INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at REAL NOT NULL, mfa_verified INTEGER NOT NULL DEFAULT 0, created_at REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS invitations(token_hash TEXT PRIMARY KEY,role TEXT NOT NULL,expires_at REAL NOT NULL,used_at REAL,created_by TEXT NOT NULL,created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS config(id INTEGER PRIMARY KEY CHECK(id=1),payload TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS records(user_id TEXT PRIMARY KEY REFERENCES users(id),revision INTEGER NOT NULL,payload TEXT NOT NULL,updated_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS record_versions(id INTEGER PRIMARY KEY,user_id TEXT NOT NULL,revision INTEGER NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS review_versions(id INTEGER PRIMARY KEY,user_id TEXT NOT NULL,revision INTEGER NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,at TEXT NOT NULL,actor TEXT,action TEXT NOT NULL,subject TEXT,outcome TEXT NOT NULL);
            CREATE INDEX IF NOT EXISTS audit_at ON audit(at);
            """)
            # Backwards-compatible schema updates for installations created by v1.
            for table,column in (("users","clinical_profile"),("invitations","clinical_profile")):
                columns={r[1] for r in con.execute(f"PRAGMA table_info({table})")}
                if column not in columns: con.execute(f"ALTER TABLE {table} ADD COLUMN {column} TEXT")
        try: os.chmod(self.path,0o600)
        except OSError: pass

    @contextlib.contextmanager
    def connection(self, transaction=False):
        con=sqlite3.connect(self.path,timeout=10)
        con.row_factory=sqlite3.Row
        con.execute("PRAGMA foreign_keys=ON")
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA secure_delete=ON")
        try:
            if transaction: con.execute("BEGIN IMMEDIATE")
            yield con
            con.commit()
        except Exception:
            con.rollback()
            raise
        finally: con.close()

    def encrypt(self,obj):
        return self.cipher.encrypt(json.dumps(obj,ensure_ascii=False,separators=(",",":"),allow_nan=False).encode()).decode()

    def decrypt(self,value): return json.loads(self.cipher.decrypt(value.encode()))

    @staticmethod
    def username_hash(username): return hashlib.sha256(username.strip().casefold().encode()).hexdigest()
