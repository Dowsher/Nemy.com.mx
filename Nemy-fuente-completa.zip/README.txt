NEMY 7 · Experiencia cinematográfica
https://nemy.com.mx/

LA EXPERIENCIA
Inicio: fotografía panorámica original y tres áreas para explorar. Encuentra tu punto de partida abre una selección de perspectiva y después seis preguntas. Ambas decisiones son necesarias para el recorrido personalizado de Consumo.
/emociones: información y ejercicios de observación progresivos.
/adicciones: doce entradas adaptadas a la pregunta elegida, siete capítulos, ciclo de siete etapas, espejo emocional, contexto, mapa, herramientas y cuaderno de observaciones/hipótesis/evidencia.
/mapa: las seis preguntas originales del proyecto, con distinción entre experiencia, hipótesis y evidencia.
/estancamiento: agotamiento, contexto laboral y pasos realistas.
/traza: conserva los tres recorridos, preguntas, puntuación, resultados, informes con IA y PDF. La presentación y las fotografías se actualizaron.
/comunidad: publicaciones, reacciones y comentarios reales para miembros.
/perfil: perfil de cuenta y recursos locales claramente separados.
/ayuda: acceso independiente a recursos de apoyo, sin registro ni selección previa.

NAVEGACIÓN Y DATOS
Puedes cambiar de recorrido desde la navegación. Los capítulos tienen anterior/siguiente, indicadores de avance y controles táctiles/de teclado. El movimiento respeta la preferencia del dispositivo y el control visible para reducirlo.
La perspectiva, la pregunta elegida y los recursos guardados se conservan sólo en sessionStorage de esta pestaña. No se envían al servidor ni se sincronizan con la cuenta. No se guardan allí teléfonos, códigos, textos de publicaciones o respuestas de TRAZA.
La comunidad conserva sus cuentas reales con alias y acceso por código de WhatsApp mediante Val. La moderación con IA continúa actuando sólo sobre comentarios. Los códigos, sesiones, cifrado y permisos del equipo siguen sin cambios.
Los cuestionarios y sus respuestas mantienen su proceso de consentimiento y almacenamiento cifrado independiente. Las nuevas fotografías son escenas conceptuales generadas con IA; no representan participantes ni testimonios reales.

IMÁGENES Y CÓDIGO
public/media contiene ocho familias fotográficas originales en WebP y sus variantes móviles. Los prompts y el manifiesto se incluyen en docs/. Las imágenes tienen dimensiones declaradas; hero con prioridad de carga y fotografías secundarias con carga diferida.
Se conserva FastAPI y HTML/CSS/JavaScript sin incorporar un framework ni dependencias remotas. Los scripts externos cumplen la política CSP del servidor. Ninguna clave ni base de datos va en este paquete.

EJECUCIÓN LOCAL (PYTHON 3.12+)
1. Crear un entorno virtual e instalar requirements.txt.
2. Definir TRAZA_DATA_DIR y TRAZA_KEY_FILE en un directorio privado fuera del código. Definir TRAZA_PUBLIC_ORIGIN=http://127.0.0.1:3230 y TRAZA_SECURE_COOKIE=0 sólo para revisión local.
3. Ejecutar: python -m uvicorn server:app --host 127.0.0.1 --port 3230 --no-access-log
4. Abrir http://127.0.0.1:3230 . Los servicios de IA y WhatsApp requieren la configuración privada existente y muestran honestamente su indisponibilidad cuando falta. No hay modo de acceso falso.

DESPLIEGUE
La versión publicada utiliza la configuración privada ya existente en el VPS, mantiene los datos y conserva la versión anterior para recuperación. Se respalda la base antes del cambio de versión y sólo se reinicia traza.service. Val, su pasarela y nemy-otp.service no se modifican.
La interfaz no abre por sí misma la operación clínica ni modifica los requisitos profesionales pendientes.
