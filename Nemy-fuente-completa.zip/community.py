"""Pseudonymous Nemy membership and community, isolated from clinical records."""
from __future__ import annotations
import base64
from datetime import datetime, timezone
import hashlib
import hmac
import inspect
import json
import os
import re
import secrets
import time
from urllib.parse import urlsplit
import uuid

import httpx
from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse
from moderation import CommentModerator, ModerationUnavailable

COOKIE = "nemy_session"
TOPICS = {"emotions": "Aspectos emocionales", "addictions": "Adicciones y consumo", "stagnation": "Estancamiento y desgaste"}
REACTIONS = ("support", "relate", "thanks")
AVATARS = ("violet", "mint", "coral", "blue", "sun")
OTP_TTL, SESSION_TTL = 300, 7 * 86400


def fail(message, status=422):
    raise HTTPException(status, message)


def exact(value, required, optional=()):
    if not isinstance(value, dict) or not set(required) <= set(value) or not set(value) <= set(required) | set(optional):
        fail("Revisa los campos enviados.")


def uid(value):
    try:
        if not isinstance(value, str) or len(value) != 36 or str(uuid.UUID(value)) != value.lower():
            raise ValueError()
    except (ValueError, AttributeError):
        fail("El identificador de la solicitud no es válido.")
    return value.lower()


def stamp(value):
    return datetime.fromtimestamp(value, timezone.utc).isoformat()


def text(value, minimum, maximum, label):
    if not isinstance(value, str):
        fail("Revisa " + label + ".")
    value = value.strip()
    if not minimum <= len(value) <= maximum or any(ord(c) < 32 and c not in "\n\t" for c in value):
        fail("Revisa " + label + ".")
    return value


def phone_number(value):
    if not isinstance(value, str) or len(value) > 35 or not re.fullmatch(r"[+\d ()-]+", value):
        fail("Escribe un número de WhatsApp válido, con clave de país.")
    digits = re.sub(r"\D", "", value)
    if not value.strip().startswith("+") and len(digits) == 10:
        digits = "52" + digits
    if not re.fullmatch(r"52[0-9]{10}", digits):
        fail("Por ahora el acceso admite números de México: +52 y diez dígitos.")
    return "+" + digits


class OtpDeliveryUncertain(Exception):
    """The transport cannot prove whether WhatsApp accepted this exact send."""


class HttpOtpSender:
    def available(self):
        return bool(os.environ.get("NEMY_OTP_SENDER_URL", "").strip() and os.environ.get("NEMY_OTP_SENDER_TOKEN", "").strip())

    async def send(self, request_id, phone, code):
        base = os.environ.get("NEMY_OTP_SENDER_URL", "").rstrip("/")
        parsed = urlsplit(base)
        if not self.available() or parsed.scheme != "http" or parsed.hostname not in ("127.0.0.1", "localhost", "::1") or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise RuntimeError("sender_unavailable")
        path = base if parsed.path.endswith("/otp/send") else base + "/otp/send"
        try:
            async with httpx.AsyncClient(timeout=12, trust_env=False) as client:
                response = await client.post(path, json={"request_id": request_id, "phone": phone, "code": code,
                    "expires_in": OTP_TTL, "brand": "Nemy"}, headers={"Authorization": "Bearer " + os.environ["NEMY_OTP_SENDER_TOKEN"]})
            if response.status_code == 409 and len(response.content) <= 4096 and response.json().get("detail",{}).get("code") == "delivery_requires_review":
                raise OtpDeliveryUncertain()
            if response.status_code != 200 or len(response.content) > 4096 or response.json().get("ok") is not True:
                raise RuntimeError("sender_unavailable")
        except (httpx.TimeoutException, httpx.NetworkError):
            raise OtpDeliveryUncertain() from None
        except (httpx.HTTPError, ValueError, KeyError):
            raise RuntimeError("sender_unavailable") from None


class CommunityService:
    def __init__(self, db, sender=None, moderator=None):
        self.db, self.sender, self.moderator = db, sender or HttpOtpSender(), moderator or CommentModerator()
        self.key = hmac.new(db.cipher._signing_key, b"nemy-community-v1", hashlib.sha256).digest()
        with db.connection() as con:
            con.executescript("""
            CREATE TABLE IF NOT EXISTS nemy_members(id TEXT PRIMARY KEY,phone_hash TEXT NOT NULL UNIQUE,phone_enc TEXT NOT NULL,profile_enc TEXT NOT NULL,alias_hash TEXT NOT NULL UNIQUE,disabled INTEGER NOT NULL DEFAULT 0,created_at REAL NOT NULL,updated_at REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS nemy_sessions(token_hash TEXT PRIMARY KEY,member_id TEXT NOT NULL REFERENCES nemy_members(id) ON DELETE CASCADE,expires_at REAL NOT NULL,created_at REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS nemy_otp(id TEXT PRIMARY KEY,request_id TEXT NOT NULL UNIQUE,request_hash TEXT NOT NULL,phone_hash TEXT NOT NULL,phone_enc TEXT NOT NULL,code_hash TEXT NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,status TEXT NOT NULL,created_at REAL NOT NULL,expires_at REAL NOT NULL);
            CREATE TABLE IF NOT EXISTS nemy_limits(key TEXT NOT NULL,bucket INTEGER NOT NULL,count INTEGER NOT NULL,PRIMARY KEY(key,bucket));
            CREATE TABLE IF NOT EXISTS nemy_posts(id TEXT PRIMARY KEY,member_id TEXT NOT NULL REFERENCES nemy_members(id) ON DELETE CASCADE,request_id TEXT NOT NULL,request_hash TEXT NOT NULL,topic TEXT NOT NULL,body_enc TEXT NOT NULL,created_at REAL NOT NULL,updated_at REAL NOT NULL,UNIQUE(member_id,request_id));
            CREATE TABLE IF NOT EXISTS nemy_reactions(post_id TEXT NOT NULL REFERENCES nemy_posts(id) ON DELETE CASCADE,member_id TEXT NOT NULL REFERENCES nemy_members(id) ON DELETE CASCADE,kind TEXT NOT NULL,created_at REAL NOT NULL,PRIMARY KEY(post_id,member_id,kind));
            CREATE TABLE IF NOT EXISTS nemy_comments(id TEXT PRIMARY KEY,post_id TEXT NOT NULL REFERENCES nemy_posts(id) ON DELETE CASCADE,member_id TEXT NOT NULL REFERENCES nemy_members(id) ON DELETE CASCADE,request_id TEXT NOT NULL,request_hash TEXT NOT NULL,body_enc TEXT NOT NULL,status TEXT NOT NULL,decision_enc TEXT,attempts INTEGER NOT NULL DEFAULT 0,lease_until REAL NOT NULL DEFAULT 0,created_at REAL NOT NULL,updated_at REAL NOT NULL,UNIQUE(member_id,request_id));
            CREATE TABLE IF NOT EXISTS nemy_blocks(member_id TEXT NOT NULL REFERENCES nemy_members(id) ON DELETE CASCADE,blocked_id TEXT NOT NULL REFERENCES nemy_members(id) ON DELETE CASCADE,created_at REAL NOT NULL,PRIMARY KEY(member_id,blocked_id));
            CREATE TABLE IF NOT EXISTS nemy_reports(id TEXT PRIMARY KEY,member_id TEXT NOT NULL REFERENCES nemy_members(id) ON DELETE CASCADE,target_type TEXT NOT NULL,target_id TEXT NOT NULL,reason_enc TEXT NOT NULL,created_at REAL NOT NULL,UNIQUE(member_id,target_type,target_id));
            CREATE INDEX IF NOT EXISTS nemy_posts_feed ON nemy_posts(created_at,id);
            CREATE INDEX IF NOT EXISTS nemy_comments_post ON nemy_comments(post_id,created_at);
            CREATE INDEX IF NOT EXISTS nemy_otp_phone ON nemy_otp(phone_hash,created_at);
            CREATE INDEX IF NOT EXISTS nemy_sessions_expiry ON nemy_sessions(expires_at);
            """)
            con.execute("DELETE FROM nemy_otp WHERE expires_at<?", (time.time()-86400,))
            con.execute("DELETE FROM nemy_sessions WHERE expires_at<?", (time.time(),))
            con.execute("DELETE FROM nemy_limits WHERE bucket<?", (int(time.time())-3*86400,))
        self.last_purge=time.time()

    def purge(self):
        """Opportunistic hourly cleanup; never touches the clinical tables."""
        now=time.time()
        if now-self.last_purge<3600:return
        with self.db.connection(transaction=True) as con:
            con.execute("DELETE FROM nemy_otp WHERE expires_at<?",(now-86400,))
            con.execute("DELETE FROM nemy_sessions WHERE expires_at<?",(now,))
            con.execute("DELETE FROM nemy_limits WHERE bucket<?",(int(now)-3*86400,))
        self.last_purge=now

    def digest(self, value):
        return hmac.new(self.key, str(value).encode(), hashlib.sha256).hexdigest()

    def fingerprint(self, value):
        return self.digest(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False))

    def audit(self, con, actor, action, subject=None):
        con.execute("INSERT INTO audit(at,actor,action,subject,outcome) VALUES(?,?,?,?,?)",
            (stamp(time.time()), self.digest(actor)[:20] if actor else None, action, self.digest(subject)[:20] if subject else None, "ok"))

    def limit(self, namespace, identity, maximum, seconds):
        now = int(time.time()); bucket = now//seconds*seconds
        key = self.digest(namespace + ":" + identity)
        with self.db.connection(transaction=True) as con:
            con.execute("DELETE FROM nemy_limits WHERE bucket<?", (now-3*86400,))
            row = con.execute("SELECT count FROM nemy_limits WHERE key=? AND bucket=?", (key,bucket)).fetchone()
            if row and row[0] >= maximum:
                fail("Has hecho varios intentos. Espera un momento y vuelve a intentar.", 429)
            con.execute("INSERT INTO nemy_limits VALUES(?,?,1) ON CONFLICT(key,bucket) DO UPDATE SET count=count+1", (key,bucket))

    def config(self):
        self.purge()
        return {"otp_available": self.sender.available(), "moderation_available": self.moderator.available(),
            "topics": [{"id": k, "label": v} for k,v in TOPICS.items()], "reactions": list(REACTIONS),
            "avatars": list(AVATARS), "otp_digits": 4, "otp_expires_in": OTP_TTL, "phone_region":"MX",
            "privacy": "Tu alias es público dentro de la comunidad. Tu teléfono se guarda cifrado para acceder y no se muestra a otras personas. La comunidad no es anónima frente al servicio de acceso ni a WhatsApp. La IA revisa los comentarios con un fragmento de hasta 300 caracteres de su publicación como contexto; no evalúa ni cambia la publicación original."}

    async def request_code(self, payload, ip):
        self.purge()
        exact(payload, {"phone", "adult", "consent", "request_id"})
        if payload["adult"] is not True or payload["consent"] is not True:
            fail("Confirma que tienes 18 años y autorizas recibir el código de acceso por WhatsApp.", 403)
        phone, request_id = phone_number(payload["phone"]), uid(payload["request_id"])
        fp, phone_hash, now = self.fingerprint({**payload,"phone":phone}), self.digest("phone:"+phone), time.time()
        with self.db.connection() as con:
            old = con.execute("SELECT * FROM nemy_otp WHERE request_id=?", (request_id,)).fetchone()
        if old:
            if not hmac.compare_digest(old["request_hash"], fp):fail("Esa solicitud ya se usó con otros datos.",409)
            if old["status"] in ("sent","uncertain") and old["expires_at"] > now:
                return self.challenge(old, phone)
            if old["status"] == "pending":fail("El envío sigue en curso. Espera unos segundos.",409)
            fail("No se pudo confirmar el envío. Solicita otro código más tarde.",503)
        if not self.sender.available():
            fail("El acceso por WhatsApp no está disponible en este momento. Puedes seguir leyendo Nemy.",503)
        self.limit("otp-ip-15m",ip,6,900); self.limit("otp-ip-day",ip,30,86400)
        self.limit("otp-phone-15m",phone_hash,3,900); self.limit("otp-phone-day",phone_hash,8,86400)
        self.limit("otp-global","global",1000,86400)
        challenge_id, code = str(uuid.uuid4()), str(secrets.randbelow(10000)).zfill(4)
        with self.db.connection(transaction=True) as con:
            recent = con.execute("SELECT created_at FROM nemy_otp WHERE phone_hash=? ORDER BY created_at DESC LIMIT 1", (phone_hash,)).fetchone()
            if recent and now-recent[0]<60:fail("Espera un minuto antes de pedir otro código.",429)
            con.execute("UPDATE nemy_otp SET status='superseded' WHERE phone_hash=? AND status IN ('pending','sent','uncertain')", (phone_hash,))
            con.execute("INSERT INTO nemy_otp(id,request_id,request_hash,phone_hash,phone_enc,code_hash,status,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?)",
                (challenge_id,request_id,fp,phone_hash,self.db.encrypt(phone),self.digest("otp:"+challenge_id+":"+code),"pending",now,now+OTP_TTL))
        try:
            await self.sender.send(request_id,phone,code)
        except OtpDeliveryUncertain:
            with self.db.connection(transaction=True) as con:
                con.execute("UPDATE nemy_otp SET status='uncertain' WHERE id=? AND status='pending'",(challenge_id,))
                row=con.execute("SELECT * FROM nemy_otp WHERE id=?",(challenge_id,)).fetchone()
            return self.challenge(row,phone)
        except Exception:
            with self.db.connection(transaction=True) as con:con.execute("UPDATE nemy_otp SET status='failed',code_hash='' WHERE id=?",(challenge_id,))
            fail("No se pudo confirmar el envío por WhatsApp. Intenta de nuevo más tarde.",503)
        finally:
            code = None
        with self.db.connection(transaction=True) as con:
            con.execute("UPDATE nemy_otp SET status='sent' WHERE id=? AND status='pending'", (challenge_id,))
            row = con.execute("SELECT * FROM nemy_otp WHERE id=?",(challenge_id,)).fetchone()
        return self.challenge(row,phone)

    def challenge(self, row, phone):
        return {"challenge_id": row["id"], "expires_in": max(0,int(row["expires_at"]-time.time())),
                "resend_after": max(0,int(60-(time.time()-row["created_at"]))), "masked_phone": "•••• "+phone[-4:],
                "delivery_status":row["status"],"notice":"Si recibes el código puedes ingresarlo; el envío no se confirmó." if row["status"]=="uncertain" else ""}

    def verify_code(self,payload,ip):
        exact(payload,{"challenge_id","code"}); challenge_id=uid(payload["challenge_id"])
        if not isinstance(payload["code"],str) or not re.fullmatch(r"[0-9]{4}",payload["code"]):fail("Escribe los cuatro dígitos del código.")
        self.limit("verify-ip-minute",ip,15,60);self.limit("verify-ip-hour",ip,100,3600)
        now,error,token,member = time.time(),None,None,None
        with self.db.connection(transaction=True) as con:
            challenge=con.execute("SELECT * FROM nemy_otp WHERE id=?",(challenge_id,)).fetchone()
            if not challenge or challenge["status"] not in ("sent","uncertain") or challenge["expires_at"]<=now or challenge["attempts"]>=5:
                error="El código no es válido o ya venció. Solicita uno nuevo."
            elif not hmac.compare_digest(challenge["code_hash"],self.digest("otp:"+challenge_id+":"+payload["code"])):
                con.execute("UPDATE nemy_otp SET attempts=attempts+1,status=CASE WHEN attempts+1>=5 THEN 'locked' ELSE status END WHERE id=?",(challenge_id,))
                error="El código no coincide. Revisa los cuatro dígitos."
            else:
                con.execute("UPDATE nemy_otp SET status='used',code_hash='' WHERE id=?",(challenge_id,))
                member=con.execute("SELECT * FROM nemy_members WHERE phone_hash=?",(challenge["phone_hash"],)).fetchone()
                if member and member["disabled"]:error="Esta cuenta no puede acceder."
                else:
                    if not member:
                        member_id=str(uuid.uuid4());alias="Viajero "+secrets.token_hex(3).upper()
                        con.execute("INSERT INTO nemy_members VALUES(?,?,?,?,?,0,?,?)",(member_id,challenge["phone_hash"],challenge["phone_enc"],self.db.encrypt({"alias":alias,"bio":"","avatar":secrets.choice(AVATARS)}),self.digest("alias:"+alias.casefold()),now,now))
                        member=con.execute("SELECT * FROM nemy_members WHERE id=?",(member_id,)).fetchone()
                    token=secrets.token_urlsafe(32)
                    con.execute("DELETE FROM nemy_sessions WHERE expires_at<?",(now,))
                    con.execute("INSERT INTO nemy_sessions VALUES(?,?,?,?)",(self.digest("session:"+token),member["id"],now+SESSION_TTL,now))
                    self.audit(con,member["id"],"nemy_login")
        if error:fail(error,401)
        return self.user(member),token

    def auth(self,request,optional=False):
        self.purge()
        token=request.cookies.get(COOKIE,"")
        row=None
        if isinstance(token,str) and 20<=len(token)<=128:
            with self.db.connection() as con:
                row=con.execute("SELECT m.* FROM nemy_sessions s JOIN nemy_members m ON m.id=s.member_id WHERE s.token_hash=? AND s.expires_at>? AND m.disabled=0",(self.digest("session:"+token),time.time())).fetchone()
        if row is None and not optional:fail("Entra con tu código de WhatsApp para participar.",401)
        return row

    def user(self,row):
        return {"id":row["id"],**self.db.decrypt(row["profile_enc"]),"created_at":stamp(row["created_at"])}

    def author(self,row):
        p=self.db.decrypt(row["profile_enc"])
        return {"id":row["id"],"alias":p["alias"],"avatar":p["avatar"]}

    def profile(self,member,payload):
        exact(payload,{"alias","bio","avatar"})
        alias=text(payload["alias"],3,32,"tu alias");bio=text(payload["bio"],0,300,"tu descripción")
        if not re.fullmatch(r"[\wÁÉÍÓÚÜÑáéíóúüñ .-]+",alias,re.UNICODE) or not isinstance(payload["avatar"],str) or payload["avatar"] not in AVATARS:
            fail("Elige un alias sencillo y un color de avatar disponible.")
        key=self.digest("alias:"+alias.casefold())
        with self.db.connection(transaction=True) as con:
            if con.execute("SELECT 1 FROM nemy_members WHERE alias_hash=? AND id!=?",(key,member["id"])).fetchone():fail("Ese alias ya está en uso. Prueba otro.",409)
            con.execute("UPDATE nemy_members SET profile_enc=?,alias_hash=?,updated_at=? WHERE id=?",(self.db.encrypt({"alias":alias,"bio":bio,"avatar":payload["avatar"]}),key,time.time(),member["id"]))
            return self.user(con.execute("SELECT * FROM nemy_members WHERE id=?",(member["id"],)).fetchone())

    def blocked(self,con,viewer,author):
        return viewer!=author and bool(con.execute("SELECT 1 FROM nemy_blocks WHERE (member_id=? AND blocked_id=?) OR (member_id=? AND blocked_id=?)",(viewer,author,author,viewer)).fetchone())

    def post_row(self,con,post_id,viewer):
        row=con.execute("SELECT p.* FROM nemy_posts p JOIN nemy_members m ON m.id=p.member_id WHERE p.id=? AND m.disabled=0",(uid(post_id),)).fetchone()
        if row is None or self.blocked(con,viewer,row["member_id"]):fail("La publicación no está disponible.",404)
        return row

    def post(self,con,row,viewer):
        author=con.execute("SELECT * FROM nemy_members WHERE id=?",(row["member_id"],)).fetchone()
        reactions={kind:0 for kind in REACTIONS};mine=[]
        for r in con.execute("SELECT kind,count(*) n FROM nemy_reactions WHERE post_id=? GROUP BY kind",(row["id"],)):reactions[r["kind"]]=r["n"]
        mine=[r[0] for r in con.execute("SELECT kind FROM nemy_reactions WHERE post_id=? AND member_id=?",(row["id"],viewer))]
        comments=con.execute("SELECT count(*) FROM nemy_comments c JOIN nemy_members m ON m.id=c.member_id WHERE c.post_id=? AND c.status='approved' AND m.disabled=0 AND NOT EXISTS(SELECT 1 FROM nemy_blocks b WHERE (b.member_id=? AND b.blocked_id=c.member_id) OR (b.blocked_id=? AND b.member_id=c.member_id))",(row["id"],viewer,viewer)).fetchone()[0]
        return {"id":row["id"],"topic":row["topic"],"body":self.db.decrypt(row["body_enc"]),"author":self.author(author),"created_at":stamp(row["created_at"]),"updated_at":stamp(row["updated_at"]),"reactions":reactions,"my_reactions":mine,"comment_count":comments,"can_edit":row["member_id"]==viewer,"can_delete":row["member_id"]==viewer}

    def cursor(self,row):
        p={"at":row["created_at"],"id":row["id"]};p["sig"]=self.fingerprint(p)
        return base64.urlsafe_b64encode(json.dumps(p,separators=(",",":")).encode()).decode().rstrip("=")

    def parse_cursor(self,value):
        if not isinstance(value,str) or len(value)>512:fail("El cursor no es válido.")
        try:
            p=json.loads(base64.urlsafe_b64decode(value+"="*((4-len(value)%4)%4)))
            if set(p)!={"at","id","sig"} or type(p["at"]) not in (int,float) or not hmac.compare_digest(p["sig"],self.fingerprint({"at":p["at"],"id":p["id"]})):raise ValueError()
            uid(p["id"]);return p
        except (ValueError,TypeError,KeyError,UnicodeError):fail("El cursor no es válido.")

    def feed(self,member,params):
        if not set(params)<={"topic","cursor","limit","mine"}:fail("Hay filtros no válidos.")
        topic=params.get("topic") or None
        if topic and topic not in TOPICS:fail("Elige un tema disponible.")
        try:limit=int(params.get("limit",10))
        except (ValueError,TypeError):fail("El límite no es válido.")
        if not 1<=limit<=30:fail("El límite no es válido.")
        values=[member["id"],member["id"]];where="m.disabled=0 AND NOT EXISTS(SELECT 1 FROM nemy_blocks b WHERE (b.member_id=? AND b.blocked_id=p.member_id) OR (b.blocked_id=? AND b.member_id=p.member_id))"
        if topic:where+=" AND p.topic=?";values.append(topic)
        if params.get("mine")=="1":where+=" AND p.member_id=?";values.append(member["id"])
        if params.get("cursor"):
            c=self.parse_cursor(params["cursor"]);where+=" AND (p.created_at<? OR (p.created_at=? AND p.id<?))";values.extend((c["at"],c["at"],c["id"]))
        with self.db.connection() as con:
            rows=list(con.execute("SELECT p.* FROM nemy_posts p JOIN nemy_members m ON m.id=p.member_id WHERE "+where+" ORDER BY p.created_at DESC,p.id DESC LIMIT ?",[*values,limit+1]))
            return {"posts":[self.post(con,r,member["id"]) for r in rows[:limit]],"next_cursor":self.cursor(rows[limit-1]) if len(rows)>limit else None}

    def create_post(self,member,payload):
        exact(payload,{"request_id","topic","body"});request_id=uid(payload["request_id"])
        if not isinstance(payload["topic"],str) or payload["topic"] not in TOPICS:fail("Elige un tema disponible.")
        body=text(payload["body"],1,5000,"la publicación");fp=self.fingerprint({**payload,"body":body})
        with self.db.connection() as con:old=con.execute("SELECT * FROM nemy_posts WHERE member_id=? AND request_id=?",(member["id"],request_id)).fetchone()
        if old:
            if not hmac.compare_digest(old["request_hash"],fp):fail("Ese envío ya contiene otra publicación.",409)
            with self.db.connection() as con:return self.post(con,old,member["id"])
        self.limit("posts",member["id"],12,3600);now=time.time()
        with self.db.connection(transaction=True) as con:
            old=con.execute("SELECT * FROM nemy_posts WHERE member_id=? AND request_id=?",(member["id"],request_id)).fetchone()
            if old:
                if not hmac.compare_digest(old["request_hash"],fp):fail("Ese envío ya contiene otra publicación.",409)
                return self.post(con,old,member["id"])
            post_id=str(uuid.uuid4());con.execute("INSERT INTO nemy_posts VALUES(?,?,?,?,?,?,?,?)",(post_id,member["id"],request_id,fp,payload["topic"],self.db.encrypt(body),now,now))
            return self.post(con,self.post_row(con,post_id,member["id"]),member["id"])

    def edit_post(self,member,post_id,payload):
        exact(payload,{"body","topic"});body=text(payload["body"],1,5000,"la publicación")
        if not isinstance(payload["topic"],str) or payload["topic"] not in TOPICS:fail("Elige un tema disponible.")
        with self.db.connection(transaction=True) as con:
            row=self.post_row(con,post_id,member["id"])
            if row["member_id"]!=member["id"]:fail("Sólo puedes editar tus publicaciones.",403)
            con.execute("UPDATE nemy_posts SET body_enc=?,topic=?,updated_at=? WHERE id=?",(self.db.encrypt(body),payload["topic"],time.time(),row["id"]))
            return self.post(con,self.post_row(con,post_id,member["id"]),member["id"])

    def comment(self,con,row,viewer,admin=False):
        author=con.execute("SELECT * FROM nemy_members WHERE id=?",(row["member_id"],)).fetchone()
        decision=self.db.decrypt(row["decision_enc"]) if row["decision_enc"] else {}
        own=row["member_id"]==viewer
        return {"id":row["id"],"post_id":row["post_id"],"author":self.author(author),"body":self.db.decrypt(row["body_enc"]),"status":row["status"],"created_at":stamp(row["created_at"]),"updated_at":stamp(row["updated_at"]),"can_delete":own,
                **({"notice":decision.get("reason", "Estamos revisando el comentario. Puedes volver a intentar." if row["status"]=="pending" else ""),"category":decision.get("category","none")} if own or admin else {})}

    def comments(self,member,post_id):
        with self.db.connection() as con:
            self.post_row(con,post_id,member["id"])
            rows=list(con.execute("SELECT c.* FROM nemy_comments c JOIN nemy_members m ON m.id=c.member_id WHERE c.post_id=? AND m.disabled=0 AND (c.status='approved' OR c.member_id=?) AND NOT EXISTS(SELECT 1 FROM nemy_blocks b WHERE (b.member_id=? AND b.blocked_id=c.member_id) OR (b.blocked_id=? AND b.member_id=c.member_id)) ORDER BY c.created_at DESC,c.id DESC LIMIT 201",(post_id,member["id"],member["id"],member["id"])))
            # Preserve newest contributions in long threads, then read them in
            # conversational order. Hidden comments never consume this window.
            return {"comments":[self.comment(con,r,member["id"]) for r in reversed(rows[:200])],"has_more":len(rows)>200}

    async def create_comment(self,member,post_id,payload):
        exact(payload,{"request_id","body","ai_consent"})
        if payload["ai_consent"] is not True:fail("Acepta la revisión por IA del comentario para publicarlo.",403)
        request_id=uid(payload["request_id"]);body=text(payload["body"],1,2000,"el comentario")
        fp=self.fingerprint({"post_id":post_id,**payload,"body":body})
        with self.db.connection() as con:
            self.post_row(con,post_id,member["id"])
            old=con.execute("SELECT * FROM nemy_comments WHERE member_id=? AND request_id=?",(member["id"],request_id)).fetchone()
        if old:
            if not hmac.compare_digest(old["request_hash"],fp):fail("Ese envío ya corresponde a otro comentario.",409)
            with self.db.connection() as con:return self.comment_result(con,old,member["id"])
        self.limit("comments-hour",member["id"],30,3600);self.limit("comments-day",member["id"],120,86400)
        now=time.time();comment_id=str(uuid.uuid4())
        with self.db.connection(transaction=True) as con:
            old=con.execute("SELECT * FROM nemy_comments WHERE member_id=? AND request_id=?",(member["id"],request_id)).fetchone()
            if old:
                if not hmac.compare_digest(old["request_hash"],fp):fail("Ese envío ya corresponde a otro comentario.",409)
                return self.comment_result(con,old,member["id"])
            con.execute("INSERT INTO nemy_comments VALUES(?,?,?,?,?,?,?,NULL,0,0,?,?)",(comment_id,post_id,member["id"],request_id,fp,self.db.encrypt(body),"pending",now,now))
        return await self.review_comment(member,comment_id)

    def comment_result(self,con,row,viewer):
        result=self.comment(con,row,viewer)
        return {"comment":result,"status":row["status"],"notice":result.get("notice","")}

    async def review_comment(self,member,comment_id):
        now=time.time()
        with self.db.connection(transaction=True) as con:
            row=con.execute("SELECT * FROM nemy_comments WHERE id=? AND member_id=?",(uid(comment_id),member["id"])).fetchone()
            if row is None:fail("El comentario no está disponible.",404)
            if row["status"]!="pending" or row["lease_until"]>now:return self.comment_result(con,row,member["id"])
            if row["attempts"]>=5:fail("Este comentario necesita revisión del equipo. Puedes escribir otro comentario.",429)
            parent=self.post_row(con,row["post_id"],member["id"])
            con.execute("UPDATE nemy_comments SET lease_until=?,attempts=attempts+1 WHERE id=?",(now+40,row["id"]))
            body,context=self.db.decrypt(row["body_enc"]),self.db.decrypt(parent["body_enc"])
        self.limit("ai-global","comments",2000,86400)
        try:
            decision=await self.moderator.review(body,context)
            if decision.get("action") not in ("publish","intervene") or decision.get("category") is None or not isinstance(decision.get("reason"),str):raise ModerationUnavailable()
            status="approved" if decision["action"]=="publish" else "intervened"
        except Exception:
            decision={"category":"unavailable","reason":"No se pudo completar la revisión ahora. Tu comentario está guardado; vuelve a intentar en un momento."};status="pending"
        with self.db.connection(transaction=True) as con:
            current=con.execute("SELECT * FROM nemy_comments WHERE id=?",(row["id"],)).fetchone()
            if current is None:fail("El comentario se eliminó durante la revisión.",409)
            # A moderator's decision made during the provider call takes priority.
            if current["status"]=="pending":
                con.execute("UPDATE nemy_comments SET status=?,decision_enc=?,lease_until=0,updated_at=? WHERE id=?",(status,self.db.encrypt(decision),time.time(),row["id"]))
            current=con.execute("SELECT * FROM nemy_comments WHERE id=?",(row["id"],)).fetchone()
            return self.comment_result(con,current,member["id"])

    def report(self,member,payload):
        exact(payload,{"target_type","target_id","reason"})
        if payload["target_type"] not in ("post","comment"):fail("El contenido no es válido.")
        target_id=uid(payload["target_id"]);reason=text(payload["reason"],5,500,"el motivo del reporte")
        self.limit("reports",member["id"],10,3600)
        with self.db.connection(transaction=True) as con:
            if payload["target_type"]=="post":self.post_row(con,target_id,member["id"])
            else:
                row=con.execute("SELECT * FROM nemy_comments WHERE id=?",(target_id,)).fetchone()
                if not row or row["status"]!="approved":fail("El comentario no está disponible.",404)
                self.post_row(con,row["post_id"],member["id"])
            con.execute("INSERT INTO nemy_reports VALUES(?,?,?,?,?,?) ON CONFLICT(member_id,target_type,target_id) DO NOTHING",(str(uuid.uuid4()),member["id"],payload["target_type"],target_id,self.db.encrypt(reason),time.time()))
        return {"ok":True}

    def admin_dashboard(self,params,actor):
        if not set(params)<={"status","limit","cursor"}:fail("Hay filtros no válidos.")
        status=params.get("status") or "pending"
        if status not in ("pending","intervened","approved","all"):fail("El estado no es válido.")
        try:limit=int(params.get("limit",25))
        except (ValueError,TypeError):fail("El límite no es válido.")
        if not 1<=limit<=100:fail("El límite no es válido.")
        where,values="1=1",[]
        if status!="all":where+=" AND status=?";values.append(status)
        if params.get("cursor"):
            c=self.parse_cursor(params["cursor"]);where+=" AND (created_at<? OR (created_at=? AND id<?))";values.extend([c["at"],c["at"],c["id"]])
        with self.db.connection(transaction=True) as con:
            summary={k:con.execute("SELECT count(*) FROM "+table).fetchone()[0] for k,table in (("members","nemy_members"),("posts","nemy_posts"),("comments","nemy_comments"),("reactions","nemy_reactions"),("reports","nemy_reports"))}
            for s in ("pending","intervened"):summary[s]=con.execute("SELECT count(*) FROM nemy_comments WHERE status=?",(s,)).fetchone()[0]
            rows=list(con.execute("SELECT * FROM nemy_comments WHERE "+where+" ORDER BY created_at DESC,id DESC LIMIT ?",[*values,limit+1]))
            reports=[{"id":r["id"],"target_type":r["target_type"],"target_id":r["target_id"],"reason":self.db.decrypt(r["reason_enc"]),"created_at":stamp(r["created_at"])} for r in con.execute("SELECT * FROM nemy_reports ORDER BY created_at DESC LIMIT 50")]
            self.audit(con,actor,"nemy_admin_dashboard")
            return {"summary":summary,"comments":[self.comment(con,r,None,True) for r in rows[:limit]],"reports":reports,"next_cursor":self.cursor(rows[limit-1]) if len(rows)>limit else None}


def attach_community(app,db,authorize_admin,sender=None,moderator=None):
    service=CommunityService(db,sender,moderator);app.state.community=service
    secure=os.environ.get("TRAZA_SECURE_COOKIE","1")=="1"

    async def body(request):
        raw=await request.body()
        if len(raw)>16384:fail("El contenido es demasiado largo.",413)
        try:return json.loads(raw)
        except (ValueError,TypeError,UnicodeError):fail("Se requiere un contenido JSON válido.")

    def ip(request):
        value=request.client.host if request.client else "unknown"
        forwarded=request.headers.get("x-forwarded-for","").strip()
        if value in ("127.0.0.1","::1") and forwarded and "," not in forwarded and len(forwarded)<=64:value=forwarded
        return value

    async def admin(request):
        actor=authorize_admin(request)
        if inspect.isawaitable(actor):actor=await actor
        if actor["role"]!="admin":fail("No tienes acceso a este panel.",403)
        return actor["id"]

    @app.get("/api/community/config")
    async def config():return service.config()

    @app.post("/api/community/auth/request-code")
    async def request_code(request:Request):return await service.request_code(await body(request),ip(request))

    @app.post("/api/community/auth/verify-code")
    async def verify(request:Request):
        member,token=service.verify_code(await body(request),ip(request));response=JSONResponse({"user":member})
        response.set_cookie(COOKIE,token,max_age=SESSION_TTL,httponly=True,secure=secure,samesite="strict",path="/")
        return response

    @app.get("/api/community/auth/me")
    async def me(request:Request):
        member=service.auth(request,True);return {"user":service.user(member) if member else None}

    @app.post("/api/community/auth/logout")
    async def logout(request:Request):
        await body(request)
        with db.connection(transaction=True) as con:con.execute("DELETE FROM nemy_sessions WHERE token_hash=?",(service.digest("session:"+request.cookies.get(COOKIE,"")),))
        response=JSONResponse({"ok":True});response.delete_cookie(COOKIE,path="/",secure=secure,samesite="strict",httponly=True);return response

    @app.get("/api/community/profile")
    async def profile(request:Request):return {"user":service.user(service.auth(request))}

    @app.patch("/api/community/profile")
    async def edit_profile(request:Request):
        member=service.auth(request);service.limit("profile",member["id"],20,3600)
        return {"user":service.profile(member,await body(request))}

    @app.delete("/api/community/profile")
    async def delete_profile(request:Request):
        member=service.auth(request);exact(await body(request),set())
        with db.connection(transaction=True) as con:
            con.execute("DELETE FROM nemy_otp WHERE phone_hash=?",(member["phone_hash"],))
            con.execute("DELETE FROM nemy_members WHERE id=?",(member["id"],));service.audit(con,None,"nemy_account_deleted")
        response=JSONResponse({"ok":True});response.delete_cookie(COOKIE,path="/",secure=secure,samesite="strict",httponly=True);return response

    @app.get("/api/community/posts")
    async def feed(request:Request):return service.feed(service.auth(request),dict(request.query_params))

    @app.post("/api/community/posts")
    async def create_post(request:Request):return {"post":service.create_post(service.auth(request),await body(request))}

    @app.get("/api/community/posts/{post_id}")
    async def get_post(post_id:str,request:Request):
        member=service.auth(request)
        with db.connection() as con:return {"post":service.post(con,service.post_row(con,post_id,member["id"]),member["id"])}

    @app.patch("/api/community/posts/{post_id}")
    async def edit_post(post_id:str,request:Request):return {"post":service.edit_post(service.auth(request),post_id,await body(request))}

    @app.delete("/api/community/posts/{post_id}")
    async def delete_post(post_id:str,request:Request):
        member=service.auth(request);exact(await body(request),set())
        with db.connection(transaction=True) as con:
            row=service.post_row(con,post_id,member["id"])
            if row["member_id"]!=member["id"]:fail("Sólo puedes borrar tus publicaciones.",403)
            con.execute("DELETE FROM nemy_posts WHERE id=?",(row["id"],))
        return {"ok":True}

    @app.post("/api/community/posts/{post_id}/reaction")
    async def reaction(post_id:str,request:Request):
        member=service.auth(request);payload=await body(request);exact(payload,{"kind"})
        if payload["kind"] not in REACTIONS:fail("Elige una reacción disponible.")
        service.limit("reactions",member["id"],150,3600)
        with db.connection(transaction=True) as con:
            row=service.post_row(con,post_id,member["id"])
            old=con.execute("SELECT 1 FROM nemy_reactions WHERE post_id=? AND member_id=? AND kind=?",(post_id,member["id"],payload["kind"])).fetchone()
            if old:con.execute("DELETE FROM nemy_reactions WHERE post_id=? AND member_id=? AND kind=?",(post_id,member["id"],payload["kind"]))
            else:con.execute("INSERT INTO nemy_reactions VALUES(?,?,?,?)",(post_id,member["id"],payload["kind"],time.time()))
            return {"post":service.post(con,row,member["id"])}

    @app.get("/api/community/posts/{post_id}/comments")
    async def comments(post_id:str,request:Request):return service.comments(service.auth(request),post_id)

    @app.post("/api/community/posts/{post_id}/comments")
    async def comment(post_id:str,request:Request):return await service.create_comment(service.auth(request),post_id,await body(request))

    @app.post("/api/community/comments/{comment_id}/retry")
    async def retry_comment(comment_id:str,request:Request):
        member=service.auth(request);payload=await body(request);exact(payload,{"ai_consent"})
        if payload["ai_consent"] is not True:fail("Acepta la revisión por IA del comentario.",403)
        service.limit("comment-retry",member["id"],20,3600)
        return await service.review_comment(member,comment_id)

    @app.delete("/api/community/comments/{comment_id}")
    async def delete_comment(comment_id:str,request:Request):
        member=service.auth(request);exact(await body(request),set())
        with db.connection(transaction=True) as con:
            row=con.execute("SELECT * FROM nemy_comments WHERE id=?",(uid(comment_id),)).fetchone()
            if row is None:fail("El comentario no está disponible.",404)
            if row["member_id"]!=member["id"]:fail("Sólo puedes borrar tus comentarios.",403)
            con.execute("DELETE FROM nemy_comments WHERE id=?",(row["id"],))
        return {"ok":True}

    @app.post("/api/community/reports")
    async def report(request:Request):return service.report(service.auth(request),await body(request))

    @app.post("/api/community/blocks")
    async def block(request:Request):
        member=service.auth(request);payload=await body(request);exact(payload,{"member_id"})
        target=uid(payload["member_id"])
        if target==member["id"]:fail("No puedes bloquear tu propia cuenta.")
        with db.connection(transaction=True) as con:
            if con.execute("SELECT 1 FROM nemy_members WHERE id=?",(target,)).fetchone() is None:fail("La cuenta no está disponible.",404)
            con.execute("INSERT INTO nemy_blocks VALUES(?,?,?) ON CONFLICT DO NOTHING",(member["id"],target,time.time()))
        return {"ok":True}

    @app.delete("/api/community/blocks/{member_id}")
    async def unblock(member_id:str,request:Request):
        member=service.auth(request);exact(await body(request),set())
        with db.connection(transaction=True) as con:con.execute("DELETE FROM nemy_blocks WHERE member_id=? AND blocked_id=?",(member["id"],uid(member_id)))
        return {"ok":True}

    @app.get("/api/community/blocks")
    async def blocks(request:Request):
        member=service.auth(request)
        with db.connection() as con:
            rows=con.execute("SELECT m.* FROM nemy_blocks b JOIN nemy_members m ON m.id=b.blocked_id WHERE b.member_id=? ORDER BY b.created_at DESC",(member["id"],))
            return {"blocks":[service.author(r) for r in rows]}

    @app.get("/api/admin/community")
    async def dashboard(request:Request):return service.admin_dashboard(dict(request.query_params),await admin(request))

    @app.get("/api/admin/community/posts/{post_id}")
    async def admin_post(post_id:str,request:Request):
        actor=await admin(request)
        with db.connection(transaction=True) as con:
            row=con.execute("SELECT * FROM nemy_posts WHERE id=?",(uid(post_id),)).fetchone()
            if row is None:fail("La publicación no está disponible.",404)
            service.audit(con,actor,"nemy_admin_post_viewed",row["id"])
            return {"post":service.post(con,row,None)}

    @app.patch("/api/admin/community/comments/{comment_id}")
    async def admin_comment(comment_id:str,request:Request):
        actor=await admin(request);payload=await body(request);exact(payload,{"action","reason"})
        if payload["action"] not in ("approve","intervene"):fail("La decisión no es válida.")
        reason=text(payload["reason"],3,280,"el motivo de revisión")
        with db.connection(transaction=True) as con:
            row=con.execute("SELECT * FROM nemy_comments WHERE id=?",(uid(comment_id),)).fetchone()
            if row is None:fail("El comentario no está disponible.",404)
            con.execute("UPDATE nemy_comments SET status=?,decision_enc=?,lease_until=0,updated_at=? WHERE id=?",("approved" if payload["action"]=="approve" else "intervened",db.encrypt({"category":"manual_review","reason":reason}),time.time(),row["id"]))
            service.audit(con,actor,"nemy_comment_reviewed",row["id"])
            return {"comment":service.comment(con,con.execute("SELECT * FROM nemy_comments WHERE id=?",(row["id"],)).fetchone(),None,True)}

    @app.post("/api/admin/community/members/{member_id}/status")
    async def admin_member(member_id:str,request:Request):
        actor=await admin(request);payload=await body(request);exact(payload,{"disabled","reason"})
        if type(payload["disabled"]) is not bool:fail("El estado no es válido.")
        text(payload["reason"],3,280,"el motivo de revisión")
        with db.connection(transaction=True) as con:
            if not con.execute("SELECT 1 FROM nemy_members WHERE id=?",(uid(member_id),)).fetchone():fail("La cuenta no está disponible.",404)
            con.execute("UPDATE nemy_members SET disabled=?,updated_at=? WHERE id=?",(int(payload["disabled"]),time.time(),member_id))
            if payload["disabled"]:con.execute("DELETE FROM nemy_sessions WHERE member_id=?",(member_id,))
            service.audit(con,actor,"nemy_member_disabled" if payload["disabled"] else "nemy_member_enabled",member_id)
        return {"ok":True}
    return service
