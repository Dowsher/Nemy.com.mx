"""Transparent original-module rules. No diagnosis or calibrated probability."""
from datetime import date, timedelta
import hashlib
import json
import re

MISSING = (98, 99)
YES = (1, "yes", "si", "sí")
NO = (0, "no")
SUBSTANCES = {"alcohol", "cannabis", "opioids", "benzodiazepines", "inhalants", "other", "none", "meth", "cocaine", "crack", 98, 99}
TIMINGS = {"antes", "al-mismo-tiempo", "despues", "antes-y-siguio", "before", "concurrent", "after", "before_ongoing", "unknown", 98, 99}
VE1_CHOICES = {"hoy", "ayer", "2-3", "4-7", "1-4-semanas", "mas-1-mes", "nunca", "today", "yesterday", "2_3_days", "4_7_days", "1_4_weeks", "over_month", "never", 98, 99}
LIFE_EVENTS = {"muerte", "ruptura", "trabajo", "casa", "violencia", "encierro", "desaparicion", "migracion", "salud", "nada", "pleito", "recuerdo", "fecha", "salida-anexo", 98, 99}
CHOICES = {
 "CB0": {"hoy", "ayer", "2-7-dias", "8-30-dias", "31-90-dias", "mas-90-dias", 98, 99},
 "CB2": {*(f"MD{i}" for i in range(1,25)), 98, 99},
 "CB3": {"no-valgo", "merezco", "nadie", "no-aguanto", "ya-que", "una-vez", "asi-puedo", "alerta", 98, 99},
 "CB5": {"corazon", "tension", "nudo", "apagado", "inquietud", "cansancio", "nada", 98, 99},
 "CB6": {"minutos", "horas", "dia", 98, 99},
 "CB6_try": {"no", "respirar", "llamar", "salir", "otra", 98, 99},
 "CB8": {"alivio", "poder", "despierto", "convivir", "trabajar", "nada", "peor", 98, 99},
 "CB10": {"vulnerabilidad", "detonante", "pensamiento", "emocion", "ganas", "consumo", 98, 99},
}
ARRAY_CHOICES = {
 "VE2": SUBSTANCES, "LT5": LIFE_EVENTS, "LT7": LIFE_EVENTS,
 "CB1": {"sueno", "comida", "dolor", "estres", "sustancia", "soledad", "dinero", "nada", 98, 99},
 "CB4": {"verguenza", "culpa", "miedo", "rabia", "soledad", "vacio", "tristeza", "alegria", 98, 99},
 "CB7": SUBSTANCES,
 "CB9": {"culpa", "bajon", "conflicto", "miedo", "bien", 98, 99},
 "strengths": {"persona", "rutina", "movimiento", "espiritualidad", "grupo", "tratamiento", "arte", "ninguno", 98, 99},
}

class InputError(ValueError):
    pass

def scalar_choice(value, choices):
    return not isinstance(value, (list, dict, bool)) and value in choices

def integer(value, lo, hi, missing=True):
    return type(value) is int and (lo <= value <= hi or (missing and value in MISSING))

def validate_answers(patch):
    if not isinstance(patch, dict) or len(patch) > 200:
        raise InputError("Respuestas inválidas.")
    result = {}
    for raw_key, value in patch.items():
        key = {"MFC_R":"MFC-R", "MFC_I":"MFC-I", "MD_T":"MD-T"}.get(raw_key, raw_key)
        valid = False
        if key == "consent":
            valid = isinstance(value, dict) and set(value) <= {"adult","care","storage","version","research","ai"} and all(value.get(k) is True for k in ("adult","care","storage")) and value.get("version") == "1.0" and all(type(value[k]) is bool for k in ("research","ai") if k in value)
        elif key == "session":
            valid = isinstance(value, dict) and set(value) <= {"number","phase","suds_before","suds_after"} and type(value.get("number")) is int and value["number"] in (1,2,3) and value.get("phase", "active") in ("active","complete") and all(integer(value[k],0,10,False) for k in ("suds_before","suds_after") if k in value)
        elif key == "completed_blocks":
            valid = isinstance(value,list) and len(value)<=20 and all(v in {"safety","state","functions","mfc","risk","context","timeline","triggers","chain","psychosis","suicide","shame","vg","cs","chemsex","strengths","readiness"} for v in value)
        elif key in ("S1","S2","S3","VE3") or re.fullmatch(r"(?:CX(?:[1-9]|1[0-7])(?:_ongoing)?|SR[1-3]|CS[1-6]|PS5)",key):
            valid = scalar_choice(value, {*YES,*NO,98,99})
        elif re.fullmatch(r"CX(?:[1-9]|1[0-7])_timing", key):
            valid = scalar_choice(value, TIMINGS)
        elif key == "VE1": valid = scalar_choice(value, VE1_CHOICES)
        elif key == "VE4": valid = integer(value,0,3)
        elif key == "VE5": valid = integer(value,0,14)
        elif key in ("VE6","CB4_intensity","readiness"): valid = integer(value,0,10)
        elif key == "MFC-I" or re.fullmatch(r"MFC(?:[1-9]|1[0-2])|MD(?:[1-9]|1[0-9]|2[0-4])",key): valid = integer(value,0,3)
        elif key == "MFC-R":
            valid = scalar_choice(value,{*(f"MFC{i}" for i in range(1,13)),*range(1,13),98,99})
            if type(value) is int and 1 <= value <=12: value = f"MFC{value}"
        elif key == "MD-T":
            valid = scalar_choice(value,{*(f"MD{i}" for i in range(1,25)),*range(1,25),98,99})
            if type(value) is int and 1 <= value <=24: value = f"MD{value}"
        elif re.fullmatch(r"LT[1-4]",key): valid = integer(value,1,100)
        elif key == "LT6": valid = scalar_choice(value,{0,1,2,4,7,98,99})
        elif re.fullmatch(r"VG[1-6]",key): valid = integer(value,0,4)
        elif re.fullmatch(r"PS[1-4]",key): valid = integer(value,0,2)
        elif key in CHOICES: valid = scalar_choice(value, CHOICES[key])
        elif key in ARRAY_CHOICES:
            valid = isinstance(value,list) and len(value) <= (2 if key=="CB4" else 20) and len(value)==len(set(str(v) for v in value)) and all(scalar_choice(v,ARRAY_CHOICES[key]) for v in value)
        if not valid: raise InputError(f"Respuesta no permitida: {key}")
        result[key] = value
    return result

def safety_ready(answers):
    required = ("S1","S2","S3","VE1","VE3","VE4","VE5","VE6")
    return all(k in answers and answers[k] not in MISSING for k in required) and answers.get("S1") in YES and answers.get("S3") in NO and "suds_before" in answers.get("session",{})

def trauma_key(key):
    return bool(re.fullmatch(r"CX\d+(?:_ongoing|_timing)?|LT\d+|VG\d+|CS\d+|CB\w+|MD\d+|MD-T",key))

def evaluate(answers, ema=None, sessions=None, session_peaks=None):
    flags = []
    def flag(code,severity,message,evidence):
        fingerprint = hashlib.sha256(json.dumps([code,answers.get("session",{}).get("number",1),evidence],sort_keys=True).encode()).hexdigest()[:18]
        flags.append({"id":fingerprint,"code":code,"severity":severity,"status":"open","message":message,"evidence":evidence})
    if answers.get("S1") in NO: flag("unsafe","red","Detener: el lugar no es seguro.",answers.get("S1"))
    if answers.get("S2") in YES: flag("screen_privacy","yellow","La pantalla puede exponerte; considera salida rápida.",answers.get("S2"))
    if answers.get("S3") in YES: flag("current_self_harm","red","Detener y buscar atención inmediata; la plataforma no avisa a emergencias.",answers.get("S3"))
    if answers.get("S3") in MISSING: flag("safety_unanswered","yellow","Seguridad sin responder: revisar con especialista.",answers.get("S3"))
    for key in ("SR1","SR2","SR3"):
        v=answers.get(key)
        if v in YES or (key in ("SR2","SR3") and v==99): flag("suicide_"+key,"red","Se requiere evaluación presencial inmediata del riesgo.",{key:v})
    ps = {k:answers[k] for k in ("PS1","PS2","PS3","PS4") if answers.get(k)==2}
    if ps or answers.get("PS5") in YES: flag("psychosis","orange","Experiencias que requieren evaluación clínica prioritaria.",{**ps,"PS5":answers.get("PS5")})
    postpone = answers.get("VE3") in YES or answers.get("VE1") in ("hoy","today") or (integer(answers.get("VE6"),0,3,False))
    if postpone: flag("postpone","orange","Posponer evaluación: efecto actual, consumo hoy o concentración insuficiente.",{k:answers.get(k) for k in ("VE1","VE3","VE6")})
    acute = answers.get("VE1") in ("ayer","2-3","4-7","yesterday","2_3_days","4_7_days") or (type(answers.get("VE4")) is int and 1<=answers["VE4"]<=3) or integer(answers.get("VE5"),0,3,False)
    if acute: flag("acute_state","yellow","Estado agudo: respuestas pueden estar influidas; valorar reaplicación tras 14 días sin consumo.",{k:answers.get(k) for k in ("VE1","VE4","VE5")})
    state = answers.get("session",{})
    suds = [state[k] for k in ("suds_before","suds_after") if k in state]
    peak=max(suds+[int((session_peaks or {}).get(str(state.get("number",1)),0))])
    if peak>=8: flag("distress_high","yellow","Detener módulos de trauma durante esta sesión y buscar apoyo.",{"session":state.get("number",1),"peak":peak})
    elif state.get("suds_after",0)>=6 or state.get("suds_after",0)-state.get("suds_before",0)>=3: flag("grounding","yellow","Hacer anclaje y decidir si descansar.",state)
    distinct_sessions = {s.get("number"):max(s.get("suds_before",0),s.get("suds_after",0),s.get("peak_suds",0)) for s in (sessions or [])}
    for n,value in (session_peaks or {}).items(): distinct_sessions[int(n)]=max(distinct_sessions.get(int(n),0),value)
    if suds: distinct_sessions[state.get("number",1)]=max(distinct_sessions.get(state.get("number",1),0),peak)
    complete_suds=[distinct_sessions[n] for n in sorted(distinct_sessions) if n is not None]
    if len(complete_suds)>=2 and all(v>=8 for v in complete_suds[-2:]): flag("specialist_only","orange","Malestar elevado en dos sesiones: continuar solo con especialista.",complete_suds[-2:])
    values=[v for k,v in answers.items() if k not in ("consent","session") and type(v) in (int,str)]
    if values and sum(v in MISSING for v in values)/len(values)>.4: flag("missing_high","yellow","Más de 40% sin respuesta: información insuficiente, sin convertir faltantes a cero.",{"count":len(values),"missing":sum(v in MISSING for v in values)})
    if type(answers.get("MFC6")) is int and 2<=answers["MFC6"]<=3 and answers.get("MD13")==0: flag("inconsistency_sleep","yellow","Diferencia entre función de evitar dormir y detonante de pesadillas: aclarar en entrevista.",{"MFC6":answers["MFC6"],"MD13":0})
    days={e["date"] for e in (ema or []) if e.get("emotion") in ("triste","tristeza","sad","verguenza","vergüenza","shame") and e.get("intensity",0)>=9}
    for d in sorted(days,reverse=True):
        dt=date.fromisoformat(d)
        if all((dt-timedelta(days=i)).isoformat() in days for i in (1,2)):
            flag("ema_persistent_distress","yellow","Tristeza o vergüenza intensas durante tres días consecutivos: revisar con especialista.",d); break
    return flags

FUNCTIONS = [("F1",[1,2],"Entumecimiento o desconexión","Depresión primaria o abstinencia"),("F2",[3,4],"Vergüenza o sensación de impotencia","Búsqueda de estatus"),("F3",[5],"Alerta ante amenaza","Entorno realmente peligroso"),("F4",[6],"Evitar dormir","Jornadas laborales"),("F5",[7],"Funciones sexuales","Búsqueda de sensaciones"),("F6",[8],"Rendimiento laboral","Rendimiento laboral"),("F7",[9],"Control de peso","Presión estética"),("F8",[10],"Concentración e inquietud","TDAH u otras dificultades atencionales por valorar"),("F9",[11],"Pertenencia social","Contexto social o soledad"),("F10",[12],"Evitar el bajón","Dependencia fisiológica")]

def hypotheses(answers):
    output=[]
    for code,items,label,alternative in FUNCTIONS:
        evidence={f"MFC{i}":answers[f"MFC{i}"] for i in items if type(answers.get(f"MFC{i}")) is int and 2<=answers[f"MFC{i}"]<=3}
        principal=answers.get("MFC-R") in {f"MFC{i}" for i in items}
        if evidence or principal or code in ("F6","F8","F10"):
            output.append({"function":code,"label":label,"reported_active":bool(evidence or principal),"principal":principal,"evidence":evidence,"non_trauma_alternative":alternative,"confidence":"insuficiente","experimental":True,"statement":"Función autorreportada para contrastar en entrevista. No establece trauma, causalidad ni diagnóstico; no hay calibración clínica."})
    return output

def progress(answers,sessions=None,session_peaks=None):
    groups={"safety":["S1","S2","S3","VE1","VE2","VE3","VE4","VE5","VE6"],"functions":[f"MFC{i}" for i in range(1,13)]+["MFC-R","MFC-I"],"context":[f"CX{i}" for i in range(1,18)],"triggers":[f"MD{i}" for i in range(1,25)],"timeline":[f"LT{i}" for i in range(1,8)],"chain":[f"CB{i}" for i in range(11)]}
    flags=evaluate(answers,sessions=sessions,session_peaks=session_peaks)
    blocked=[f["code"] for f in flags if f["severity"] in ("red","orange") or f["code"]=="distress_high"]
    state=answers.get("session",{"number":1,"phase":"active"})
    return {"session":state.get("number",1),"current_session":state.get("number",1),"phase":state.get("phase","active"),"sessions":sessions or [],"counts":{name:{"answered":sum(k in answers for k in keys),"total":len(keys)} for name,keys in groups.items()},"blocked":bool(blocked),"block_reasons":blocked,"safety_ready":safety_ready(answers),"completed":state.get("phase")=="complete" and state.get("number")==3}
