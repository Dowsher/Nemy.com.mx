# Nemy community API v1

Integration: `attach_community(app, db, authorize_admin, sender=None, moderator=None)`.
Production uses real configured sender/AI. Injection parameters are only for isolated tests.
Clinical accounts, answers, sessions and permissions remain separate. Cookie `nemy_session`, HTTPOnly, Secure when `TRAZA_SECURE_COOKIE=1`, SameSite Strict, 7 days.

## Access

- GET `/api/community/config`: `{otp_available,moderation_available,topics:[{id,label}],reactions:[support,relate,thanks],avatars:[violet,mint,coral,blue,sun],otp_digits:4,otp_expires_in:300,phone_region:'MX',privacy}`.
- POST `/api/community/auth/request-code`: `{phone,adult:true,consent:true,request_id:UUID}` → `{challenge_id,expires_in,resend_after,masked_phone}`. Currently Mexico +52 and ten digits. Phone is never a username or public field. No code is returned or logged. Unavailable sender returns503 honestly.
- Response also includes `delivery_status:'sent'|'uncertain',notice`. An uncertain delivery keeps the challenge usable for5minutes if the user receives its code; repeat request_id never resends. Explicit known failure does not claim delivery. Another issuance supersedes the old challenge.
- POST `/api/community/auth/verify-code`: `{challenge_id:UUID,code:'1234'}` → `{user}` and cookie. Five attempts max per challenge; expiry5min; resend cooldown60sec. Attempt denials persist before response. Used/expired/locked/superseded codes cannot sign in. Rate limits persist HMAC keys, no raw IP.
- GET `/api/community/auth/me`: `{user:null|User}`.
- POST `/api/community/auth/logout`: `{}` → `{ok:true}`.
- GET `/api/community/profile`: `{user}`; PATCH exact `{alias,bio,avatar}` → `{user}`.
- DELETE `/api/community/profile`: `{}` deletes membership, own posts, own comments/reactions, sessions and OTP rows. Deletes comments under deleted own posts too. Prior downloaded material/backups are unaffected.
- User: `{id,alias,bio,avatar,created_at}`. Alias3–32 characters; bio0–300. There is no phone in public/profile/admin JSON.

## Community (members only)

- GET `/api/community/posts?topic=&cursor=&limit=10&mine=1` → `{posts,next_cursor}`. `mine=1` optional. Limit1–30. Cursor signed. Topics `emotions`,`addictions`,`stagnation`.
- POST `/api/community/posts` exact `{request_id:UUID,topic,body}` → `{post}`. Body1–5000. Idempotent per member/request id. Original posts do not call AI.
- GET `/api/community/posts/{id}` → `{post}`; PATCH exact `{body,topic}`, DELETE `{}` only own.
- POST `/api/community/posts/{id}/reaction` exact `{kind:'support'|'relate'|'thanks'}` toggles own reaction and returns `{post}`.
- Post: `{id,topic,body,author:{id,alias,avatar},created_at,updated_at,reactions:{support,relate,thanks},my_reactions:[],comment_count,can_edit,can_delete}`.
- GET `/api/community/posts/{id}/comments` → `{comments,has_more}`. Latest200 visible comments, shown oldest-to-newest within that window; `has_more:true` means older comments exist. Approved comments plus own pending/intervened, with disabled/blocked accounts excluded before applying the limit. UI states the window honestly and does not offer an unimplemented history button.
- POST samepath exact `{request_id:UUID,body,ai_consent:true}` → `{comment,status,notice}`. Body1–2000. Comment statuses `approved`,`intervened`,`pending`.
- POST `/api/community/comments/{id}/retry` exact `{ai_consent:true}` retries a pending own comment. DELETE sameid exact `{}` removes own.
- Comment: `{id,post_id,body,author,created_at,updated_at,status,can_delete}`. Only author/admin additionally receive `notice,category`.
- The provider gets comment+up to300characters of public-to-members parent context, no alias or phone. Notice must mention this. The original post is never changed or judged by comment moderation.
- Failed moderation persists pending with clear retry notice; pending text is not published to others. Profanity alone and expressions of distress are not grounds for intervention. Specific attacks, threats, hate, encouragement of self-harm, directed sexual harassment and third-party private data may be held, with private explanation.
- POST `/api/community/reports`: `{target_type:'post'|'comment',target_id:UUID,reason:5..500chars}` → `{ok:true}`.
- POST `/api/community/blocks`: `{member_id:UUID}` → `{ok:true}`. GET → `{blocks:[{id,alias,avatar}]}`. DELETE `/blocks/{id}` `{}` unblocks. Blocks isolate the two accounts' posts/comments.

## Private administrator

Every endpoint calls the existing admin+password+MFA callback. No community cookie substitutes for staff auth.

- GET `/api/admin/community?status=pending|intervened|approved|all&limit=25&cursor=...` → `{summary:{members,posts,comments,pending,intervened,reactions,reports},comments:[Comment],reports:[{id,target_type,target_id,reason,created_at}],next_cursor}`.
- GET `/api/admin/community/posts/{id}` → `{post}`, including disabled author's content for review. Access audited.
- PATCH `/api/admin/community/comments/{id}` exact `{action:'approve'|'intervene',reason:3..280chars}` → `{comment}`.
- POST `/api/admin/community/members/{id}/status`: `{disabled:bool,reason:3..280chars}` → `{ok:true}`; disabling revokes member sessions.

## Environment

`NEMY_OTP_SENDER_URL=http://127.0.0.1:3247` and `NEMY_OTP_SENDER_TOKEN` (private random bearer).
Sidecar POST `/otp/send` exact `{request_id,phone,code,expires_in:300,brand:'Nemy'}`. No bot/session changes from this module.
Existing `OPENAI_API_KEY` and optional `NEMY_COMMENT_MODEL` (defaults to existing `TRAZA_AI_MODEL`, then `gpt-5.4-mini`). `store:false`, max600 output tokens, reasoning low, timeout25s, fixed JSONschema.
JSON writes rely on parent app origin/content-type/body-limit middleware. No uploads, HTML processing, automatic post moderation, outbound social notifications or health-record linking.
Hourly opportunistic cleanup runs on membership activity/config requests: OTP challenges are removed24hours after expiry, expired sessions are removed, and rate buckets older than3days are removed. Deleting a membership also deletes every OTP row for its phone hash; previously made backups are outside that operation.
