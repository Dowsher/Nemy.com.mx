# Nemy: códigos de acceso por WhatsApp mediante Val

Este adaptador es un servicio nuevo y limitado al acceso de Nemy. No crea una
segunda sesión de WhatsApp ni modifica Val, sus conversaciones, sus grupos, sus
pedidos o sus registros. Usa el gateway ya vinculado en `127.0.0.1:3020`.

## Estado comprobado, 27 de octubre de 2026

- `banda-bot.service`: `/opt/banda-bot`, API local8000.
- `baileys-gateway.service`: `/opt/baileys-gateway`, API local3020.
- GET gateway`/health` informó `connected:true`.
- Gateway ya ofrece `POST /send-marketplace`, autorización
  `x-baileys-send-token`, encabezado `Idempotency-Key`64hex y cuerpo
  `{to:"+52…",text:"…"}`. Resuelve el destinatario en WhatsApp y conserva un
  recibo de envío por clave. Un resultado incierto pasa a revisión y no se
  reenvía ciegamente.
- El adaptador nuevo no requiere reiniciar esos servicios. Las pruebas incluidas
  son sintéticas y no contactan el gateway ni envían mensajes reales.

## Contrato con el servidor Nemy

`POST http://127.0.0.1:3247/otp/send`

Encabezado: `Authorization: Bearer <NEMY_OTP_SENDER_TOKEN>`.
`Content-Type: application/json`.

```json
{
  "request_id": "UUID canónico en minúsculas",
  "phone": "+52 más diez dígitos",
  "code": "cuatro dígitos como texto, incluidos ceros iniciales",
  "expires_in": 300,
  "brand": "Nemy"
}
```

Sólo permite estos cinco campos. No admite mensajes, imágenes, destinatarios de
grupo, URLs, otro propósito ni otra marca. México es el alcance del gateway
existente; no se promete entrega internacional.

Respuesta200: `{ok:true,request_id,status:"sent",duplicate:boolean}`. Significa
que el gateway confirmó el envío; no promete lectura o recepción en el equipo.

Errores tienen `detail:{code,message}`:

- 401`unauthorized`: token del adaptador incorrecto.
- 422`invalid_*`: solicitud no permitida; sin envío.
- 503`sender_unavailable`/`not_connected`: configuración o conexión no disponible.
  Si el gateway indicó explícitamente desconexión previa al envío, puede
  reintentarse la misma solicitud con el mismo código yUUID.
- 409`idempotency_conflict`: elUUID se reutilizó con datos diferentes.
- 409`delivery_requires_review`: resultado ambiguo o envío en curso. No cambiar
  la clave para reenviar automáticamente. Un código correcto que llegue por
  WhatsApp puede comprobarse por el backend dentro de su vigencia y presupuesto
  de intentos, sin afirmar que una entrega ambigua fue imposible.
- 429`send_limit`/`sender_busy`: espera antes de volver a solicitar.

El servidor Nemy genera el código, verifica su vigencia, limita intentos y
mantiene la sesión del usuario. El adaptador sólo lo envía. Nunca debe devolver
el código al navegador como alternativa a WhatsApp ni ofrecer un código de
prueba en producción.

## Plantilla y separación

Plantilla fija: «Nemy · Tu código de acceso es 1234. Vence en5minutos. No lo
compartas. Solicitado en nemy.com.mx. Si no lo pediste, ignora este mensaje.»

La clave del transporte esSHA256(`NEMY:OTP:`+UUID). Separa los trabajos de Nemy
de las claves de pedidos existentes y evita colisiones. El historial sólo guarda
UUID, huellasHMAC, clave de transporte, estado, fechas y códigos genéricos de
error; no guarda teléfono,OTP, mensaje ni cuerpo de solicitud. Retiene esa
bitácora hasta30días y poda oportunistamente.

Límites propios:2envíos simultáneos,30solicitudes/minuto,600/día,
3solicitudes por número cada15minutos. Los reintentos idénticos confirmados
devuelven el mismo resultado sin otro mensaje. Estos límites son independientes
de las tareas de Val. El backend también debe limitar IP, cuenta e intentos de
verificación del código de cuatro dígitos.

## Instalación por el responsable del despliegue

Archivo: `otp_gateway.py`. Dependencias ya presentes en `/opt/traza/venv`:
FastAPI, uvicorn yhttpx. Servicio propuesto: `nemy-otp.service`, usuario nuevo
sin inicio de sesión`nemy-otp`, directorio`/opt/nemy-otp/current`, datos privados
`/var/lib/nemy-otp`, puerto sólo loopback3247.

El servicio consume `/etc/nemy-otp/sender.env` con permisos restringidos. Variables
necesarias:

- `NEMY_OTP_ENABLED=1`.
- `NEMY_OTP_SENDER_TOKEN`: secreto nuevo y distinto para autenticar sólo al backend
  de Nemy ante este servicio.
- `BAILEYS_SEND_TOKEN`: valor ya existente en
  `/opt/baileys-gateway/.env`, variable del mismo nombre. Copiar internamente sin
  imprimirlo; no darlo a la aplicación pública, al navegador ni a su repositorio.
- `NEMY_OTP_DATA_DIR=/var/lib/nemy-otp`.
- `NEMY_OTP_GATEWAY_URL=http://127.0.0.1:3020`.

La aplicación Nemy recibe sólo`NEMY_OTP_SENDER_URL=http://127.0.0.1:3247/otp/send`
y`NEMY_OTP_SENDER_TOKEN`; no recibe el secreto genérico de Val. No modificar el
archivo de configuración, el código ni la unidad existente de Val/gateway.

GET`/health` informa únicamente estado y propósito; no envía códigos. El servicio
no incluyeUIde vinculación,QR, secretos ni acceso a mensajes entrantes.

## Pruebas

Desde este directorio:

```text
<python-del-entorno> -m unittest test_otp_gateway.py
```

Comprueban plantilla, códigos con ceros iniciales, aislamiento de propósito,
límites, autenticación, idempotencia tras reinicio, concurrencia, desconexión,
incertidumbre de entrega y ausencia de datos originales en la bitácora.

Una entrega real de extremo a extremo requiere un número autorizado por su
titular y una comprobación real del código recibido. No se ha realizado esa
prueba al preparar este adaptador.
