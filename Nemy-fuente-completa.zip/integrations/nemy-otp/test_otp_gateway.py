"""Synthetic OTP bridge acceptance; never contacts Val or sends WhatsApp."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest
import uuid

import httpx
from fastapi.testclient import TestClient

from otp_gateway import Config, OtpBridge, code_message, create_app


class BridgeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.config=Config('NEMY-test-token-'+('x'*40),'Val-test-token-'+('y'*40),Path(self.tmp.name))
        self.calls=[]
        self.gateway_status=200
        self.gateway_body={'ok':True}
        self.connected=True
        def transport(request):
            self.calls.append(request)
            if request.url.path=='/health':return httpx.Response(200,json={'connected':self.connected})
            return httpx.Response(self.gateway_status,json=self.gateway_body)
        self.transport=httpx.MockTransport(transport)
        self.app=create_app(self.config,self.transport)
        self.client=TestClient(self.app)
        self.addCleanup(self.client.close)
        self.headers={'Authorization':'Bearer '+self.config.token}
        self.payload={'request_id':str(uuid.uuid4()),'phone':'+523171234567','code':'0123','expires_in':300,'brand':'Nemy'}

    def send(self,payload=None):return self.client.post('/otp/send',json=payload or self.payload,headers=self.headers)
    def sends(self):return [r for r in self.calls if r.url.path=='/send-marketplace']

    def test_fixed_template_keeps_leading_zero_and_names_the_real_origin(self):
        r=self.send();self.assertEqual(r.status_code,200,r.text)
        request=self.sends()[0];body=json.loads(request.content)
        self.assertEqual(body,{'to':self.payload['phone'],'text':code_message('0123')})
        self.assertIn('nemy.com.mx',body['text']);self.assertIn('5 minutos',body['text'])
        self.assertEqual(request.headers['x-baileys-send-token'],self.config.gateway_token)
        self.assertEqual(request.headers['idempotency-key'],hashlib.sha256(('NEMY:OTP:'+self.payload['request_id']).encode()).hexdigest())
        self.assertNotIn(self.config.token,request.content.decode())

    def test_repeat_success_is_idempotent_even_after_bridge_restart_and_disconnection(self):
        self.assertEqual(self.send().status_code,200)
        self.connected=False
        with TestClient(create_app(self.config,self.transport)) as again:
            r=again.post('/otp/send',json=self.payload,headers=self.headers)
        self.assertEqual(r.status_code,200);self.assertTrue(r.json()['duplicate'])
        self.assertEqual(len(self.sends()),1)

    def test_same_request_cannot_change_phone_or_code(self):
        self.assertEqual(self.send().status_code,200)
        for change in ({'code':'9999'},{'phone':'+523171234568'}):
            self.assertEqual(self.send({**self.payload,**change}).status_code,409)
        self.assertEqual(len(self.sends()),1)

    def test_unauthorized_and_disabled_never_call_the_gateway(self):
        self.assertEqual(self.client.post('/otp/send',json=self.payload).status_code,401)
        self.assertEqual(self.client.post('/otp/send',json=self.payload,headers={'Authorization':'Bearer bad'}).status_code,401)
        with TestClient(create_app(Config('', '',Path(self.tmp.name)/'disabled',enabled=False),self.transport))as client:
            self.assertEqual(client.post('/otp/send',json=self.payload,headers=self.headers).status_code,503)
            self.assertFalse(client.get('/health').json()['ready'])
        self.assertEqual(self.calls,[])
        self.assertFalse((Path(self.tmp.name)/'disabled').exists())

    def test_only_nemy_login_purpose_and_exact_phone_shape_are_allowed(self):
        changes=[{'text':'anything'},{'brand':'Other'},{'expires_in':301},{'expires_in':300.0},{'code':1234},{'code':'12345'},{'phone':'3171234567'},{'phone':'+12025550123'},{'request_id':'not-a-uuid'}]
        for change in changes:
            with self.subTest(change=change):self.assertEqual(self.send({**self.payload,**change}).status_code,422)
        self.assertEqual(self.calls,[])

    def test_unexpected_gateway_url_disables_the_bridge(self):
        with TestClient(create_app(Config(self.config.token,self.config.gateway_token,Path(self.tmp.name)/'foreign','http://example.com'),self.transport))as client:
            self.assertEqual(client.post('/otp/send',json=self.payload,headers=self.headers).status_code,503)
        self.assertFalse((Path(self.tmp.name)/'foreign').exists())

    def test_json_size_and_format_have_bounds(self):
        self.assertEqual(self.client.post('/otp/send',content='x',headers=self.headers).status_code,415)
        self.assertEqual(self.client.post('/otp/send',content='x'*2049,headers={**self.headers,'Content-Type':'application/json'}).status_code,413)
        self.assertEqual(self.client.post('/otp/send',content='{',headers={**self.headers,'Content-Type':'application/json'}).status_code,422)
        self.assertEqual(self.calls,[])

    def test_disconnected_channel_does_not_claim_delivery_or_create_a_job(self):
        self.connected=False;r=self.send()
        self.assertEqual(r.status_code,503);self.assertEqual(r.json()['detail']['code'],'not_connected')
        self.assertEqual(len(self.sends()),0)
        with self.app.state.bridge.connect()as con:self.assertEqual(con.execute('select count(*) from deliveries').fetchone()[0],0)

    def test_uncertain_delivery_never_resends_with_same_or_new_transport_key(self):
        self.gateway_status=502;self.gateway_body={'error':'transport failure'}
        self.assertEqual(self.send().status_code,409)
        self.gateway_status=200;self.gateway_body={'ok':True}
        self.assertEqual(self.send().status_code,409)
        self.assertEqual(len(self.sends()),1)
        with self.app.state.bridge.connect()as con:self.assertEqual(con.execute('select state from deliveries').fetchone()[0],'review')

    def test_timeout_is_not_treated_as_proof_of_no_send(self):
        def transport(request):
            if request.url.path=='/health':return httpx.Response(200,json={'connected':True})
            raise httpx.ReadTimeout('synthetic timeout')
        self.app.state.bridge.transport=httpx.MockTransport(transport)
        self.assertEqual(self.send().status_code,409)
        self.assertEqual(self.send().json()['detail']['code'],'delivery_requires_review')

    def test_explicit_pre_send_disconnect_can_retry_the_same_id(self):
        self.gateway_status=503;self.gateway_body={'error':'not_connected'}
        self.assertEqual(self.send().status_code,503)
        self.gateway_status=200;self.gateway_body={'ok':True}
        self.assertEqual(self.send().status_code,200)
        self.assertEqual(len(self.sends()),2)
        self.assertEqual(self.sends()[0].headers['idempotency-key'],self.sends()[1].headers['idempotency-key'])

    def test_gateway_auth_failure_is_safe_generic_and_not_publicly_leaked(self):
        self.gateway_status=401;self.gateway_body={'error':'secret test gateway detail'}
        r=self.send();self.assertEqual(r.status_code,503)
        self.assertNotIn('secret test',r.text)
        self.assertNotIn(self.config.gateway_token,r.text)

    def test_phone_budget_keeps_login_from_overloading_existing_val_work(self):
        for _ in range(3):
            self.assertEqual(self.send({**self.payload,'request_id':str(uuid.uuid4())}).status_code,200)
        self.assertEqual(self.send({**self.payload,'request_id':str(uuid.uuid4())}).status_code,429)
        self.assertEqual(len(self.sends()),3)

    def test_ledger_does_not_store_codes_phones_or_message_bodies(self):
        self.assertEqual(self.send().status_code,200)
        with self.app.state.bridge.connect()as con:
            row=dict(con.execute('select * from deliveries').fetchone())
        self.assertEqual(set(row),{'request_id','fingerprint','recipient_key','transport_key','state','created_at','updated_at','error_code'})
        self.assertNotIn(self.payload['phone'],json.dumps(row))
        self.assertNotIn(code_message(self.payload['code']),json.dumps(row))
        if os.name!='nt':self.assertEqual((self.app.state.bridge.path.stat().st_mode&0o777),0o600)

    def test_health_reports_channel_state_without_credentials_or_identity(self):
        r=self.client.get('/health');self.assertEqual(r.status_code,200);self.assertTrue(r.json()['ready'])
        self.assertEqual(set(r.json()),{'ok','ready','gateway_connected','purpose','digits','expires_in'})
        self.assertNotIn(self.config.token,r.text);self.assertNotIn(self.config.gateway_token,r.text)


class ConcurrentTests(unittest.IsolatedAsyncioTestCase):
    async def test_duplicate_inflight_id_has_only_one_transport_send(self):
        with tempfile.TemporaryDirectory()as tmp:
            config=Config('t'*40,'g'*40,Path(tmp));sends=[];entered=asyncio.Event();release=asyncio.Event()
            async def transport(request):
                if request.url.path=='/health':return httpx.Response(200,json={'connected':True})
                sends.append(request);entered.set();await release.wait();return httpx.Response(200,json={'ok':True})
            bridge=OtpBridge(config,httpx.MockTransport(transport))
            payload={'request_id':str(uuid.uuid4()),'phone':'+523171234567','code':'0123','expires_in':300,'brand':'Nemy'}
            first=asyncio.create_task(bridge.send(payload));await entered.wait()
            with self.assertRaises(Exception)as error:await bridge.send(payload)
            self.assertEqual(error.exception.status_code,409)
            release.set();self.assertTrue((await first)['ok']);self.assertEqual(len(sends),1)


if __name__=='__main__':unittest.main(verbosity=2)
