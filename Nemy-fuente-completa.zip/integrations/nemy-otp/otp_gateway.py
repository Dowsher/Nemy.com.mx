"""Purpose-limited Nemy login-code bridge over Val's existing loopback gateway.

This service does not open a WhatsApp session, consume incoming messages, change
Val's routing, or provide an arbitrary-message endpoint. No phone or code is
written to its SQLite ledger or logs. A delivery uncertainty is never retried
with a new transport key.
"""
from __future__ import annotations

import asyncio
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import sqlite3
import time
import uuid

import httpx
from fastapi import FastAPI, HTTPException, Request


@dataclass(frozen=True)
class Config:
    token: str
    gateway_token: str
    data_dir: Path
    gateway_url: str = "http://127.0.0.1:3020"
    enabled: bool = True

    @classmethod
    def environment(cls):
        return cls(
            os.environ.get("NEMY_OTP_SENDER_TOKEN", ""),
            os.environ.get("BAILEYS_SEND_TOKEN", ""),
            Path(os.environ.get("NEMY_OTP_DATA_DIR", "/var/lib/nemy-otp")),
            os.environ.get("NEMY_OTP_GATEWAY_URL", "http://127.0.0.1:3020").rstrip("/"),
            os.environ.get("NEMY_OTP_ENABLED", "0") == "1",
        )

    @property
    def ready(self):
        return self.enabled and len(self.token) >= 32 and len(self.gateway_token) >= 16 and self.gateway_url == "http://127.0.0.1:3020"


def fail(status, code, message):
    raise HTTPException(status, detail={"code": code, "message": message})


def code_message(code):
    return (f"Nemy · Tu código de acceso es {code}.\n"
            "Vence en 5 minutos. No lo compartas.\n"
            "Solicitado en nemy.com.mx. Si no lo pediste, ignora este mensaje.")


class OtpBridge:
    def __init__(self, config: Config, transport=None):
        self.config, self.transport = config, transport
        self.path = config.data_dir / "deliveries.sqlite"
        self.lock = asyncio.Lock()
        self.active = 0
        if config.ready:
            config.data_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
            with self.connect() as con:
                con.executescript("""
                    CREATE TABLE IF NOT EXISTS deliveries(
                        request_id TEXT PRIMARY KEY, fingerprint TEXT NOT NULL,
                        recipient_key TEXT NOT NULL, transport_key TEXT NOT NULL,
                        state TEXT NOT NULL, created_at REAL NOT NULL,
                        updated_at REAL NOT NULL, error_code TEXT);
                    CREATE INDEX IF NOT EXISTS deliveries_created ON deliveries(created_at);
                    CREATE INDEX IF NOT EXISTS deliveries_recipient ON deliveries(recipient_key,created_at);
                """)
            os.chmod(self.path, 0o600)

    @contextmanager
    def connect(self):
        con = sqlite3.connect(self.path, timeout=10)
        con.row_factory = sqlite3.Row
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("PRAGMA secure_delete=ON")
        try:
            with con:
                yield con
        finally:
            con.close()

    def authorize(self, header):
        if not self.config.ready:
            fail(503, "sender_unavailable", "El envío de códigos no está disponible ahora.")
        expected = "Bearer " + self.config.token
        if not isinstance(header, str) or not hmac.compare_digest(header.encode(), expected.encode()):
            fail(401, "unauthorized", "Acceso no autorizado.")

    def fingerprint(self, value):
        return hmac.new(self.config.token.encode(), json.dumps(value, sort_keys=True, separators=(",", ":")).encode(), hashlib.sha256).hexdigest()

    @staticmethod
    def validate(payload):
        if not isinstance(payload, dict) or set(payload) != {"request_id", "phone", "code", "expires_in", "brand"}:
            fail(422, "invalid_payload", "La solicitud no tiene el formato permitido.")
        request_id = payload["request_id"]
        try:
            if not isinstance(request_id, str) or str(uuid.UUID(request_id)) != request_id or len(request_id) != 36:
                raise ValueError()
        except (ValueError, TypeError, AttributeError):
            fail(422, "invalid_request_id", "El envío necesita un identificador válido.")
        if not isinstance(payload["phone"], str) or not re.fullmatch(r"\+52\d{10}", payload["phone"]):
            fail(422, "invalid_phone", "Usa un número mexicano con código +52.")
        if not isinstance(payload["code"], str) or not re.fullmatch(r"[0-9]{4}", payload["code"]):
            fail(422, "invalid_code", "El código debe tener cuatro dígitos.")
        if type(payload["expires_in"]) is not int or payload["expires_in"] != 300 or payload["brand"] != "Nemy":
            fail(422, "invalid_purpose", "Sólo se permiten códigos de acceso de Nemy con vigencia de cinco minutos.")

    async def connected(self):
        if not self.config.ready:
            return False
        try:
            async with httpx.AsyncClient(transport=self.transport, timeout=3, trust_env=False) as client:
                response = await client.get(self.config.gateway_url + "/health")
                data = response.json() if len(response.content) <= 16384 else None
                return response.status_code == 200 and isinstance(data, dict) and data.get("connected") is True
        except (httpx.HTTPError, ValueError, TypeError):
            return False

    def _existing(self, con, request_id, fingerprint):
        row = con.execute("SELECT * FROM deliveries WHERE request_id=?", (request_id,)).fetchone()
        if row and not hmac.compare_digest(row["fingerprint"], fingerprint):
            fail(409, "idempotency_conflict", "Ese envío ya corresponde a otro código o número.")
        if row and row["state"] == "sent":
            return {"ok": True, "request_id": request_id, "status": "sent", "duplicate": True}
        if row and row["state"] in {"review", "sending"}:
            # Inflight or interrupted sends may already have reached WhatsApp.
            fail(409, "delivery_requires_review", "El envío está en comprobación. Espera antes de solicitar otro código.")
        return None

    async def send(self, payload):
        self.validate(payload)
        if not self.config.ready:
            fail(503, "sender_unavailable", "El envío de códigos no está disponible ahora.")
        request_id = payload["request_id"]
        fingerprint = self.fingerprint(payload)
        recipient_key = self.fingerprint({"purpose": "recipient", "phone": payload["phone"]})
        transport_key = hashlib.sha256(("NEMY:OTP:" + request_id).encode()).hexdigest()
        now = time.time()
        # Retries acknowledged previously can succeed even if Val is now offline.
        with self.connect() as con:
            old = self._existing(con, request_id, fingerprint)
            if old:
                return old
        if not await self.connected():
            fail(503, "not_connected", "El canal de WhatsApp no está conectado ahora.")
        async with self.lock:
            if self.active >= 2:
                fail(429, "sender_busy", "Hay otros códigos en envío. Espera unos segundos.")
            with self.connect() as con:
                con.execute("BEGIN IMMEDIATE")
                old = self._existing(con, request_id, fingerprint)
                if old:
                    return old
                existing = con.execute("SELECT state FROM deliveries WHERE request_id=?", (request_id,)).fetchone()
                if not existing:
                    day = con.execute("SELECT count(*) FROM deliveries WHERE created_at>=?", (now - 86400,)).fetchone()[0]
                    minute = con.execute("SELECT count(*) FROM deliveries WHERE created_at>=?", (now - 60,)).fetchone()[0]
                    recipient = con.execute("SELECT count(*) FROM deliveries WHERE recipient_key=? AND created_at>=?", (recipient_key, now - 900)).fetchone()[0]
                    if day >= 600 or minute >= 30 or recipient >= 3:
                        fail(429, "send_limit", "Espera antes de pedir otro código.")
                    con.execute("INSERT INTO deliveries VALUES(?,?,?,?,?,?,?,NULL)", (request_id, fingerprint, recipient_key, transport_key, "sending", now, now))
                else:
                    con.execute("UPDATE deliveries SET state='sending',updated_at=?,error_code=NULL WHERE request_id=?", (now, request_id))
                # The ledger contains no phone, code, message or original payload.
                con.execute("DELETE FROM deliveries WHERE created_at<?", (now - 30 * 86400,))
            self.active += 1
        try:
            async with httpx.AsyncClient(transport=self.transport, timeout=12, trust_env=False) as client:
                response = await client.post(
                    self.config.gateway_url + "/send-marketplace",
                    headers={"x-baileys-send-token": self.config.gateway_token, "Idempotency-Key": transport_key},
                    json={"to": payload["phone"], "text": code_message(payload["code"])},
                )
            data = response.json() if len(response.content) <= 16384 else None
            if response.status_code == 200 and isinstance(data, dict) and data.get("ok") is True:
                self.outcome(request_id, "sent")
                return {"ok": True, "request_id": request_id, "status": "sent", "duplicate": False}
            try:
                code = data.get("error") if isinstance(data, dict) else None
            except (ValueError, TypeError):
                code = None
            if response.status_code == 503 and code == "not_connected":
                self.outcome(request_id, "not_sent", "not_connected")
                fail(503, "not_connected", "El canal de WhatsApp se desconectó antes del envío.")
            if response.status_code in {401, 403}:
                self.outcome(request_id, "not_sent", "gateway_unauthorized")
                fail(503, "sender_unavailable", "El envío de códigos no está disponible ahora.")
            # The existing gateway itself remembers uncertain message keys. Do not
            # reinterpret 409/502/timeouts as proof that a recipient saw nothing.
            self.outcome(request_id, "review", "delivery_uncertain")
            fail(409, "delivery_requires_review", "No pudimos confirmar la entrega. Espera antes de pedir otro código.")
        except (httpx.HTTPError, ValueError, TypeError):
            self.outcome(request_id, "review", "delivery_uncertain")
            fail(409, "delivery_requires_review", "No pudimos confirmar la entrega. Espera antes de pedir otro código.")
        finally:
            async with self.lock:
                self.active -= 1

    def outcome(self, request_id, state, error=None):
        with self.connect() as con:
            con.execute("UPDATE deliveries SET state=?,updated_at=?,error_code=? WHERE request_id=?", (state, time.time(), error, request_id))


def create_app(config=None, transport=None):
    bridge = OtpBridge(config or Config.environment(), transport)
    app = FastAPI(title="Nemy OTP bridge", docs_url=None, redoc_url=None, openapi_url=None)
    app.state.bridge = bridge

    @app.get("/health")
    async def health():
        connected = await bridge.connected()
        return {"ok": True, "ready": bridge.config.ready and connected, "gateway_connected": connected,
                "purpose": "nemy-login-only", "digits": 4, "expires_in": 300}

    @app.post("/otp/send")
    async def send(request: Request):
        bridge.authorize(request.headers.get("authorization"))
        if request.headers.get("content-type", "").split(";", 1)[0].strip() != "application/json":
            fail(415, "json_required", "Se requiere JSON.")
        raw = await request.body()
        if len(raw) > 2048:
            fail(413, "payload_too_large", "La solicitud es demasiado grande.")
        try:
            payload = json.loads(raw)
        except (ValueError, TypeError, RecursionError):
            fail(422, "invalid_json", "Se requiere JSON válido.")
        return await bridge.send(payload)

    return app


app = create_app()
