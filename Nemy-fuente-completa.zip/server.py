"""TRAZA restricted pilot: invitations, consent, clinician review and encrypted data."""
import argparse
import base64
from collections import defaultdict, deque
from datetime import datetime, timezone, timedelta, date
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import struct
import time
import uuid
from urllib.parse import quote, urlparse

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, Response
from starlette.middleware.base import BaseHTTPMiddleware

from db import Database
from engine import InputError, validate_answers, evaluate, hypotheses, progress, safety_ready, trauma_key, SUBSTANCES

VERSION="10.2.0"
COOKIE="traza_session"
ROOT=Path(__file__).resolve().parent
DEFAULT_CONFIG={"mode":"restricted-pilot","enrollment_open":False,"privacy_notice":"","privacy_contact":"","clinical_name":"","clinical_license":"","service_hours":"","guard_contact":"","readiness":{key:False for key in ("privacy","clinician","guard","licenses","clinical_validation")},"instruments":[],"crisis_resources":[{"name":"Emergencias México","phone":"911","url":"tel:911"},{"name":"Línea de la Vida","phone":"800 911 2000","url":"https://www.gob.mx/conasama/articulos/linea-de-la-vida-800-911-2000?oai_link_source=model_response_hotline"}]}
AUTH_LIMIT=defaultdict(deque)

def now_iso(): return datetime.now(timezone.utc).isoformat()
def digest(value): return hashlib.sha256(value.encode()).hexdigest()
def password_hash(password):
    salt=secrets.token_bytes(16)
    derived=hashlib.scrypt(password.encode(),salt=salt,n=65536,r=8,p=1,dklen=32,maxmem=128*1024*1024)
    return "scrypt$65536$8$1$"+salt.hex()+"$"+derived.hex()
def password_check(password,encoded):
    try:
        _,n,r,p,salt,expected=encoded.split("$")
        actual=hashlib.scrypt(password.encode(),salt=bytes.fromhex(salt),n=int(n),r=int(r),p=int(p),dklen=32,maxmem=256*1024*1024)
        return hmac.compare_digest(actual.hex(),expected)
    except (ValueError,TypeError): return False
FAKE_PASSWORD=password_hash(secrets.token_urlsafe(24))

def totp(secret,counter=None):
    counter=int(time.time()//30) if counter is None else counter
    key=base64.b32decode(secret+"="*((8-len(secret)%8)%8))
    value=hmac.new(key,struct.pack(">Q",counter),hashlib.sha1).digest()
    pos=value[-1]&15
    return str((struct.unpack(">I",value[pos:pos+4])[0]&0x7fffffff)%1000000).zfill(6)
def check_totp(secret,code,last=-1):
    if not isinstance(code,str) or not re.fullmatch(r"\d{6}",code): return None
    current=int(time.time()//30)
    for c in (current-1,current,current+1):
        if c>last and hmac.compare_digest(totp(secret,c),code): return c
    return None

def safe_username(value):
    if not isinstance(value,str) or not re.fullmatch(r"[A-Za-z0-9_.-]{3,64}",value): raise HTTPException(422,"Usa un alias de 3 a 64 caracteres: letras, números, punto, guion o guion bajo.")
    return value.strip()
def safe_password(value):
    if not isinstance(value,str) or not 12<=len(value)<=256: raise HTTPException(422,"La contraseña debe tener entre 12 y 256 caracteres.")
    return value
def limit(key,max_attempts=12,window=900):
    q=AUTH_LIMIT[key]; now=time.time()
    while q and q[0]<now-window: q.popleft()
    if len(q)>=max_attempts: raise HTTPException(429,"Demasiados intentos. Espera 15 minutos.")
    q.append(now)
    if len(AUTH_LIMIT)>10000:
        for k in list(AUTH_LIMIT)[:5000]:
            if not AUTH_LIMIT[k] or AUTH_LIMIT[k][-1]<now-window: AUTH_LIMIT.pop(k,None)

def public_user(db,row):
    result={"id":row["id"],"username":db.decrypt(row["username_enc"]),"role":row["role"],"mfa_required":row["role"]!="participant","mfa_enabled":bool(row["mfa_enabled"]),"must_change_password":bool(row["must_change"])}
    if row["role"]=="clinician" and row["clinical_profile"]: result["clinical_profile"]=db.decrypt(row["clinical_profile"])
    return result
def audit(con,actor,action,subject=None,outcome="ok"):
    # No health, identity, notes, tokens, passwords or network addresses in audit.
    con.execute("INSERT INTO audit(at,actor,action,subject,outcome) VALUES(?,?,?,?,?)",(now_iso(),digest(actor)[:20] if actor else None,action,digest(subject)[:20] if subject else None,outcome))
def get_config(db,con):
    row=con.execute("SELECT payload FROM config WHERE id=1").fetchone()
    return db.decrypt(row[0]) if row else json.loads(json.dumps(DEFAULT_CONFIG))
def ready(config):
    return all(config["readiness"].values()) and all(config.get(k,"").strip() for k in ("privacy_notice","privacy_contact","clinical_name","clinical_license","service_hours","guard_contact"))
def empty_record(): return {"answers":{},"ema":[],"review":{"status":"pending"},"flags":[],"sessions":[],"session_started_at":None,"alert_resolutions":{},"current_flag_ids":{},"session_peaks":{}}
def load_record(db,con,uid):
    row=con.execute("SELECT * FROM records WHERE user_id=?",(uid,)).fetchone()
    return (db.decrypt(row["payload"]),row["revision"],row["updated_at"]) if row else (empty_record(),0,None)
def merged_flags(record):
    current=evaluate(record["answers"],record["ema"],record["sessions"],record.get("session_peaks",{}))
    # Preserve original safety evidence until a clinician resolves it.
    by_id={f["id"]:f for f in record.get("flags",[])}
    previous=record.get("current_flag_ids",{})
    present={}
    for flag in current:
        base=flag["id"]
        occurrence=previous.get(base,base)
        if base not in previous and occurrence in by_id: occurrence=secrets.token_hex(9)
        flag["id"]=occurrence
        present[base]=occurrence
        by_id[occurrence]=flag
    record["current_flag_ids"]=present
    for flag in by_id.values():
        if flag["id"] in record.get("alert_resolutions",{}): flag["status"]="resolved"
    return list(by_id.values())
def save_record(db,con,uid,record,revision):
    stamp=now_iso()
    encrypted=db.encrypt(record)
    con.execute("INSERT INTO records(user_id,revision,payload,updated_at) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET revision=excluded.revision,payload=excluded.payload,updated_at=excluded.updated_at",(uid,revision,encrypted,stamp))
    con.execute("INSERT INTO record_versions(user_id,revision,payload,created_at) VALUES(?,?,?,?)",(uid,revision,encrypted,stamp))
def public_record(record,revision):
    review=record.get("review",{"status":"pending"})
    view={"status":review.get("status","pending")}
    if review.get("status")=="approved": view.update({"patient_summary":review["patient_summary"],"approved_at":review.get("at")})
    p=progress(record["answers"],record["sessions"],record.get("session_peaks",{}))
    p["block_reasons"]=list(dict.fromkeys(p["block_reasons"]+[f["code"] for f in record.get("flags",[]) if f["severity"] in ("red","orange") and f.get("status")!="resolved"]))
    p["blocked"]=bool(p["block_reasons"])
    if record["sessions"]:
        last=record["sessions"][-1]
        if last.get("completed_at"):
            p["next_session_at"]=(datetime.fromisoformat(last["completed_at"])+timedelta(hours=24)).isoformat()
    return {"answers":record["answers"],"ema":record["ema"],"review":view,"revision":revision,"flags":[{k:v for k,v in f.items() if k!="evidence"} for f in record.get("flags",[])],"progress":p}

async def body(request,allowed=None):
    try: value=await request.json()
    except Exception: raise HTTPException(422,"JSON inválido.")
    if not isinstance(value,dict) or (allowed is not None and not set(value)<=set(allowed)): raise HTTPException(422,"Campos no permitidos.")
    return value

def create_app(data_dir=None,key_file=None):
    db=Database(data_dir,key_file)
    application=FastAPI(title="Nemy y TRAZA",version=VERSION,docs_url=None,redoc_url=None,openapi_url=None)
    application.state.db=db
    origin=os.environ.get("TRAZA_PUBLIC_ORIGIN","http://127.0.0.1:3230").rstrip("/")
    secure=os.environ.get("TRAZA_SECURE_COOKIE","1")=="1"
    allowed_origins={origin}
    if origin in ("http://127.0.0.1:3230","http://localhost:3230"): allowed_origins|={"http://127.0.0.1:3230","http://localhost:3230"}

    @application.middleware("http")
    async def security(request,call_next):
        if request.method in ("POST","PUT","PATCH","DELETE"):
            if request.headers.get("origin","").rstrip("/") not in allowed_origins: return JSONResponse({"detail":"Origen no permitido."},403)
            if "application/json" not in request.headers.get("content-type",""): return JSONResponse({"detail":"Se requiere JSON."},415)
            max_body=262144 if (request.url.path=="/api/journey/pdf" or request.url.path.startswith("/api/activity/sessions/") and request.url.path.endswith("/report")) else 131072
            try:
                if int(request.headers.get("content-length","0"))>max_body: return JSONResponse({"detail":"Solicitud demasiado grande."},413)
            except ValueError: return JSONResponse({"detail":"Longitud inválida."},400)
            raw=await request.body()
            if len(raw)>max_body: return JSONResponse({"detail":"Solicitud demasiado grande."},413)
        response=await call_next(request)
        response.headers.update({"Cache-Control":"no-store, private","Pragma":"no-cache","X-Content-Type-Options":"nosniff","Referrer-Policy":"no-referrer","X-Frame-Options":"DENY","Permissions-Policy":"camera=(), microphone=(), geolocation=()","Content-Security-Policy":"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"})
        if secure: response.headers["Strict-Transport-Security"]="max-age=31536000"
        return response

    def auth(request,role=None,setup=False,con=None):
        token=request.cookies.get(COOKIE,"")
        if not token or len(token)>128: raise HTTPException(401,"Inicia sesión.")
        def fetch(c):
            return c.execute("SELECT u.*,s.token_hash session_hash,s.mfa_verified,s.expires_at,s.created_at session_created FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND u.disabled=0",(digest(token),time.time())).fetchone()
        if con is None:
            with db.connection() as c: user=fetch(c)
        else: user=fetch(con)
        if user is None: raise HTTPException(401,"La sesión caducó. Inicia sesión.")
        if role and user["role"] not in ([role] if isinstance(role,str) else role): raise HTTPException(403,"Tu función no permite esta acción.")
        if not setup and user["role"]!="participant" and (user["must_change"] or not user["mfa_enabled"] or not user["mfa_verified"]): raise HTTPException(403,"Completa cambio de contraseña y segundo factor.")
        return user

    def new_session(con,user,mfa=False):
        token=secrets.token_urlsafe(32)
        duration=8*3600 if user["role"]=="participant" else 3600
        con.execute("DELETE FROM sessions WHERE expires_at<?",(time.time(),))
        con.execute("INSERT INTO sessions VALUES(?,?,?,?,?)",(digest(token),user["id"],time.time()+duration,int(mfa),time.time()))
        return token,duration
    def session_response(user,token,duration):
        response=JSONResponse({"user":public_user(db,user)})
        response.set_cookie(COOKIE,token,max_age=duration,httponly=True,secure=secure,samesite="strict",path="/")
        return response

    @application.get("/api/health")
    async def health(): return {"ok":True,"version":VERSION,"mode":"nemy-community-and-traza"}

    @application.get("/api/explore/schema")
    @application.post("/api/explore/analyze")
    async def retired_exploration():
        return JSONResponse({"detail":"El recorrido anterior se integró a los tres recorridos de TRAZA.","url":"/traza"},status_code=410)

    @application.get("/api/config")
    async def config_public():
        with db.connection() as con: cfg=get_config(db,con)
        cfg["guard_contact"]=""
        # Instruments have verified licensing/content metadata only, never unpublished items.
        bank=ROOT / "instruments.json"
        if bank.exists():
            try:
                content=json.loads(bank.read_text(encoding="utf-8"))
                instruments=content.get("instruments",[]) if isinstance(content,dict) else []
                cfg["instruments"]=[{key:value for key,value in i.items() if key in ("id","name","version","language","status","license_status","license_verified","source","source_url","sources","enabled","psychometrist_verified","pending_reason","reason","license","activation_requirements")} for i in instruments]
            except (ValueError,OSError): pass
        return cfg

    @application.get("/api/auth/me")
    async def me(request:Request): return {"user":public_user(db,auth(request,setup=True))}

    @application.post("/api/auth/login")
    async def login(request:Request):
        data=await body(request,("username","password","totp"))
        username=str(data.get("username",""))[:128]
        password=data.get("password","")
        if not isinstance(password,str) or len(password)>256: raise HTTPException(401,"Credenciales incorrectas.")
        ip=request.client.host if request.client else "unknown"
        # Nginx must overwrite this header; only the loopback proxy is trusted.
        if ip in ("127.0.0.1","::1"):
            forwarded=request.headers.get("x-forwarded-for","").strip()
            if forwarded and "," not in forwarded and len(forwarded)<=64: ip=forwarded
        limit("login-ip:"+ip,30); limit("login-user:"+digest(username.casefold()),12)
        with db.connection(transaction=True) as con:
            user=con.execute("SELECT * FROM users WHERE username_hash=?",(db.username_hash(username),)).fetchone()
            okay=password_check(password,user["password"] if user else FAKE_PASSWORD)
            if not okay or not user or user["disabled"]:
                audit(con,None,"login",outcome="denied")
                # HTTPException would roll back audit; explicit commit keeps only minimal event.
                con.commit()
                raise HTTPException(401,"Credenciales incorrectas.")
            verified=False
            if user["role"]!="participant" and user["mfa_enabled"]:
                code=data.get("totp")
                if not code: return JSONResponse({"mfa_required":True},200)
                counter=check_totp(db.decrypt(user["mfa_secret"]),code,user["last_totp"])
                if counter is None: raise HTTPException(401,"Credenciales incorrectas.")
                con.execute("UPDATE users SET last_totp=? WHERE id=?",(counter,user["id"]))
                verified=True
            token,duration=new_session(con,user,verified)
            audit(con,user["id"],"login")
        return session_response(user,token,duration)

    @application.post("/api/auth/logout")
    async def logout(request:Request):
        token=request.cookies.get(COOKIE,"")
        with db.connection(transaction=True) as con: con.execute("DELETE FROM sessions WHERE token_hash=?",(digest(token),))
        response=JSONResponse({"ok":True}); response.delete_cookie(COOKIE,path="/",secure=secure,httponly=True,samesite="strict"); return response

    @application.post("/api/auth/password")
    async def password_change(request:Request):
        data=await body(request,("current_password","new_password"))
        new=safe_password(data.get("new_password"))
        with db.connection(transaction=True) as con:
            user=auth(request,setup=True,con=con)
            limit("password:"+user["id"],8)
            if not isinstance(data.get("current_password"),str) or not password_check(data["current_password"],user["password"]): raise HTTPException(401,"Contraseña actual incorrecta.")
            if hmac.compare_digest(data["current_password"],new): raise HTTPException(422,"Elige una contraseña diferente.")
            con.execute("UPDATE users SET password=?,must_change=0 WHERE id=?",(password_hash(new),user["id"]))
            con.execute("DELETE FROM sessions WHERE user_id=? AND token_hash!=?",(user["id"],user["session_hash"]))
            audit(con,user["id"],"password_changed")
        return {"ok":True}

    @application.post("/api/auth/mfa/setup")
    async def mfa_setup(request:Request):
        await body(request,())
        with db.connection(transaction=True) as con:
            user=auth(request,role=("admin","clinician"),setup=True,con=con)
            if user["must_change"]: raise HTTPException(403,"Cambia primero la contraseña inicial.")
            if user["mfa_enabled"]: raise HTTPException(409,"El segundo factor ya está activo.")
            secret=base64.b32encode(secrets.token_bytes(20)).decode().rstrip("=")
            con.execute("UPDATE users SET mfa_pending=? WHERE id=?",(db.encrypt(secret),user["id"]))
        return {"secret":secret,"otpauth_url":"otpauth://totp/"+quote("TRAZA:"+db.decrypt(user["username_enc"]))+"?secret="+secret+"&issuer=TRAZA&algorithm=SHA1&digits=6&period=30"}

    @application.post("/api/auth/mfa/verify")
    async def mfa_verify(request:Request):
        data=await body(request,("code",))
        with db.connection(transaction=True) as con:
            user=auth(request,role=("admin","clinician"),setup=True,con=con)
            limit("mfa:"+user["id"],8)
            if user["must_change"] or not user["mfa_pending"]: raise HTTPException(403,"Prepara primero el segundo factor.")
            counter=check_totp(db.decrypt(user["mfa_pending"]),data.get("code"))
            if counter is None: raise HTTPException(401,"Código incorrecto.")
            con.execute("UPDATE users SET mfa_secret=mfa_pending,mfa_pending=NULL,mfa_enabled=1,last_totp=? WHERE id=?",(counter,user["id"]))
            con.execute("DELETE FROM sessions WHERE user_id=? AND token_hash!=?",(user["id"],user["session_hash"]))
            con.execute("UPDATE sessions SET mfa_verified=1 WHERE token_hash=?",(user["session_hash"],))
            audit(con,user["id"],"mfa_enabled")
        return {"ok":True}

    @application.post("/api/auth/redeem")
    async def redeem(request:Request):
        data=await body(request,("token","username","password"))
        username=safe_username(data.get("username")); password=safe_password(data.get("password"))
        token=data.get("token")
        if not isinstance(token,str) or not 20<=len(token)<=128: raise HTTPException(400,"Invitación inválida.")
        limit("redeem:"+(request.client.host if request.client else "unknown"),12)
        with db.connection(transaction=True) as con:
            inv=con.execute("SELECT * FROM invitations WHERE token_hash=? AND used_at IS NULL AND expires_at>?",(digest(token),time.time())).fetchone()
            if not inv: raise HTTPException(400,"Invitación inválida, usada o vencida.")
            cfg=get_config(db,con)
            if inv["role"]=="participant" and (not cfg["enrollment_open"] or not ready(cfg)): raise HTTPException(403,"El registro real aún está cerrado.")
            uid=uuid.uuid4().hex
            try:
                con.execute("INSERT INTO users(id,username_hash,username_enc,password,role,must_change,created_at) VALUES(?,?,?,?,?,?,?)",(uid,db.username_hash(username),db.encrypt(username),password_hash(password),inv["role"],0,now_iso()))
            except sqlite3.IntegrityError: raise HTTPException(409,"Ese alias no está disponible.")
            if inv["clinical_profile"]: con.execute("UPDATE users SET clinical_profile=? WHERE id=?",(inv["clinical_profile"],uid))
            con.execute("UPDATE invitations SET used_at=? WHERE token_hash=?",(time.time(),digest(token)))
            user=con.execute("SELECT * FROM users WHERE id=?",(uid,)).fetchone()
            session,duration=new_session(con,user)
            audit(con,uid,"invitation_redeemed")
        return session_response(user,session,duration)

    @application.get("/api/record")
    async def record_get(request:Request):
        user=auth(request,"participant")
        with db.connection() as con: record,revision,_=load_record(db,con,user["id"])
        return public_record(record,revision)

    @application.put("/api/record")
    async def record_put(request:Request):
        data=await body(request,("answers","revision"))
        if type(data.get("revision")) is not int or data["revision"]<0: raise HTTPException(422,"Revisión inválida.")
        try: patch=validate_answers(data.get("answers"))
        except InputError as exc: raise HTTPException(422,str(exc))
        with db.connection(transaction=True) as con:
            user=auth(request,"participant",con=con)
            cfg=get_config(db,con)
            if not cfg["enrollment_open"] or not ready(cfg): raise HTTPException(403,"El piloto no está habilitado para guardar datos reales.")
            record,revision,_=load_record(db,con,user["id"])
            if revision!=data["revision"]: raise HTTPException(409,"Otra sesión cambió las respuestas. Recarga antes de guardar.")
            old_answers=record["answers"]
            merged={**old_answers,**patch}
            if not merged.get("consent"): raise HTTPException(403,"Se requiere consentimiento adulto, de atención y almacenamiento, versión 1.0.")
            old_state=old_answers.get("session",{"number":1,"phase":"active"})
            state=merged.get("session",old_state.copy())
            if "session" in patch and state["number"]==old_state["number"]: state={**old_state,**state}; merged["session"]=state
            elif "session" not in merged: merged["session"]=state
            current_number=old_state.get("number",1)
            if state["number"] not in (current_number,current_number+1): raise HTTPException(409,"Sesión fuera de secuencia.")
            if state["number"]>current_number:
                if old_state.get("phase")!="complete" or not record["sessions"]: raise HTTPException(409,"Completa primero la sesión anterior.")
                completed=datetime.fromisoformat(record["sessions"][-1]["completed_at"])
                elapsed=datetime.now(timezone.utc)-completed
                if elapsed<timedelta(hours=24): raise HTTPException(409,"Deben pasar al menos 24 horas entre sesiones.")
                if elapsed>timedelta(days=7): raise HTTPException(409,"Pasaron más de 7 días. Solicita revisión del especialista antes de reiniciar.")
                if state.get("phase","active")!="active": raise HTTPException(409,"Inicia la nueva sesión antes de completarla.")
                for key in ("S1","S2","S3","VE1","VE2","VE3","VE4","VE5","VE6"):
                    if key not in patch: merged.pop(key,None)
                record["session_started_at"]=now_iso()
            if not record["session_started_at"]: record["session_started_at"]=now_iso()
            if old_state.get("phase")=="complete" and state["number"]==current_number and patch.keys()-{"consent","session","completed_blocks"}: raise HTTPException(409,"La sesión cerrada conserva sus respuestas. Inicia la siguiente sesión.")
            if old_state.get("phase")=="complete" and state["number"]==current_number and state.get("phase")!="complete": raise HTTPException(409,"Una sesión completada no puede reabrirse.")
            sensitive=any(trauma_key(k) for k in patch)
            assessment=any(k not in {"consent","session","S1","S2","S3","VE1","VE2","VE3","VE4","VE5","VE6","PS1","PS2","PS3","PS4","PS5","SR1","SR2","SR3","completed_blocks"} for k in patch)
            peaks=record.setdefault("session_peaks",{})
            peaks[str(state["number"])]=max(peaks.get(str(state["number"]),0),state.get("suds_before",0),state.get("suds_after",0))
            live_flags=evaluate(merged,record["ema"],record["sessions"],peaks)
            stop=any(f["severity"] in ("red","orange") or f["code"]=="distress_high" for f in live_flags) or any(f["severity"] in ("red","orange") and f.get("status")!="resolved" for f in record.get("flags",[]))
            if assessment and (not safety_ready(merged) or stop): raise HTTPException(403,"Completa seguridad y estado; con riesgo o malestar alto solo se permite seguridad.")
            if sensitive and state["number"]==1: raise HTTPException(403,"Los módulos sensibles comienzan en la segunda sesión.")
            if state.get("phase")=="complete" and old_state.get("phase")!="complete":
                if not safety_ready(merged) or "suds_after" not in state: raise HTTPException(422,"Completa seguridad, estado y termómetro final antes de cerrar.")
                record["sessions"].append({**state,"peak_suds":peaks[str(state["number"])],"started_at":record["session_started_at"],"completed_at":now_iso(),"safety_snapshot":{k:merged.get(k) for k in ("S1","S2","S3","VE1","VE3","VE4","VE5","VE6")}})
            record["answers"]=merged
            record["flags"]=merged_flags(record)
            record["review"]={"status":"pending"}
            save_record(db,con,user["id"],record,revision+1)
            audit(con,user["id"],"record_saved",user["id"])
        view=public_record(record,revision+1)
        return {"revision":revision+1,"flags":view["flags"],"progress":view["progress"],"review":view["review"]}

    @application.post("/api/ema")
    async def ema_save(request:Request):
        data=await body(request,("id","date","craving","emotion","intensity","trigger","context","sleep","used","substance","strategy"))
        try:
            if str(uuid.UUID(data.get("id","")))!=data.get("id"): raise ValueError()
            day=date.fromisoformat(data.get("date",""))
            if day>datetime.now(timezone.utc).date() or day<datetime.now(timezone.utc).date()-timedelta(days=35): raise ValueError()
            for k in ("craving","intensity"):
                if type(data.get(k)) is not int or not 0<=data[k]<=10: raise ValueError()
            enums={"emotion":{"calma","alegria","tristeza","verguenza","culpa","miedo","rabia","soledad","vacio","otra"},"trigger":{"ninguno","emocion","cuerpo","recuerdo","conflicto","lugar","fecha","critica","sustancia","dinero","sexual","otro"},"context":{"casa","trabajo","grupo","calle","otro"},"sleep":{"0-3","4-5","6-8","9+"},"strategy":{"ninguna","respirar","caminar","contactar","grupo","descansar","otra"},"substance":SUBSTANCES-{98,99}}
            for key,choices in enums.items():
                if key in data and (not isinstance(data[key],str) or data[key] not in choices): raise ValueError()
            if not all(k in data for k in ("emotion","trigger","context","sleep","used")) or type(data["used"]) is not bool: raise ValueError()
            if data["used"] and data.get("substance") in (None,"none"): raise ValueError()
        except (ValueError,TypeError,AttributeError): raise HTTPException(422,"Registro diario inválido. Usa las opciones disponibles sin relatos libres.")
        with db.connection(transaction=True) as con:
            user=auth(request,"participant",con=con)
            cfg=get_config(db,con)
            if not cfg["enrollment_open"] or not ready(cfg): raise HTTPException(403,"El piloto está cerrado.")
            record,revision,_=load_record(db,con,user["id"])
            if not record["answers"].get("consent"): raise HTTPException(403,"Se requiere consentimiento antes del registro diario.")
            for old in record["ema"]:
                if old["id"]==data["id"]:
                    if old!=data: raise HTTPException(409,"Este identificador ya contiene otro registro.")
                    return {"ok":True,"id":data["id"],"revision":revision,"idempotent":True}
            if len(record["ema"])>=120: raise HTTPException(409,"Límite del piloto alcanzado. Consulta a tu especialista.")
            record["ema"].append(data)
            record["flags"]=merged_flags(record); record["review"]={"status":"pending"}
            save_record(db,con,user["id"],record,revision+1); audit(con,user["id"],"ema_saved",user["id"])
        return {"ok":True,"id":data["id"],"revision":revision+1,"flags":public_record(record,revision+1)["flags"],"review":{"status":"pending"}}

    @application.get("/api/export")
    async def export(request:Request):
        user=auth(request,"participant")
        with db.connection(transaction=True) as con:
            record,revision,_=load_record(db,con,user["id"]); audit(con,user["id"],"record_exported",user["id"])
        exported={"tool":"TRAZA","version":VERSION,"exported_at":now_iso(),**public_record(record,revision)}
        return JSONResponse(exported,headers={"Content-Disposition":'attachment; filename="traza-mis-datos.json"'})

    @application.delete("/api/record")
    async def delete_record(request:Request):
        await body(request,())
        with db.connection(transaction=True) as con:
            user=auth(request,"participant",con=con)
            for table in ("records","record_versions","review_versions"): con.execute(f"DELETE FROM {table} WHERE user_id=?",(user["id"],))
            audit(con,None,"health_data_deleted")
        # Expire WAL frames so deleted encrypted ciphertext is not retained indefinitely.
        with db.connection() as con: con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        return {"ok":True,"message":"Datos activos de salud y versiones eliminados. Las copias de seguridad externas siguen su plazo de retención del aviso de privacidad."}

    @application.get("/api/staff/cases")
    async def cases(request:Request):
        user=auth(request,"clinician")
        with db.connection(transaction=True) as con:
            rows=con.execute("SELECT r.*,u.username_enc FROM records r JOIN users u ON u.id=r.user_id WHERE u.role='participant' ORDER BY r.updated_at DESC LIMIT 500").fetchall()
            cases=[]
            for row in rows:
                r=db.decrypt(row["payload"])
                cases.append({"id":row["user_id"],"username":db.decrypt(row["username_enc"]),"updated_at":row["updated_at"],"flags":public_record(r,row["revision"])["flags"],"status":r["review"]["status"],"progress":progress(r["answers"],r["sessions"],r.get("session_peaks",{}))})
            audit(con,user["id"],"case_list_viewed")
        return {"cases":cases}

    @application.get("/api/staff/cases/{uid}")
    async def case_detail(uid:str,request:Request):
        user=auth(request,"clinician")
        with db.connection(transaction=True) as con:
            person=con.execute("SELECT * FROM users WHERE id=? AND role='participant'",(uid,)).fetchone()
            if not person: raise HTTPException(404,"Caso no disponible.")
            r,rev,_=load_record(db,con,uid)
            review_history=[db.decrypt(row[0]) for row in con.execute("SELECT payload FROM review_versions WHERE user_id=? ORDER BY id",(uid,))]
            events=[dict(row) for row in con.execute("SELECT at,action,outcome FROM audit WHERE subject=? ORDER BY id DESC LIMIT 100",(digest(uid)[:20],))]
            audit(con,user["id"],"case_viewed",uid)
        return {"id":uid,"username":db.decrypt(person["username_enc"]),"answers":r["answers"],"ema":r["ema"],"flags":r["flags"],"hypotheses":hypotheses(r["answers"]),"review":r["review"],"review_history":review_history,"revision":rev,"audit":events,"progress":progress(r["answers"],r["sessions"],r.get("session_peaks",{}))}

    @application.post("/api/staff/cases/{uid}/review")
    async def review_case(uid:str,request:Request):
        data=await body(request,("action","patient_summary","clinical_notes","revision","interview_completed"))
        action=data.get("action")
        if action not in ("approve","reject","draft"): raise HTTPException(422,"Acción inválida.")
        for k in ("patient_summary","clinical_notes"):
            if not isinstance(data.get(k,""),str) or len(data.get(k,""))>10000: raise HTTPException(422,"Texto inválido o demasiado largo.")
        if type(data.get("revision")) is not int: raise HTTPException(422,"Revisión inválida.")
        with db.connection(transaction=True) as con:
            user=auth(request,"clinician",con=con)
            r,revision,_=load_record(db,con,uid)
            if revision==0: raise HTTPException(404,"Caso no disponible.")
            if data["revision"]!=revision: raise HTTPException(409,"El caso cambió. Recarga antes de revisar.")
            cfg=get_config(db,con)
            if action=="approve":
                profile=db.decrypt(user["clinical_profile"]) if user["clinical_profile"] else {}
                if not profile.get("license_attested") or not profile.get("clinical_name") or not profile.get("clinical_license"): raise HTTPException(403,"El administrador debe vincular y atestiguar la identidad y cédula de esta cuenta clínica.")
                if not cfg["readiness"]["clinician"] or not cfg["clinical_license"].strip() or not cfg["clinical_name"].strip(): raise HTTPException(403,"Falta responsable clínico con cédula atestiguada.")
                if data.get("interview_completed") is not True: raise HTTPException(422,"La aprobación exige una entrevista clínica completada.")
                if not data.get("patient_summary","").strip(): raise HTTPException(422,"Incluye el resumen revisado para la persona.")
                if any(f["severity"] in ("red","orange") and f["status"]!="resolved" for f in r["flags"]): raise HTTPException(409,"Resuelve y documenta primero las alertas rojas o naranjas.")
                if not safety_ready(r["answers"]): raise HTTPException(409,"Falta evaluación inicial de seguridad completa.")
            review={"status":{"approve":"approved","reject":"rejected","draft":"pending"}[action],"patient_summary":data.get("patient_summary",""),"clinical_notes":data.get("clinical_notes",""),"interview_completed":data.get("interview_completed") is True,"clinician_id":user["id"],"clinical_profile":db.decrypt(user["clinical_profile"]) if user["clinical_profile"] else None,"source_revision":revision,"at":now_iso(),"version":revision+1}
            r["review"]=review
            con.execute("INSERT INTO review_versions(user_id,revision,payload,created_at) VALUES(?,?,?,?)",(uid,revision+1,db.encrypt(review),now_iso()))
            save_record(db,con,uid,r,revision+1); audit(con,user["id"],"review_"+action,uid)
        return {"review":review,"revision":revision+1}

    @application.post("/api/staff/cases/{uid}/alerts/resolve")
    async def resolve(uid:str,request:Request):
        data=await body(request,("note","reason","alert_id"))
        if not isinstance(data.get("note"),str) or not 10<=len(data["note"].strip())<=2000: raise HTTPException(422,"Documenta la revisión clínica en 10 a 2000 caracteres.")
        if not isinstance(data.get("reason"),str) or not 3<=len(data["reason"])<=120: raise HTTPException(422,"Especifica el motivo clínico.")
        with db.connection(transaction=True) as con:
            user=auth(request,"clinician",con=con)
            r,rev,_=load_record(db,con,uid)
            if not rev: raise HTTPException(404,"Caso no disponible.")
            targets=[f for f in r["flags"] if f["status"]!="resolved" and (not data.get("alert_id") or f["id"]==data["alert_id"])]
            if not targets: raise HTTPException(409,"No hay alertas pendientes que coincidan.")
            for f in targets:
                r["alert_resolutions"][f["id"]]={"clinician_id":user["id"],"at":now_iso(),"note":data["note"],"reason":data["reason"]}; f["status"]="resolved"
            r["review"]={"status":"pending"}
            save_record(db,con,uid,r,rev+1); audit(con,user["id"],"alerts_resolved",uid)
        return {"ok":True,"revision":rev+1,"resolved":len(targets)}

    @application.get("/api/admin/config")
    async def admin_config_get(request:Request):
        auth(request,"admin")
        with db.connection() as con: return get_config(db,con)

    @application.put("/api/admin/config")
    async def admin_config_put(request:Request):
        fields=("privacy_notice","privacy_contact","clinical_name","clinical_license","service_hours","guard_contact","readiness","enrollment_open")
        data=await body(request,fields)
        with db.connection(transaction=True) as con:
            user=auth(request,"admin",con=con); cfg=get_config(db,con)
            for key,value in data.items():
                if key=="readiness":
                    if not isinstance(value,dict) or set(value)!=set(cfg["readiness"]) or any(type(v) is not bool for v in value.values()): raise HTTPException(422,"Completa las cinco atestiguaciones de preparación.")
                elif key=="enrollment_open":
                    if type(value) is not bool: raise HTTPException(422,"Valor inválido.")
                elif not isinstance(value,str) or len(value)> (15000 if key=="privacy_notice" else 1000): raise HTTPException(422,"Configuración inválida.")
                cfg[key]=value
            if cfg["enrollment_open"] and not ready(cfg): raise HTTPException(409,"No se puede abrir: completa aviso, responsable con cédula, guardia, licencias y validación clínica.")
            con.execute("INSERT INTO config(id,payload) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload",(db.encrypt(cfg),)); audit(con,user["id"],"readiness_config_updated")
        return cfg

    @application.post("/api/admin/invitations")
    async def invitation(request:Request):
        data=await body(request,("role","expires_hours","clinical_name","clinical_license","license_attested"))
        role=data.get("role"); hours=data.get("expires_hours",72)
        if role not in ("participant","clinician") or type(hours) is not int or not 1<=hours<=168: raise HTTPException(422,"Invitación inválida.")
        with db.connection(transaction=True) as con:
            user=auth(request,"admin",con=con); limit("invite:"+user["id"],30)
            cfg=get_config(db,con)
            if role=="participant" and (not cfg["enrollment_open"] or not ready(cfg)): raise HTTPException(403,"El registro real está cerrado hasta completar preparación.")
            token=secrets.token_urlsafe(32); expires=time.time()+hours*3600
            profile=None
            if role=="clinician" and any(k in data for k in ("clinical_name","clinical_license","license_attested")):
                if not all(isinstance(data.get(k),str) and 1<=len(data[k].strip())<=200 for k in ("clinical_name","clinical_license")) or data.get("license_attested") is not True: raise HTTPException(422,"Completa nombre, cédula y atestiguación de verificación de esta persona.")
                profile={"clinical_name":data["clinical_name"].strip(),"clinical_license":data["clinical_license"].strip(),"license_attested":True,"attested_by":user["id"],"attested_at":now_iso(),"verification":"Manual por administrador; la plataforma no consulta el registro profesional."}
            con.execute("INSERT INTO invitations(token_hash,role,expires_at,used_at,created_by,created_at,clinical_profile) VALUES(?,?,?,?,?,?,?)",(digest(token),role,expires,None,user["id"],now_iso(),db.encrypt(profile) if profile else None)); audit(con,user["id"],"invitation_created")
        return {"token":token,"expires_at":datetime.fromtimestamp(expires,timezone.utc).isoformat(),"url":origin+"/equipo?invite="+quote(token),"role":role}

    @application.get("/api/admin/audit")
    async def audit_get(request:Request):
        user=auth(request,"admin")
        with db.connection(transaction=True) as con:
            events=[dict(row) for row in con.execute("SELECT id,at,actor,action,subject,outcome FROM audit ORDER BY id DESC LIMIT 250")]; audit(con,user["id"],"audit_viewed")
        return {"events":events}

    @application.get("/robots.txt")
    async def public_robots():
        return Response("User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /equipo\nDisallow: /admin-actividad\nDisallow: /administracion-comunidad\nDisallow: /perfil\nDisallow: /acceso\nSitemap: https://nemy.com.mx/sitemap.xml\n",media_type="text/plain")

    @application.get("/sitemap.xml")
    async def public_sitemap():
        paths=("/","/mi-recuperacion","/acompanar","/dtr-ga","/privacidad","/emociones","/adicciones","/mapa","/estancamiento","/traza","/ayuda")
        urls="".join("<url><loc>https://nemy.com.mx"+path+"</loc></url>" for path in paths)
        return Response('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+urls+'</urlset>',media_type="application/xml")

    @application.get("/")
    async def nemy_life_home():
        return FileResponse(ROOT/"public"/"home-life.html")

    @application.get("/mi-recuperacion")
    async def self_path():
        return FileResponse(ROOT/"public"/"mi-recuperacion.html")

    @application.get("/acompanar")
    async def supporter_path():
        return FileResponse(ROOT/"public"/"acompanar.html")

    @application.get("/privacidad")
    async def life_privacy():
        return FileResponse(ROOT/"public"/"privacy-life.html")

    @application.get("/crio")
    async def crio_page(): return FileResponse(ROOT/"public"/"crio.html")

    @application.get("/donar")
    async def donation_page(): return FileResponse(ROOT/"public"/"donar.html")

    @application.get("/dtr-ga")
    async def dtr_page():
        return FileResponse(ROOT/"public"/"dtr.html")

    @application.get("/emociones")
    @application.get("/estancamiento")
    @application.get("/mapa")
    @application.get("/ayuda")
    @application.get("/comunidad")
    @application.get("/perfil")
    @application.get("/acceso")
    async def index():
        return FileResponse(ROOT/"public"/"nemy.html")

    @application.get("/adicciones")
    async def addictions_experience():
        return FileResponse(ROOT/"public"/"umbral.html")

    @application.get("/traza")
    async def traza_home():
        path=ROOT/"public"/"welcome.html"
        if not path.exists(): return JSONResponse({"service":"TRAZA","mode":"restricted-pilot"})
        return FileResponse(path)

    @application.get("/explorar")
    async def previous_exploration():
        from fastapi.responses import RedirectResponse
        return RedirectResponse("/traza",status_code=307)

    @application.get("/equipo")
    async def professional_portal():
        return FileResponse(ROOT/"public"/"equipo.html")

    @application.get("/instrumentos")
    async def instrument_library():
        return FileResponse(ROOT/"public"/"battery.html")

    @application.get("/admin-actividad")
    async def activity_portal():
        return FileResponse(ROOT/"public"/"admin-activity.html")

    @application.get("/administracion-comunidad")
    async def community_admin_portal():
        return FileResponse(ROOT/"public"/"admin-community.html")

    @application.get("/media/{filename}")
    async def cinematic_media(filename:str):
        names=("hero-valle","emociones-ventana","consumo-reflejo","impulso-montana","espejo-emocional","ciclo-alivio","acompanar-conversacion","nuevo-amanecer","crio-hielo")
        allowed={name+suffix+".webp" for name in names for suffix in ("","-mobile")}
        if filename not in allowed: raise HTTPException(404,"No disponible.")
        path=ROOT/"public"/"media"/filename
        if not path.is_file(): raise HTTPException(404,"No disponible.")
        return FileResponse(path,media_type="image/webp")

    @application.get("/{filename}")
    async def assets(filename:str):
        if filename not in ("styles.css","sw.js","manifest.webmanifest","favicon.svg","clinical-content.js","instruments.js","flow.js","flow.css","equipo.html","professional.js","staff.css","battery.js","battery.css","BRSCL-content.json","journey.js","journey.css","experience.js","experience.css","activity-client.js","question-support.js","question-scenes.js","admin-activity.js","admin-activity.css","nemy.js","nemy.css","nemy-scenes.js","nemy-content.json","admin-community.js","umbral.js","umbral.css","umbral-pizarron.webp","cinema-main.js","cinema-traza.css","nemy-life.css","nemy-life.js","dtr.js","dtr.css","nemy-neon.css","nemy-neon.js","crio.css"): raise HTTPException(404,"No disponible.")
        path=ROOT/"public"/filename
        if not path.is_file(): raise HTTPException(404,"No disponible.")
        return FileResponse(path,media_type="image/webp" if filename.endswith(".webp") else None)

    from exploration import attach_exploration
    attach_exploration(application, db)
    from battery import attach_battery
    attach_battery(application)
    from journey import attach_journey
    attach_journey(application,db,application.state.exploration)
    from activity import attach_activity
    attach_activity(application,db,lambda request: auth(request,"admin"))
    from community import attach_community
    attach_community(application,db,lambda request: auth(request,"admin"))
    from dtr_api import attach_dtr
    attach_dtr(application)
    return application

app=create_app()

def bootstrap(output):
    db=app.state.db
    with db.connection(transaction=True) as con:
        if con.execute("SELECT 1 FROM users WHERE role='admin' LIMIT 1").fetchone(): raise SystemExit("An administrator already exists; bootstrap refused.")
        username="admin"; password=secrets.token_urlsafe(24); uid=uuid.uuid4().hex
        path=Path(output).resolve(); path.parent.mkdir(parents=True,exist_ok=True)
        # Exclusive creation prevents accidental overwrite of an existing credential handoff.
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        try:
            con.execute("INSERT INTO users(id,username_hash,username_enc,password,role,must_change,created_at) VALUES(?,?,?,?,?,?,?)",(uid,db.username_hash(username),db.encrypt(username),password_hash(password),"admin",1,now_iso()))
            with os.fdopen(fd,"w",encoding="utf-8") as f:
                f.write("TRAZA — acceso inicial de administración\nUsuario: admin\nContraseña: "+password+"\nCambia esta contraseña y configura TOTP al entrar. El administrador no puede leer datos clínicos.\n")
            audit(con,uid,"admin_bootstrapped")
        except Exception:
            try: os.close(fd)
            except OSError: pass
            path.unlink(missing_ok=True); raise
    print("Administrator created. Credentials written to the requested private file.")

if __name__=="__main__":
    parser=argparse.ArgumentParser(); sub=parser.add_subparsers(dest="command")
    boot=sub.add_parser("bootstrap"); boot.add_argument("--output",required=True)
    args=parser.parse_args()
    if args.command=="bootstrap": bootstrap(args.output)
    else:
        import uvicorn
        uvicorn.run(app,host="127.0.0.1",port=int(os.environ.get("PORT","3230")),access_log=False)
