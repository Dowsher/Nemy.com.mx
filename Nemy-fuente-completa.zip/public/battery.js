(() => {
  'use strict';
  const main = document.getElementById('main');
  const modalRoot = document.getElementById('modal-root');
  const ux = window.TRAZA_UX;
  const sessions = {};
  let pendingText=null,saveTimer=null;
  const activity = new window.TRAZA_ACTIVITY.Activity('battery', activityStatus);
  function activityStatus(status,message='') { state.saveStatus=status; if(message)state.saveError=message; else if(status==='saved')state.saveError=''; const node=document.getElementById('save-status'); if(node) { node.textContent=status==='saving'?'Guardando…':status==='error'?'Sin guardar · reintenta':'Respuestas guardadas'; node.dataset.status=status; } }
  function registerAnswer(item,value) { activity.event('answer',state.form.id,item.id,value??null).catch(error=>{state.saveError=error.message;activityStatus('error');}); }
  function flushText() { clearTimeout(saveTimer); if(pendingText) { const pending=pendingText;pendingText=null;registerAnswer(pending.item,pending.value); } }
  async function saved() { flushText(); try { await activity.flush();state.saveError='';return true; } catch(error) { state.error=error.message;state.saveError=error.message;render(false);return false; } }
  async function tracked(type,value=null) { if(!(await saved()))return false; try { await activity.event(type,null,null,value);return true; } catch(error) {state.error=error.message;render(false);return false;} }
  async function useSession(id) { if(!(await saved()))throw new Error(state.saveError); if(activity.session && state.form) sessions[state.form.id]={session:activity.session,sequence:activity.sequence}; activity.reset(); if(sessions[id]) Object.assign(activity,sessions[id]); else await activity.start({kind:'battery',route_id:null,form_id:id}); }
  const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
  const state = {catalog: null, catalogError: '', view: 'catalog', filter: 'all', saveStatus:'',saveError:'',storage:false, adult: false, processing: false, consent: false, pendingId: null, form: null, answers: {}, drafts: {}, results: {}, index: 0, result: null, error: '', loading: false, editReview: false, dangerChecked: false, dangerAnswer: null, dangerNext: 'question', blocked: false, pauseView: null, exiting: false};
  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, char => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[char]));
  const arr = value => Array.isArray(value) ? value : value == null ? [] : [value];
  const readable = value => typeof value === 'object' && value !== null ? (value.label || value.text || value.message || value.name || '') : value;
  const safeUrl = value => { try { const url = new URL(value, location.origin); return ['http:', 'https:'].includes(url.protocol) ? url.href : ''; } catch (_) { return ''; } };
  const urlLink = (value, label) => { const url = safeUrl(value); return url ? `<a href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(label)} ↗</a>` : ''; };
  const primary = (label, action, disabled = false, extra = '') => `<button class="primary" data-action="${action}"${disabled ? ' disabled' : ''}${extra}>${esc(label)} <span class="arrow" aria-hidden="true">→</span></button>`;
  const back = (action = 'catalog', label = 'Cuestionarios', detail = '') => `<div class="screen-top"><button class="back-button" data-action="${action}"><span aria-hidden="true">←</span> ${esc(label)}</button>${detail ? `<span class="step-label">${esc(detail)}</span>` : ''}</div>`;
  const errorBox = () => (state.error || state.saveError) ? `<div class="error-box" role="alert">${esc(state.error || state.saveError)}${state.saveError?'<button class="text-button" data-action="retry-save">Reintentar guardado</button>':''}</div>` : '';
  const catalogEntry = id => state.catalog?.instruments.find(instrument => instrument.id === id);
  const items = () => [...arr(state.form?.items), ...arr(state.form?.additional_items)].filter(item => item && item.id);
  const same = (a, b) => a === b;
  const isMissing = (value, item) => value == null || (item?.type === 'text' && typeof value === 'string' && !value.trim()) || (item?.type === 'number' ? value === 'skipped' || value === 'unknown' : same(value, 98) || same(value, 99)) || (Array.isArray(value) && (!value.length || value.some(part => same(part, 98) || same(part, 99))));
  const missingOptions = item => item.type === 'number' ? [{value: 'skipped', label: 'Pasar esta pregunta'}, {value: 'unknown', label: 'No sé'}] : [{value: 98, label: 'Pasar esta pregunta'}, {value: 99, label: 'No sé'}];
  const textLimit = item => Math.min(500, Math.max(1, Number.isInteger(item.max_length) ? item.max_length : 500));
  function conditionMatches(condition, answers) {
    if (!condition) return true;
    if (Array.isArray(condition)) return condition.every(part => conditionMatches(part, answers));
    if (condition.all) return arr(condition.all).every(part => conditionMatches(part, answers));
    if (condition.any) return arr(condition.any).some(part => conditionMatches(part, answers));
    const value = answers[condition.id];
    if (isMissing(value)) return false;
    if (own(condition, 'equals')) return same(value, condition.equals);
    if (own(condition, 'includes')) return Array.isArray(value) && value.some(part => same(part, condition.includes));
    if (own(condition, 'not_in')) return value != null && !arr(condition.not_in).includes(value);
    return false;
  }
  const visibleItems = () => items().filter(item => conditionMatches(item.show_if, state.answers));
  const availableOptions = item => arr(item.options).filter(option => !item.filter_options_by_answers?.[option.value] || conditionMatches(item.filter_options_by_answers[option.value], state.answers));
  function pruneAnswers() {
    // More than one pass also removes answers whose own parent became hidden.
    let removed = true;
    while (removed) {
      removed = false;
      for (const item of items()) {
        if (!own(state.answers, item.id)) continue;
        if (!conditionMatches(item.show_if, state.answers)) { delete state.answers[item.id]; removed = true; continue; }
        if (item.filter_options_by_answers && !isMissing(state.answers[item.id], item)) {
          const options = availableOptions(item);
          if (Array.isArray(state.answers[item.id])) {
            const filtered = state.answers[item.id].filter(value => options.some(option => same(option.value, value)));
            if (filtered.length !== state.answers[item.id].length) { if (filtered.length) state.answers[item.id] = filtered; else delete state.answers[item.id]; removed = true; }
          } else if (!options.some(option => same(option.value, state.answers[item.id]))) { delete state.answers[item.id]; removed = true; }
        }
      }
    }
    if (state.form) state.drafts[state.form.id] = {...state.answers};
  }
  function hasAnswer(item) { return own(state.answers, item.id) && (item.type !== 'text' || typeof state.answers[item.id] !== 'string' || !!state.answers[item.id].trim()) && (!Array.isArray(state.answers[item.id]) || state.answers[item.id].length > 0); }
  function answerLabel(item) {
    const value = state.answers[item.id];
    if (value == null || (item.type === 'text' && typeof value === 'string' && !value.trim()) || (Array.isArray(value) && !value.length)) return 'Sin responder';
    if (item.type === 'number') return value === 'skipped' ? 'Pasada' : value === 'unknown' ? 'No sé' : `${value}${item.unit ? ` ${item.unit}` : ' años'}`;
    if (same(value, 98)) return 'Pasada';
    if (same(value, 99)) return 'No sé';
    if (item.type === 'text') return String(value);
    return arr(value).map(part => item.options?.find(option => same(option.value, part))?.label ?? String(part)).join(' · ');
  }
  function render(focus = true) {
    const views = {catalog: catalogView, consent: consentView, intro: introView, question: questionView, review: reviewView, result: resultView, danger: dangerView, safety: safetyView, paused: pausedView, loading: loadingView};
    main.innerHTML = (views[state.view] || catalogView)();
    document.body.classList.toggle('has-question-dock',['question','danger'].includes(state.view));
    if(!main.querySelector('.back-button'))main.insertAdjacentHTML('afterbegin',state.view==='catalog'?'<div class="universal-back"><a class="back-button" href="/">← Regresar al inicio</a></div>':'<div class="universal-back"><button class="back-button" data-action="go-back">← Regresar</button></div>');
    const pause = document.getElementById('pause-button');
    pause.hidden = !['question', 'review', 'intro', 'result'].includes(state.view);
    if (focus) { main.focus({preventScroll: true}); window.scrollTo({top: 0, behavior: 'instant'}); }
    const title = state.form && state.view !== 'catalog' ? `${state.form.name} · TRAZA` : 'Cuestionarios · TRAZA';
    document.title = title;
  }
  function catalogView() {
    if (!state.catalog) return `<section class="view battery-view"><p class="eyebrow">TRAZA · Cuestionarios</p><h1>Elige por dónde empezar.</h1>${state.catalogError ? `<div class="error-box" role="alert">${esc(state.catalogError)}</div>${primary('Volver a cargar', 'retry-catalog')}` : '<p class="inline-loading" role="status">Cargando cuestionarios…</p>'}</section>`;
    const instruments = state.catalog.instruments.filter(instrument=>instrument.status==='available');
    const topics = [...new Set(instruments.map(instrument => instrument.topic || 'Otros temas'))];
    const available = instruments.filter(instrument => instrument.status === 'available').length;
    const visible = instruments.filter(instrument => state.filter === 'all' || (instrument.topic || 'Otros temas') === state.filter);
    const ready = visible.filter(instrument => instrument.status === 'available');
    const pending = visible.filter(instrument => instrument.status !== 'available');
    const sections = topics.filter(topic => ready.some(instrument => (instrument.topic || 'Otros temas') === topic)).map(topic => `<section class="battery-section"><h2>${esc(topic)}</h2><div class="battery-grid">${ready.filter(instrument => (instrument.topic || 'Otros temas') === topic).map(catalogCard).join('')}</div></section>`).join('');
    const pendingHtml = pending.length ? `<details class="battery-pending"${ready.length ? '' : ' open'}><summary>Instrumentos con un requisito pendiente <span>${pending.length}</span></summary><p class="small muted">Consulta el requisito de cada versión.</p><div>${pending.map(instrument => `<div class="battery-pending-row"><div><strong>${esc(instrument.name)}</strong><span>${esc(instrument.topic || 'Otros temas')}</span></div><button class="secondary" data-action="permission" data-id="${esc(instrument.id)}">Ver requisito <span aria-hidden="true">↗</span></button></div>`).join('')}</div></details>` : '';
    return `<section class="view battery-catalog"><p class="eyebrow"><span class="eyebrow-dot"></span>Cuestionarios</p><h1>Elige por dónde empezar.</h1><p class="lead">Explora un tema concreto y recibe su resultado al terminar. Puedes hacer un cuestionario o varios.</p><div class="battery-intro"><span class="small-tag lilac">${available} disponibles</span><span class="small muted">Sin cuenta · Una pregunta a la vez</span></div><div class="battery-filters" aria-label="Filtrar por tema"><button class="filter-chip" data-action="filter" data-filter="all" aria-pressed="${state.filter === 'all'}">Todos</button>${topics.map(topic => `<button class="filter-chip" data-action="filter" data-filter="${esc(topic)}" aria-pressed="${state.filter === topic}">${esc(topic)}</button>`).join('')}</div>${sections || (pending.length ? '' : '<p class="battery-empty">No hay cuestionarios en este tema.</p>')}${pendingHtml}<p class="home-privacy">Antes de responder, aceptarás el guardado cifrado para el panel privado de TRAZA. Estos cuestionarios individuales no usan IA.</p></section>`;
  }
  function catalogCard(instrument) {
    const available = instrument.status === 'available';
    const result = state.results[instrument.id];
    const draft = state.drafts[instrument.id];
    const started = draft && Object.keys(draft).length > 0;
    const title = instrument.title && instrument.title.toLocaleLowerCase() !== instrument.name.toLocaleLowerCase() ? instrument.title : '';
    return `<article class="battery-card${available ? '' : ' status-restricted'}">${result ? '<span class="status-pill done">Resultado disponible en esta pestaña</span>' : started ? '<span class="status-pill">En curso</span>' : available ? '' : '<span class="status-pill">Consulta de disponibilidad</span>'}<h3>${esc(instrument.name)}</h3>${title ? `<p class="battery-card-title">${esc(title)}</p>` : ''}<p>${esc(instrument.description || 'Cuestionario para explorar este tema.')}</p><div class="battery-card-meta">${instrument.item_count ? `<span>${esc(instrument.question_count_label || (instrument.item_count + ""))}</span>` : ''}${instrument.minutes ? `<span>${esc(instrument.minutes)} min aprox.</span>` : ''}</div>${available ? primary(result ? 'Ver resultado' : started ? 'Continuar' : 'Empezar', result ? 'open-result' : 'open', false, ` data-id="${esc(instrument.id)}"`) : `<button class="secondary" data-action="permission" data-id="${esc(instrument.id)}">Ver qué falta <span aria-hidden="true">↗</span></button>`}</article>`;
  }
  function consentView() {
    return `<section class="view battery-view">${back()}<div class="panel"><p class="eyebrow">Una vez, antes de empezar</p><h1>Responde y consulta tu resultado.</h1><p class="lead">Tus respuestas se guardarán cifradas en TRAZA y se usarán para calcular la puntuación. El equipo autorizado puede consultarlas en el panel privado. Estos cuestionarios no envían respuestas a OpenAI.</p><div class="check-list"><label class="consent-check"><input type="checkbox" id="adult-consent"${state.adult ? ' checked' : ''}><span>Tengo <strong>18 años o más</strong>.</span></label><label class="consent-check"><input type="checkbox" id="processing-consent"${state.processing ? ' checked' : ''}><span>Acepto este uso de mis respuestas para obtener los resultados.</span></label><label class="consent-check"><input type="checkbox" id="storage-consent"${state.storage ? ' checked' : ''}><span>Acepto guardar mis respuestas e informes cifrados hasta 90 días y que el equipo autorizado de TRAZA los consulte en el panel privado de administración.</span></label></div><p class="small muted">El progreso se conserva en esta pestaña. Si la cierras o recargas, se pierde; puedes descargar tus respuestas al terminar.</p><div class="action-row spread"><button class="text-button" data-action="privacy">Mis datos</button>${primary('Continuar', 'consent-next', !(state.adult && state.processing && state.storage))}</div>${errorBox()}</div></section>`;
  }
  function introView() {
    const entry = catalogEntry(state.form.id) || {};
    return `<section class="view battery-view">${back()}<div class="panel"><p class="eyebrow">${esc(entry.topic || 'Cuestionario')}</p><h1>${esc(state.form.name)}</h1>${state.form.title && state.form.title !== state.form.name ? `<p class="lead">${esc(state.form.title)}</p>` : ''}<div class="battery-stats"><span class="small-tag lilac">${esc(entry.question_count_label || (items().length + ' preguntas'))}</span>${entry.minutes ? `<span class="small-tag">${esc(entry.minutes)} min aprox.</span>` : ''}</div>${state.form.instructions ? `<p class="battery-instructions">${esc(state.form.instructions)}</p>` : ''}${state.form.intro ? `<p class="battery-instructions">${esc(state.form.intro)}</p>` : ''}${state.form.intro_notice ? `<p class="battery-scope-note">${esc(state.form.intro_notice)}</p>` : ''}<div class="action-row">${primary(Object.keys(state.answers).length ? 'Continuar' : 'Empezar', 'begin')}</div></div><div class="battery-source" style="margin-top:18px">${sourceView()}</div></section>`;
  }
  function questionView() {
    const visible = visibleItems();
    state.index = Math.min(state.index, Math.max(0, visible.length - 1));
    const item = visible[state.index];
    if (!item) return reviewView();
    const options = availableOptions(item);
    const value = state.answers[item.id];
    const marked = option => Array.isArray(value) ? value.some(part => same(part, option.value)) : same(value, option.value);
    const standard = options.map((option, index) => optionView(item, option, index, marked(option))).join('');
    const unknown = missingOptions(item).filter(option => !options.some(existing => same(existing.value, option.value)));
    const contextFor = question => own(question, 'context_instructions') ? String(question.context_instructions || '') : question.instruction || question.instructions || question.context || state.form.question_instructions || (question.id.endsWith('_EXPOSURE') ? '' : state.form.instructions) || '';
    const context = contextFor(item);
    const previous = visible[state.index - 1];
    const previousContext = previous && contextFor(previous);
    const contextHtml = context ? `<div class="battery-question-context">${context.length > 230 && context === previousContext ? `<details><summary>Instrucciones de este bloque</summary><p>${esc(context)}</p></details>` : esc(context)}</div>` : '';
    const numeric = item.type === 'number';
    const textual = item.type === 'text';
    const textValue = textual && typeof value === 'string' ? value : '';
    const textHint = textual && item.input_hint ? `<p class="small muted battery-text-hint" id="text-answer-hint">${esc(item.input_hint)}</p>` : '';
    const field = ux?.sliderSpec(item) ? ux.slider(item,value,'battery-slider') : numeric ? `<label class="battery-number-label" for="number-answer">${esc(item.input_label || 'Edad aproximada en años')}</label><input class="battery-number" id="number-answer" name="number-answer" type="number" inputmode="numeric" min="${esc(item.min ?? 0)}" max="${esc(item.max ?? 100)}" step="1" value="${typeof value === 'number' ? esc(value) : ''}" autocomplete="off"><p class="small muted battery-number-hint">${esc(item.min ?? 0)} a ${esc(item.max ?? 100)} ${esc(item.unit || 'años')}</p>` : textual ? `<label class="battery-text-label" for="text-answer">${esc(item.input_label || (item.optional ? 'Descripción breve (opcional)' : 'Tu respuesta'))}</label><textarea class="battery-text" id="text-answer" name="text-answer" rows="5" maxlength="${textLimit(item)}" autocomplete="off" aria-describedby="${textHint ? 'text-answer-hint ' : ''}text-answer-count">${esc(textValue)}</textarea>${textHint}<p class="small muted battery-text-count" id="text-answer-count">${textValue.length} / ${textLimit(item)} caracteres</p>` : `<div class="options battery-options">${standard}</div>`;
    const legend = options.some(option => own(option, 'shaded')) ? '<p class="battery-shaded-legend">Las zonas sombreadas pertenecen al formato original.</p>' : '';
    return `<section class="view battery-view">${back(state.index ? 'previous' : 'intro', state.index ? 'Anterior' : 'Instrucciones', state.form.name)}<div class="progress-row"><span class="question-block">${esc(item.group || 'Paso a paso')}</span><span class="question-step">${state.index + 1} de ${visible.length}</span></div><progress class="battery-progress" value="${visible.filter(question=>hasAnswer(question)).length}" max="${visible.length}" aria-label="Avance del cuestionario"></progress>${contextHtml}${ux?.support(item.id,state.form.id) || ''}<fieldset class="question-form"><legend class="question-title">${esc(item.display_text || item.text)}</legend>${item.hint ? `<p class="question-hint">${esc(item.hint)}</p>` : ''}${item.multiple ? `<p class="multiple-note">${item.max_choices && item.max_choices < options.length ? `Elige hasta ${esc(item.max_choices)} opciones.` : 'Puedes elegir varias opciones.'}</p>` : ''}${field}${legend}${unknown.length ? `<div class="unknown-options">${unknown.map((option, index) => optionView(item, option, options.length + index, marked(option), true)).join('')}</div>` : ''}</fieldset><div class="question-actions question-dock"><button class="dock-back" data-action="${state.index?'previous':'intro'}">← Regresar</button><div class="dock-status"><span id="save-status" role="status" data-status="${esc(state.saveStatus)}">${state.saveStatus==='saving'?'Guardando…':state.saveStatus==='error'?'Sin guardar · reintenta':'A tu ritmo'}</span><button class="text-button" data-action="review">Ver lo que llevo</button></div>${primary(state.editReview || state.index === visible.length - 1 ? 'Revisar' : 'Continuar', 'next', !item.optional && !hasAnswer(item))}</div><div class="battery-toolbar"><button class="text-button" data-action="catalog">Volver al catálogo</button><button class="text-button" data-action="question-instructions">Instrucciones y fuente</button></div>${errorBox()}</section>`;
  }
  function optionView(item, option, index, checked, unknown = false) {
    return `<label class="option${checked ? ' chosen' : ''}${unknown ? ' unknown' : ''}${option.shaded ? ' original-shaded' : own(option, 'shaded') ? ' original-unshaded' : ''}"><input type="${item.multiple && !unknown ? 'checkbox' : 'radio'}" name="answer" value="${index}" data-item="${esc(item.id)}"${checked ? ' checked' : ''}><span>${esc(option.label)}</span><span class="option-check" aria-hidden="true">✓</span></label>`;
  }
  function reviewList() {
    return `<ol class="battery-review-list">${visibleItems().map((item, index) => `<li><p>${esc(item.display_text || item.text)}</p><span class="answer-value${isMissing(state.answers[item.id], item) ? ' skipped' : ''}">${esc(answerLabel(item))}</span><button data-action="edit" data-index="${index}" aria-label="Cambiar respuesta ${index + 1}">Cambiar</button></li>`).join('')}</ol>`;
  }
  function reviewView() {
    const visible = visibleItems();
    const answered = visible.filter(item => !isMissing(state.answers[item.id], item)).length;
    return `<section class="view battery-view">${back('return-question', 'Volver al cuestionario', state.form.name)}<div class="battery-review-head"><p class="eyebrow">${esc(state.form.name)}</p><h1>Revisa tus respuestas.</h1><p class="small muted">${answered} de ${visible.length} respondidas${answered < visible.length ? ' · Las pasadas o sin respuesta no cuentan como cero.' : '.'}</p></div>${reviewList()}${errorBox()}<div class="action-row spread"><button class="secondary" data-action="export">Descargar respuestas</button>${primary(state.loading ? 'Calculando…' : 'Ver resultado', 'score', state.loading)}</div></section>`;
  }
  function scoreNumber(result) {
    const total = result.total;
    if (total == null || typeof total === 'object') return '';
    const maximum = Array.isArray(result.range) ? result.range[1] : result.range?.max;
    return `<p class="battery-score-number">${esc(total)}${maximum != null ? `<small> / ${esc(maximum)}</small>` : ''}</p>`;
  }
  function resultView() {
    const result = state.result || {};
    const band = readable(result.band);
    const missing = arr(result.missing_ids);
    const subscales = arr(result.subscales);
    const findings = arr(result.findings);
    const hasScore = result.total != null || band || subscales.length;
    const scoreCard = result.total != null || band ? `<div class="battery-score">${scoreNumber(result)}${band ? `<p class="battery-band">${esc(band)}</p>` : ''}</div>` : '';
    const dimensions = subscales.map(part => {
      const value = part.value ?? part.total ?? part.score;
      const maximum = part.max ?? (Array.isArray(part.range) ? part.range[1] : null);
      const label = readable(part.band || part.label || part.summary);
      return `<div class="battery-subscale"><p>${esc(part.name || part.title || part.id)}${label ? `<span>${esc(label)}</span>` : ''}</p>${value != null ? `<strong>${esc(value)}${maximum != null ? ` <span>/ ${esc(maximum)}</span>` : ''}</strong>` : ''}</div>`;
    }).join('');
    const findingsHtml = findings.map(finding => `<div class="battery-finding">${typeof finding === 'object' ? `${finding.title ? `<strong>${esc(finding.title)}</strong><br>` : ''}${esc(finding.text || finding.message || finding.summary || finding.label || '')}` : esc(finding)}</div>`).join('');
    return `<section class="view battery-view"><div class="print-heading">TRAZA · ${esc(result.name || state.form.name)} · ${new Date().toLocaleDateString('es-MX')}</div>${back()}<p class="eyebrow">${esc(result.name || state.form.name)}</p><h1 class="result-title">${result.complete ? 'Tu resultado.' : 'Tu cuestionario está incompleto.'}</h1>${ux?.results([result]) || ''}${scoreCard}${result.summary ? `<div class="battery-result-summary battery-text-list">${arr(result.summary).map(text => `<p>${esc(readable(text))}</p>`).join('')}</div>` : ''}${dimensions ? `<div class="battery-subscales">${dimensions}</div>` : ''}${findingsHtml ? `<div class="battery-findings">${findingsHtml}</div>` : ''}${!result.complete && missing.length ? `<div class="battery-inline-warning">Faltan ${missing.length} respuestas para calcular el resultado completo. <button class="text-button" data-action="first-missing">Ir a la primera →</button></div>` : ''}<p class="battery-boundary">${hasScore ? 'Puntuación orientativa; no es un diagnóstico.' : 'Registro descriptivo; no es un diagnóstico.'}</p><div class="action-row result-actions">${primary('Elegir otro cuestionario', 'catalog')}<button class="secondary" data-action="review">Revisar respuestas</button></div><div class="export-actions"><button class="secondary" data-action="export">Descargar resultado</button><button class="secondary" data-action="print">Imprimir / guardar PDF</button><button class="quiet-button" data-action="restart">Responder de nuevo</button></div><details class="simple-details" style="margin-top:24px"><summary>Mis respuestas</summary>${reviewList()}</details><div class="battery-source" style="margin-top:25px">${sourceView(result.source_url)}</div></section>`;
  }
  function sourceView(url) {
    const source = url || state.form?.source?.url || catalogEntry(state.form?.id)?.source_url;
    const form = state.form || {};
    const notes = ['translation_warning', 'intended_use', 'presentation_note', 'source_scope', 'population_note', 'limitations'].flatMap(key => arr(form[key])).filter(Boolean);
    const metadata = `${form.version ? `<p><strong>Versión:</strong> ${esc(form.version)}</p>` : ''}${notes.map(note => `<p>${esc(readable(note))}</p>`).join('')}${form.attribution ? `<p class="battery-credit"><strong>Créditos</strong><br>${esc(form.attribution)}</p>` : ''}`;
    const license = form.content_license ? `<p class="battery-credit"><strong>${esc(form.content_license)}</strong>${form.license_url ? ` · ${urlLink(form.license_url, 'Consultar licencia')}` : ''} · ${esc(form.attribution || '')}${form.content_download_url ? ` <a href="${esc(form.content_download_url)}" target="_blank" rel="noopener noreferrer">Descargar contenido y licencia ↗</a>` : ''}</p>` : '';
    return `${urlLink(source, 'Consultar fuente')}${license}${metadata ? `<details><summary>Versión y alcance</summary>${metadata}</details>` : ''}`;
  }
  function resources() {
    return '<div class="resource-card"><h3>Si hay peligro inmediato</h3><p>Llama al 911 o pide a alguien que te acompañe.</p><a class="call" href="tel:911">Llamar al 911 ↗</a></div><div class="resource-card"><h3>Orientación en salud mental</h3><a class="call" href="tel:+528009112000?oai_link_source=model_response_hotline">800 911 2000 ↗</a><a class="source-link" href="https://www.gob.mx/conasama/articulos/linea-de-la-vida-800-911-2000?oai_link_source=model_response_hotline" target="_blank" rel="noopener noreferrer">Información oficial de la Línea de la Vida ↗</a></div>';
  }
  function dangerView() {
    return `<section class="view battery-view battery-safety"><p class="eyebrow">Una comprobación directa</p><h1 class="question-title">¿Hay peligro de que te hagas daño ahora?</h1>${ux?.support('S3','context') || ''}<p class="question-hint">La pregunta anterior puede referirse a momentos distintos. Aquí nos referimos a este momento.</p><div class="options">${[{value: 'yes', label: 'Sí, ahora'}, {value: 'no', label: 'No'}, {value: 'unknown', label: 'No sé'}].map(option => `<label class="option${state.dangerAnswer === option.value ? ' chosen' : ''}"><input type="radio" name="danger" value="${option.value}"${state.dangerAnswer === option.value ? ' checked' : ''}><span>${option.label}</span></label>`).join('')}</div>${state.dangerAnswer === 'unknown' ? `<div class="battery-inline-warning">Puedes hablar con alguien para aclararlo.</div>${resources()}` : ''}<div class="action-row question-dock"><button class="dock-back" data-action="go-back">← Regresar</button>${primary('Continuar', 'danger-next', !state.dangerAnswer)}</div></section>`;
  }
  function safetyView() { return `<section class="view battery-view battery-safety"><p class="eyebrow">Atención ahora</p><h1>Busca ayuda en este momento.</h1>${resources()}<div class="action-row"><button class="secondary" data-action="danger-correct">Corregir mi respuesta</button><button class="quiet-button" data-action="exit">Cerrar TRAZA</button></div></section>`; }
  function pausedView() { return `<section class="view battery-view paused-view"><div class="block-icon" aria-hidden="true">Ⅱ</div><h1>Recorrido en pausa.</h1><div class="action-row">${primary('Continuar', 'resume')}<button class="secondary" data-action="catalog">Ver cuestionarios</button></div><p class="battery-pause-note">Tu progreso sigue en esta pestaña.</p></section>`; }
  function loadingView() { return `<section class="view battery-view loading-view"><div class="loading-orbit" aria-hidden="true"></div><h1>${state.loading === 'score' ? 'Calculando tu resultado.' : 'Preparando el cuestionario.'}</h1><p class="lead">Un momento…</p></section>`; }
  async function request(url, options = {}) {
    const response = await fetch(url, {credentials: 'same-origin', cache: 'no-store', ...options, headers: {Accept: 'application/json', ...options.headers}});
    let data;
    try { data = await response.json(); } catch (_) { throw new Error('El servidor no devolvió una respuesta válida. Vuelve a intentarlo.'); }
    if (!response.ok) { const message = typeof data.detail === 'string' ? data.detail : data.message || data.error; throw new Error(message || 'No se pudo completar la solicitud. Vuelve a intentarlo.'); }
    return data;
  }
  async function loadCatalog() {
    state.catalogError = ''; render(false);
    try { state.catalog = await request('/api/battery/catalog'); if (!Array.isArray(state.catalog.instruments)) throw new Error('El catálogo no está disponible.'); }
    catch (error) { state.catalog = null; state.catalogError = error.message; }
    render(false);
  }
  async function openInstrument(id, useResult = false) {
    const entry = catalogEntry(id);
    if (!entry || entry.status !== 'available') return;
    state.pendingId = id; state.error = '';
    if (!state.consent) { state.view = 'consent'; render(); return; }
    state.loading = 'form'; state.view = 'loading'; render();
    try {
      const form = await request(`/api/battery/${encodeURIComponent(id)}`);
      if (!Array.isArray(form.items) || form.id !== id) throw new Error('No se pudo abrir este cuestionario.');
      await useSession(id); state.form = form; state.answers = {...(state.drafts[id] || {})}; state.result = state.results[id] || null;
      pruneAnswers(); state.index = Math.max(0, visibleItems().findIndex(item => !hasAnswer(item)));
      state.editReview = false; state.dangerChecked = false; state.dangerAnswer = null;
      state.view = useResult && state.result ? 'result' : 'intro';
    } catch (error) { state.view = 'catalog'; state.error = error.message; showModal('No se pudo abrir', `<p>${esc(error.message)}</p>`); }
    finally { state.loading = false; render(); }
  }
  function saveAnswer(item, value) {
    if (Array.isArray(value) && !value.length) delete state.answers[item.id];
    else state.answers[item.id] = value;
    pruneAnswers(); state.result = null; delete state.results[state.form.id]; state.error = '';
    const cleanValue=own(state.answers,item.id)?state.answers[item.id]:null; if(item.type==='text'||item.type==='number') {pendingText={item,value:cleanValue};clearTimeout(saveTimer);saveTimer=setTimeout(flushText,700);} else registerAnswer(item,cleanValue);
    if (item.id === 'PHQ9_9') { state.dangerChecked = false; state.dangerAnswer = null; }
  }
  function shouldCheckDanger() { const value = state.answers.PHQ9_9; return !state.dangerChecked && !isMissing(value) && Number(value) > 0; }
  function nextQuestion() {
    if (state.editReview) { state.editReview = false; state.view = 'review'; }
    else if (state.index >= visibleItems().length - 1) state.view = 'review';
    else { state.index += 1; state.view = 'question'; }
    render();
  }
  async function score() {
    if (state.loading) return;
    if(!(await saved()))return;
    if (shouldCheckDanger()) { state.dangerNext = 'score'; state.view = 'danger'; render(); return; }
    pruneAnswers(); state.error = ''; state.loading = 'score'; state.view = 'loading'; render();
    try {
      const result = await request(`/api/battery/${encodeURIComponent(state.form.id)}/score`, {method: 'POST', headers: {'Content-Type': 'application/json','X-Traza-Activity-Session':activity.session.session_id,'X-Traza-Visit':activity.visit.visit_token}, body: JSON.stringify({answers: state.answers, form_version: state.form.version || '1.0'})});
      state.result = result; state.results[state.form.id] = result; await activity.event('complete');
      if ((result.safety?.review || result.safety?.urgent) && !state.dangerChecked) { state.dangerNext = 'result'; state.dangerAnswer = null; state.view = 'danger'; }
      else state.view = 'result';
    } catch (error) { state.error = error.message; state.view = 'review'; }
    finally { state.loading = false; render(); }
  }
  async function exportData() {
    if(!(await tracked('export','json')))return;
    if (!state.form) return;
    const packet = {product: 'TRAZA', version: state.catalog?.version, instrument: {id: state.form.id, name: state.form.name, version: state.form.version, attribution: state.form.attribution, content_license: state.form.content_license, license_url: state.form.license_url, source_url: state.form.source?.url, presentation_note: state.form.presentation_note, registration: state.form.registration, language: state.form.language, edition_number: state.form.edition_number, translation_warning: state.form.translation_warning, intended_use: state.form.intended_use}, created_at: new Date().toISOString(), answers: {...state.answers}, responses: visibleItems().map(item => ({id: item.id, question: item.text, value: state.answers[item.id] ?? null, label: answerLabel(item)})), result: state.result || null};
    const url = URL.createObjectURL(new Blob([JSON.stringify(packet, null, 2)], {type: 'application/json;charset=utf-8'}));
    const link = document.createElement('a'); link.href = url; link.download = `TRAZA-${state.form.id}-${new Date().toISOString().slice(0, 10)}.json`; link.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  let modalFocus = null;
  function showModal(title, body) {
    modalFocus = document.activeElement;
    modalRoot.innerHTML = `<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title" tabindex="-1"><div class="modal-head"><h2 id="modal-title">${esc(title)}</h2><button class="modal-close" data-action="close-modal" aria-label="Cerrar">×</button></div>${body}</section></div>`;
    modalRoot.querySelector('.modal-close').focus();
  }
  function closeModal() { modalRoot.innerHTML = ''; modalFocus?.focus?.(); }
  function privacy() { showModal('Tus datos', '<p>Sin nombre ni correo. Al entrar se registra una visita con tipo de dispositivo, sistema y navegador, sin guardar el agente de usuario completo ni usar una huella para reconocer personas entre visitas.</p><p>Al aceptar el registro se guardan las respuestas y cambios cifrados hasta 90 días para el panel privado del equipo autorizado de TRAZA. Los cuestionarios individuales calculan sus resultados sin enviar datos a OpenAI.</p><p>Para continuar conserva esta pestaña; no se crea una cuenta ni una recuperación al recargar. Las descargas quedan en tu dispositivo. Puedes borrar el registro de esta sesión aquí; no elimina archivos descargados ni copias de seguridad anteriores.</p><button class="secondary" data-action="erase-session">Borrar esta sesión guardada</button>'); }
  function permission(id) {
    const entry = catalogEntry(id); if (!entry) return;
    showModal(entry.name, `<p>${esc(entry.reason || 'Falta una versión autorizada con contenido y puntuación verificables para habilitar este cuestionario.')}</p><div class="battery-permission"><p class="small" style="margin:0">En cuanto esté resuelto este requisito, podrá responderse aquí.</p></div>${entry.source_url ? `<p>${urlLink(entry.source_url, 'Consultar información del instrumento')}</p>` : ''}`);
  }
  function restart() {
    showModal('Responder de nuevo', `<p>Esto reemplazará las respuestas y el resultado de ${esc(state.form.name)} en esta pestaña.</p><div class="action-row"><button class="secondary" data-action="close-modal">Conservar resultado</button>${primary('Empezar de nuevo', 'confirm-restart')}</div>`);
  }
  document.addEventListener('input', event => {
    if(event.target.name==='battery-slider') { const item=visibleItems()[state.index],value=Number(event.target.value),spec=ux?.sliderSpec(item||{});if(!item||!spec?.options.some(option=>option.value===value))return;saveAnswer(item,value);const output=document.getElementById('slider-output');if(output)output.textContent=spec.options.find(option=>option.value===value).label;event.target.setAttribute('aria-valuetext',output?.textContent||String(value));event.target.closest('.answer-slider')?.classList.add('touched');const hint=document.getElementById('slider-instruction');if(hint)hint.textContent='Puedes ajustar la barra o pasar la pregunta.';const progress=main.querySelector('.battery-progress');if(progress)progress.value=visibleItems().filter(question=>hasAnswer(question)).length;const next=main.querySelector('[data-action="next"]');if(next)next.disabled=false;return;}
    if (!['number-answer', 'text-answer'].includes(event.target.name)) return;
    const item = visibleItems()[state.index];
    if (!item || (event.target.name === 'number-answer' ? item.type !== 'number' : item.type !== 'text')) return;
    if (item.type === 'text') {
      const value = event.target.value.slice(0, textLimit(item));
      if (event.target.value !== value) event.target.value = value;
      if (value.trim()) saveAnswer(item, value);
      else { saveAnswer(item,''); delete state.answers[item.id]; pendingText={item,value:null}; }
      const count = document.getElementById('text-answer-count'); if (count) count.textContent = `${value.length} / ${textLimit(item)} caracteres`;
    } else {
      const value = event.target.value.trim();
      const number = Number(value);
      if (value && Number.isInteger(number) && number >= (item.min ?? 0) && number <= (item.max ?? 100)) saveAnswer(item, number);
      else { delete state.answers[item.id]; pruneAnswers(); state.result = null; delete state.results[state.form.id]; pendingText={item,value:null}; clearTimeout(saveTimer);saveTimer=setTimeout(flushText,700); }
    }
    main.querySelectorAll('input[name="answer"]').forEach(input => { input.checked = false; input.closest('.option').classList.remove('chosen'); });
    const progress=main.querySelector('.battery-progress');if(progress)progress.value=visibleItems().filter(question=>hasAnswer(question)).length;
    const next = main.querySelector('[data-action="next"]'); if (next) next.disabled = !item.optional && !hasAnswer(item);
  });
  document.addEventListener('change', event => {
    const target = event.target;
    if (target.id === 'adult-consent' || target.id === 'processing-consent' || target.id === 'storage-consent') {
      state.adult = document.getElementById('adult-consent').checked; state.processing = document.getElementById('processing-consent').checked; state.storage=document.getElementById('storage-consent').checked;
      const next = main.querySelector('[data-action="consent-next"]'); if (next) next.disabled = !(state.adult && state.processing && state.storage); return;
    }
    if (target.name === 'danger') { state.dangerAnswer = target.value; activity.event('answer','context','S3',target.value==='yes'?1:target.value==='no'?0:99).catch(error=>{state.saveError=error.message;activityStatus('error');}); render(false); main.querySelector(`input[name="danger"][value="${target.value}"]`)?.focus({preventScroll: true}); return; }
    if (target.name !== 'answer') return;
    const item = visibleItems()[state.index]; if (!item || item.id !== target.dataset.item) return;
    const baseOptions = availableOptions(item);
    const options = [...baseOptions, ...missingOptions(item).filter(option => !baseOptions.some(existing => same(existing.value, option.value)))];
    const selected = options[Number(target.value)]; if (!selected) return;
    let value = selected.value;
    if (item.multiple && !same(value, 98) && !same(value, 99)) {
      const previous = Array.isArray(state.answers[item.id]) ? state.answers[item.id] : [];
      const exclusive = arr(item.exclusive_values);
      value = target.checked ? (exclusive.includes(value) ? [value] : [...previous.filter(part => !same(part, value) && !exclusive.includes(part)), value]) : previous.filter(part => !same(part, value));
      if (item.max_choices && value.length > item.max_choices) {
        state.error = `Puedes elegir hasta ${item.max_choices} opciones.`; render(false); main.querySelector(`input[name="answer"][value="${target.value}"]`)?.focus({preventScroll: true}); return;
      }
    }
    saveAnswer(item, value); render(false); main.querySelector(`input[name="answer"][value="${target.value}"]`)?.focus({preventScroll: true});
  });
  document.addEventListener('click', async event => {
    const button = event.target.closest('[data-action]'); if (!button || button.disabled) return;
    const action = button.dataset.action;
    const serial=['next','danger-next','consent-next','open','open-result','score','confirm-restart','erase-session'].includes(action);if(serial && state.navBusy)return;if(serial)state.navBusy=true;try {
    if(state.loading && !['help','privacy','close-modal','exit','motion','go-back'].includes(action))return;
    if(action==='retry-save') {await saved();return;}
    if(action==='go-back'){state.view=state.view==='danger'?'question':state.view==='paused'?state.pauseView||'question':'catalog';render();return;}
    if(action==='erase-session') {
      const previousLoading=state.loading;
      state.loading='erase';
      // Pause the editor timer, preserving its latest value until the server confirms deletion.
      flushText();
      try {
        await activity.erase();
        if(state.form) { delete sessions[state.form.id]; delete state.drafts[state.form.id]; delete state.results[state.form.id]; }
        clearTimeout(saveTimer); saveTimer=null; pendingText=null;
        Object.assign(state,{form:null,answers:{},result:null,consent:false,adult:false,processing:false,storage:false,blocked:false,dangerChecked:false,dangerAnswer:null,dangerNext:'question',pauseView:null,index:0,pendingId:null,editReview:false,error:'',saveError:'',saveStatus:'',loading:false,view:'catalog'});
        closeModal(); render();
      } catch(error) { state.loading=previousLoading; state.error=error.message; closeModal(); render(false); }
      return;
    }
    if(['catalog','open','open-result','next','previous','intro','review','return-question','edit','first-missing','pause','confirm-restart','danger-next'].includes(action) && !(await saved()))return;
    if (state.blocked && !['help', 'exit', 'danger-correct', 'danger-next', 'close-modal', 'motion', 'privacy'].includes(action)) { state.view = 'safety'; render(); return; }
    if (action === 'retry-catalog') loadCatalog();
    else if (action === 'catalog') { state.view = 'catalog'; state.error = ''; render(); }
    else if (action === 'filter') { state.filter = button.dataset.filter; render(false); }
    else if (action === 'open' || action === 'open-result') await openInstrument(button.dataset.id, action === 'open-result');
    else if (action === 'consent-next' && state.adult && state.processing && state.storage) { state.consent = true; await openInstrument(state.pendingId, !!state.results[state.pendingId]); }
    else if (action === 'intro') { state.view = 'intro'; render(); }
    else if (action === 'begin') { state.view = 'question'; render(); }
    else if (action === 'next') { if (shouldCheckDanger()) { state.dangerNext = 'question'; state.view = 'danger'; render(); } else nextQuestion(); }
    else if (action === 'previous') { state.index = Math.max(0, state.index - 1); state.editReview = false; state.view = 'question'; render(); }
    else if (action === 'return-question') { state.view = 'question'; render(); }
    else if (action === 'review') { state.view = 'review'; state.error = ''; render(); }
    else if (action === 'edit') { state.index = Number(button.dataset.index); state.editReview = true; state.view = 'question'; render(); }
    else if (action === 'first-missing') { const index = visibleItems().findIndex(item => arr(state.result?.missing_ids).includes(item.id)); state.index = Math.max(0, index); state.editReview = false; state.view = 'question'; render(); }
    else if (action === 'score') await score();
    else if (action === 'export') exportData();
    else if (action === 'print') { if(!(await tracked('export','pdf')))return; main.querySelectorAll('details').forEach(detail => detail.open = true); window.print(); }
    else if (action === 'restart') restart();
    else if (action === 'confirm-restart') { closeModal(); if(!(await saved()))return; activity.reset(); delete sessions[state.form.id]; try {await activity.start({kind:'battery',route_id:null,form_id:state.form.id});}catch(error){state.error=error.message;render(false);return;} state.answers = {}; state.drafts[state.form.id] = {}; state.result = null; delete state.results[state.form.id]; state.index = 0; state.dangerChecked = false; state.dangerAnswer = null; state.view = 'intro'; render(); }
    else if (action === 'permission') permission(button.dataset.id);
    else if (action === 'privacy') privacy();
    else if (action === 'help') showModal('Ayuda', resources());
    else if (action === 'question-instructions') showModal(state.form.name, `${state.form.instructions ? `<p class="battery-instructions">${esc(state.form.instructions)}</p>` : ''}${sourceView()}`);
    else if (action === 'close-modal') closeModal();
    else if (action === 'pause') { state.pauseView = state.view; state.view = 'paused'; render(); }
    else if (action === 'resume') { state.view = state.pauseView || 'question'; render(); }
    else if (action === 'danger-next' && state.dangerAnswer) {
      state.dangerChecked = true;
      if (state.dangerAnswer === 'yes') { state.blocked = true; state.view = 'safety'; render(); }
      else if (state.dangerNext === 'score') { state.blocked = false; await score(); }
      else if (state.dangerNext === 'result') { state.blocked = false; state.view = 'result'; render(); }
      else { state.blocked = false; nextQuestion(); }
    }
    else if (action === 'danger-correct') { state.dangerChecked = false; state.view = 'danger'; render(); }
    else if (action === 'motion') { const reduced = document.documentElement.classList.toggle('reduce-motion'); document.getElementById('motion-toggle').setAttribute('aria-pressed', String(reduced)); }
    else if (action === 'exit') { state.exiting = true; state.answers = {}; state.drafts = {}; state.results = {}; state.result = null; location.replace('https://www.google.com/'); }
  } finally { if(serial)state.navBusy=false; }
  });
  document.addEventListener('click', event => { if (event.target.classList.contains('modal-backdrop')) closeModal(); });
  let escapes = [];
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      if (modalRoot.childElementCount) { closeModal(); return; }
      const now = Date.now(); escapes = [...escapes.filter(time => now - time < 1800), now];
      if (escapes.length >= 3) { state.exiting = true; location.replace('https://www.google.com/'); }
    }
    if (event.key === 'Tab' && modalRoot.childElementCount) {
      const controls = [...modalRoot.querySelectorAll('button,a[href],input,[tabindex="0"]')].filter(control => !control.disabled);
      const first = controls[0], last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
    }
  });
  window.addEventListener('beforeunload', event => { if (!state.exiting && Object.values(state.drafts).some(draft => Object.keys(draft).length)) { event.preventDefault(); event.returnValue = ''; } });
  loadCatalog();
})();
