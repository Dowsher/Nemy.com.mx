(() => {
  'use strict';
  const uuid = () => crypto.randomUUID();
  async function post(path, body, token) {
    const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 30000);
    try {
      const response = await fetch(path, {method: 'POST', credentials: 'same-origin', cache: 'no-store', signal: controller.signal, headers: {'Content-Type':'application/json', Accept:'application/json', ...(token ? {'X-Traza-Visit':token} : {})}, body:JSON.stringify(body)});
      let data = {}; try { data = await response.json(); } catch (_) {}
      if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : data.detail?.message || 'No se pudo guardar. Tu respuesta sigue aquí; vuelve a intentar.');
      return data;
    } catch (error) { throw new Error(error.name === 'AbortError' ? 'El guardado tardó demasiado. Tu respuesta sigue aquí; vuelve a intentar.' : error.message); }
    finally { clearTimeout(timeout); }
  }
  function device() {
    const ua = navigator.userAgent || '', touch = navigator.maxTouchPoints || 0;
    const ios = /iPhone|iPad|iPod/.test(ua) || /Macintosh/.test(ua) && touch > 1;
    const os = ios ? 'iOS' : /Android/.test(ua) ? 'Android' : /Windows/.test(ua) ? 'Windows' : /Mac/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : 'other';
    const kind = /iPad|Tablet/.test(ua) || ios && !/iPhone/.test(ua) ? 'tablet' : /Mobile|iPhone|iPod/.test(ua) ? 'mobile' : 'desktop';
    const browser = /Edg\//.test(ua) ? 'Edge' : /Firefox\//.test(ua) ? 'Firefox' : /Chrome|CriOS/.test(ua) ? 'Chrome' : /Safari/.test(ua) ? 'Safari' : 'other';
    return {kind,os,browser};
  }
  class Activity {
    constructor(entry, onStatus = () => {}) { this.entry=entry; this.onStatus=onStatus; this.visitBody={event_id:uuid(),device:device(),viewport:{width:Math.max(1,Math.round(window.innerWidth)),height:Math.max(1,Math.round(window.innerHeight))},entry}; this.visit=null; this.visiting=null; this.session=null; this.queue=[]; this.sequence=0; this.running=null; this.reportPending=null; this.startPending=null; this.visitNow().catch(()=>{}); }
    async visitNow() { if(this.visit) return this.visit; if(this.visiting) return this.visiting; this.visiting=post('/api/activity/visits',this.visitBody).then(data=>{ if(!data.visit_token || !data.visit_id) throw new Error('No se pudo preparar el registro de esta visita.'); return this.visit=data; }).finally(()=>{this.visiting=null;}); return this.visiting; }
    async start(meta) { if(this.session) return this.session; const visit=await this.visitNow(); this.startPending ||= {event_id:uuid(),...meta,consent:{adult:true,storage:true,version:'5.0'}}; const data=await post('/api/activity/sessions',this.startPending,visit.visit_token); if(!data.session_id) throw new Error('No se pudo iniciar el registro. Vuelve a intentar.'); this.session=data; this.startPending=null; this.sequence=data.revision || 0; this.onStatus('saved'); return data; }
    reset() { if(this.queue.length || this.running) throw new Error('Guarda primero los cambios pendientes.'); this.session=null; this.sequence=0; this.startPending=null; this.reportPending=null; }
    event(type,form_id=null,question_id=null,value=null) { if(!this.session) return Promise.reject(new Error('Primero acepta el registro de respuestas.')); this.queue.push({event_id:uuid(),sequence:++this.sequence,type,form_id,question_id,value}); return this.flush(); }
    async flush() {
      if(this.running) { await this.running; if(this.queue.length) return this.flush(); return; }
      if(!this.queue.length) return;
      this.onStatus('saving');
      this.running=(async()=>{ while(this.queue.length) { const event=this.queue[0]; const data=await post(`/api/activity/sessions/${encodeURIComponent(this.session.session_id)}/events`,event,this.visit.visit_token); if(data.ok !== true || data.received_sequence !== event.sequence) throw new Error('El servidor no confirmó la respuesta. Vuelve a intentar.'); this.queue.shift(); } this.onStatus('saved'); })().catch(error=>{this.onStatus('error',error.message);throw error;}).finally(()=>{this.running=null;});
      return this.running;
    }
    async report(packet) { await this.flush(); this.reportPending ||= {event_id:uuid(),packet}; await post(`/api/activity/sessions/${encodeURIComponent(this.session.session_id)}/report`,this.reportPending,this.visit.visit_token); this.reportPending=null; this.onStatus('saved'); }
    async erase() {
      if(this.erasing) return this.erasing;
      if(!this.session || !this.visit) return;
      const sessionId=this.session.session_id,visitToken=this.visit.visit_token;
      this.erasing=(async()=>{
        await this.flush();
        const response=await fetch(`/api/activity/sessions/${encodeURIComponent(sessionId)}`,{method:'DELETE',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json','X-Traza-Visit':visitToken,Accept:'application/json'}});
        if(!response.ok) throw new Error('No se pudo borrar esta sesión. Vuelve a intentar.');
        this.reset();
      })().finally(()=>{this.erasing=null;});
      return this.erasing;
    }
  }
  window.TRAZA_ACTIVITY={Activity};
})();
