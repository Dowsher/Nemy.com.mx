'use strict';
(()=>{
const sections={'/traza':'traza','/instrumentos':'traza','/dtr-ga':'dtr','/adicciones':'umbral','/emociones':'emociones','/estancamiento':'impulso','/mapa':'mapa','/comunidad':'comunidad','/acompanar':'comunidad','/ayuda':'ayuda','/perfil':'perfil','/acceso':'perfil','/equipo':'equipo','/admin-actividad':'equipo','/administracion-comunidad':'equipo'};
function theme(){document.documentElement.dataset.section=sections[location.pathname]||'nemy';}
theme();window.addEventListener('popstate',theme);document.addEventListener('nemy:navigate',theme);
// DOM navigation by the existing SPA updates its main region; no tracking or storage.
const main=document.getElementById('main');if(main)new MutationObserver(theme).observe(main,{childList:true});
document.querySelectorAll('a[href="/dtr-ga"],a[href="/traza"],a[href="/adicciones"]').forEach(link=>{link.dataset.tool=sections[link.getAttribute('href')];});
if('IntersectionObserver' in window&&!matchMedia('(prefers-reduced-motion: reduce)').matches){const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('is-visible');observer.unobserve(entry.target);}}),{threshold:.08});document.querySelectorAll('.tool-card,.quote-card,.principles article,.mini-steps article').forEach(el=>{el.classList.add('neon-reveal');observer.observe(el);});}
})();
