'use strict';
(()=>{
const menu=document.querySelector('.menu-button'),nav=document.getElementById('navigation');
function closeMenu(){nav?.classList.remove('open');menu?.setAttribute('aria-expanded','false');}
menu?.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';menu.setAttribute('aria-expanded',String(open));nav.classList.toggle('open',open);});
nav?.addEventListener('click',event=>{if(event.target.closest('a'))closeMenu();});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&nav?.classList.contains('open')){closeMenu();menu.focus();}});
const motion=document.getElementById('motion');
motion?.addEventListener('click',()=>{const on=document.body.classList.toggle('reduce-motion');motion.setAttribute('aria-pressed',String(on));motion.textContent=on?'Activar movimiento':'Reducir movimiento';});
const content=document.getElementById('path-content');
const paths={self:'<div><span class="eyebrow">Tu camino / Para mí</span><h3>Comprender lo que te pasa es un comienzo.</h3><p>Explora el craving, organiza lo que sientes y encuentra apoyo para dar un siguiente paso a tu ritmo.</p></div><div class="path-links"><a href="/mi-recuperacion">Explorar mi camino <span>↗</span></a><a href="/traza">Evaluación voluntaria con TRAZA <span>↗</span></a><a href="/perfil">Mi seguimiento personal <span>↗</span></a></div>',close:'<div><span class="eyebrow">Tu camino / Para alguien que quiero</span><h3>Acompañar sin dejar de cuidarte.</h3><p>Comprende el consumo, aprende a conversar sin confrontar y encuentra herramientas para ofrecer apoyo con límites saludables.</p></div><div class="path-links"><a href="/acompanar">Explorar cómo acompañar <span>↗</span></a><a href="/adicciones">Comprender los mecanismos del consumo <span>↗</span></a><a href="/ayuda">Orientación ante situaciones de riesgo <span>↗</span></a></div>'};
document.querySelectorAll('[data-path]').forEach(button=>button.addEventListener('click',()=>{if(!content)return;document.querySelectorAll('[data-path]').forEach(other=>other.setAttribute('aria-pressed',String(other===button)));content.innerHTML=paths[button.dataset.path];}));
if('IntersectionObserver' in window&&!matchMedia('(prefers-reduced-motion: reduce)').matches){document.body.classList.add('reveal-ready');const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('seen');observer.unobserve(entry.target);}}),{threshold:.3});document.querySelectorAll('.manifesto-body p').forEach(p=>observer.observe(p));}
})();
