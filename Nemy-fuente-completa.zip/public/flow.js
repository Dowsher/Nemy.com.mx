/* TRAZA public self-exploration. Health responses exist only in this tab's memory.
   No browser persistence, analytics, third-party fonts, or direct provider requests. */
(() => {
  'use strict';
  const main = document.getElementById('main');
  const modalRoot = document.getElementById('modal-root');
  const announcer = document.getElementById('announcer');
  const motionPreference = window.matchMedia('(prefers-reduced-motion: reduce)');
  const blocks = ['present', 'experiences', 'impact', 'support'];
  const icons = {
    present: '<path d="M4 15h4l3-9 4 18 3-9h8"/>',
    experiences: '<path d="M5 8h20v18H5zM10 4v8M20 4v8M5 15h20M10 20h3M17 20h3"/>',
    impact: '<circle cx="15" cy="15" r="11"/><path d="M15 8v7l5 3"/>',
    support: '<path d="M15 26S3 19 3 10a7 7 0 0 1 12-4 7 7 0 0 1 12 4c0 9-12 16-12 16Z"/>',
    pause: '<path d="M10 6v18M20 6v18"/>',
    safety: '<path d="M15 3 26 8v8c0 7-11 12-11 12S4 23 4 16V8Z"/><path d="m10 15 3 3 7-7"/>'
  };
  const state = {
    screen: 'home', schema: null, schemaError: '', loadingSchema: true,
    adult: false, processing: false, answers: {}, currentId: null,
    selected: null, introduced: new Set(), block: null, resume: null,
    sticky: {peak_distress: 0, current_risk: false, unsafe: false},
    safetyReason: '', result: null, feedback: null, error: '', requestId: null,
    packet: null, controller: null, editing: false, exiting: false,
    reducedMotion: motionPreference.matches
  };
  let returnFocus = null;
  let escapeTimes = [];
  const esc = value => String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const svg = name => `<svg viewBox="0 0 30 30" aria-hidden="true">${icons[name] || icons.present}</svg>`;
  const arrow = '<span class="arrow" aria-hidden="true">→</span>';
  const primary = (label, action, disabled = false) => `<button class="primary" data-action="${action}"${disabled ? ' disabled' : ''}>${label}${arrow}</button>`;
  const top = (action = 'back', label = 'Volver', step = '') => `<div class="screen-top"><button class="back-button" data-action="${action}"><span aria-hidden="true">←</span>${label}</button><span class="step-label">${esc(step)}</span></div>`;
  const getBlock = id => state.schema?.blocks.find(item => item.id === id) || {id, title: id, description: ''};
  const getQuestion = id => state.schema?.questions.find(item => item.id === id);
  const has = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
  const isKnown = value => Number.isInteger(value) && value >= 0 && value < 98;
  const isVisible = question => !question.show_if || (question.show_if.any || []).some(condition => state.answers[condition.id] === condition.equals);
  const visibleQuestions = () => (state.schema?.questions || []).filter(isVisible);
  const answeredQuestions = () => visibleQuestions().filter(q => has(state.answers, q.id));
  const safetyBlocked = () => state.sticky.current_risk || state.sticky.unsafe || state.sticky.peak_distress >= 8;
  const safetyClear = () => state.answers.S1 === 1 && state.answers.S3 === 0 && Number.isInteger(state.answers.S2) && state.answers.S2 >= 0 && state.answers.S2 < 8 && !safetyBlocked();
  const answerLabel = (q, value) => Array.isArray(value) ? value.map(v => q.options.find(o => o.value === v)?.label || String(v)).join(' · ') : (q.options.find(o => o.value === value)?.label || 'Sin responder');
  function announce(text) { announcer.textContent = ''; window.setTimeout(() => { announcer.textContent = text; }, 30); }
  function focusMain() { main.focus({preventScroll: true}); window.scrollTo({top: 0, behavior: 'instant'}); }
  function cleanHiddenAnswers() {
    for (const q of state.schema.questions) if (!isVisible(q)) delete state.answers[q.id];
  }
  function invalidateResult() { state.result = null; state.feedback = null; state.requestId = null; state.packet = null; state.error = ''; }
  function counts() {
    const qs = answeredQuestions().filter(q => q.block !== 'safety');
    const known = qs.filter(q => Array.isArray(state.answers[q.id]) ? state.answers[q.id].some(isKnown) : isKnown(state.answers[q.id]));
    const present = known.filter(q => q.block === 'present').length;
    const impact = known.filter(q => q.block === 'impact').length;
    return {total: qs.length, known: known.length, skipped: qs.filter(q => state.answers[q.id] === 98).length, present, impact};
  }
  function canAnalyze() {
    const c = counts();
    const limits = state.schema?.limits || {};
    return safetyClear() && c.present >= (limits.min_present_answers || 3) && c.impact >= (limits.min_impact_answers || 1);
  }
  function show(screen, focus = true) {
    state.screen = screen;
    render();
    if (focus) focusMain();
  }
  function render() {
    const views = {home: homeView, consent: consentView, block: blockView, question: questionView, review: reviewView, aiConsent: aiConsentView, loading: loadingView, result: resultView, safety: safetyView, paused: pausedView};
    main.innerHTML = (views[state.screen] || homeView)();
    document.getElementById('pause-button').hidden = !['block','question','review','aiConsent','result'].includes(state.screen);
    document.documentElement.classList.toggle('reduce-motion', state.reducedMotion);
    const motion = document.getElementById('motion-toggle');
    motion.setAttribute('aria-pressed', String(state.reducedMotion));
    motion.textContent = state.reducedMotion ? 'Movimiento reducido ✓' : 'Reducir movimiento';
  }
  function homeView() {
    return `<section class="view home-view"><p class="eyebrow"><span class="eyebrow-dot"></span>Un paso para entenderte</p><h1>Dale sentido a<br><em>lo que sientes.</em></h1><p class="lead">Responde preguntas sobre lo que sientes y has vivido. Al terminar, revisa tus respuestas o crea un mapa con IA.</p><div class="home-action">${primary('Empezar', 'start', state.loadingSchema || !!state.schemaError)}<span class="time-note"><strong>4 bloques cortos</strong>Una pregunta a la vez</span></div>${state.loadingSchema ? '<p class="inline-loading" role="status">Preparando tu recorrido…</p>' : ''}${state.schemaError ? `<div class="error-box" role="alert"><p>${esc(state.schemaError)}</p><button class="text-button" data-action="retry-schema">Volver a intentar →</button></div>` : ''}<p class="home-privacy"><svg viewBox="0 0 18 18" aria-hidden="true"><rect x="4" y="8" width="10" height="8" rx="2"/><path d="M6 8V5a3 3 0 0 1 6 0v3"/></svg>Sin nombre ni cuenta.</p><div class="home-blocks"><p>Cuatro temas para empezar</p><div class="block-tiles"><div class="block-tile">${svg('present')}Lo que notas hoy</div><div class="block-tile">${svg('experiences')}Cosas que has vivido</div><div class="block-tile">${svg('impact')}Cómo influye en tu día</div><div class="block-tile">${svg('support')}Lo que te acompaña</div></div></div><div class="library-entry"><div><h2>Explora un tema concreto</h2><p>Cuestionarios de ánimo, ansiedad, atención, experiencias y consumo.</p></div><a class="secondary" href="/instrumentos">Ver cuestionarios →</a></div></section>`;
  }
  function consentView() {
    return `<section class="view">${top('home', 'Volver', 'Antes de empezar')}<div class="panel"><p class="eyebrow"><span class="eyebrow-dot"></span>Datos y condiciones</p><h1>Antes de empezar.</h1><p class="lead">Elige opciones sobre cómo te has sentido y las experiencias que reconoces. No se piden relatos.</p><div class="note-box mint">Tus respuestas se quedan en esta pestaña hasta que decidas enviarlas para crear un mapa con IA. También puedes verlas sin usar IA.</div><div class="check-list"><label class="consent-check"><input type="checkbox" id="adult-consent"${state.adult ? ' checked' : ''}><span>Tengo <strong>18 años o más</strong>.</span></label><label class="consent-check"><input type="checkbox" id="processing-consent"${state.processing ? ' checked' : ''}><span>Acepto que TRAZA organice mis respuestas en esta pestaña para mi autoexploración. Sé que esto <strong>no confirma un diagnóstico</strong>.</span></label></div><p class="small muted">Si recargas o cierras la pestaña, se pierden tus respuestas. Al terminar podrás guardarlas en tu dispositivo.</p><div class="action-row spread"><button class="text-button" data-action="privacy">Leer sobre mis datos</button>${primary('Comenzar', 'begin', !(state.adult && state.processing))}</div></div></section>`;
  }
  function progress(block, current = 0, total = 0) {
    if (block === 'safety') return `<div class="progress-row"><span class="question-block" style="margin:0">Primero, cómo estás ahora</span><span class="question-step">${current} de ${total}</span></div>`;
    const index = blocks.indexOf(block);
    return `<div class="progress-row"><div class="progress-segments" aria-label="Bloque ${index + 1} de 4">${blocks.map((b, i) => `<i class="${i < index ? 'done' : i === index ? 'current' : ''}"></i>`).join('')}</div><span class="step-label">Bloque ${index + 1} de 4</span>${total ? `<span class="question-step">${current} de ${total}</span>` : ''}</div>`;
  }
  function blockView() {
    const b = getBlock(state.block);
    const sensitive = b.id === 'experiences';
    const intro = sensitive ? 'Indica cuáles experiencias reconoces y cuáles prefieres omitir.' : b.id === 'present' ? 'Responde pensando en las últimas dos semanas.' : b.description;
    return `<section class="view block-view" data-block="${esc(b.id)}">${top('block-back', 'Volver')}${progress(b.id)}<div class="block-icon">${svg(b.id)}</div><h1>${esc(b.title)}.</h1><p class="lead">${esc(intro)}</p><div class="action-row">${primary('Continuar', 'enter-block')}${sensitive ? '<button class="quiet-button" data-action="skip-block">Pasar este bloque</button>' : ''}</div><p class="block-count">${visibleQuestions().filter(q => q.block === b.id).length} preguntas</p></section>`;
  }
  function optionMarkup(q, option, range = false) {
    const value = option.value;
    const checked = Array.isArray(state.selected) ? state.selected.includes(value) : state.selected === value;
    return `<label class="option${checked ? ' chosen' : ''}${value >= 98 ? ' unknown' : ''}${range ? ' range-option' : ''}"><input type="${q.type === 'multi' ? 'checkbox' : 'radio'}" name="answer" value="${esc(value)}"${checked ? ' checked' : ''}${range ? ` aria-label="${esc(option.label)}"` : ''}><span>${range ? esc(value) : esc(option.label)}</span><span class="option-check" aria-hidden="true">✓</span></label>`;
  }
  function questionView() {
    const q = getQuestion(state.currentId);
    if (!q) return '<p class="error-box">No pudimos cargar esta pregunta. Vuelve al inicio para intentarlo otra vez.</p>';
    const qs = visibleQuestions().filter(item => item.block === q.block);
    const pos = qs.findIndex(item => item.id === q.id) + 1;
    const options = q.type === 'range' ? `<div class="range-options">${q.options.filter(o => o.value < 98).map(o => optionMarkup(q,o,true)).join('')}</div><div class="range-ends"><span>0 · Nada</span><span>10 · Demasiado ahora</span></div><div class="unknown-options">${q.options.filter(o => o.value >= 98).map(o => optionMarkup(q,o)).join('')}</div>` : `<div class="options">${q.options.filter(o => o.value < 98).map(o => optionMarkup(q,o)).join('')}</div><div class="unknown-options">${q.options.filter(o => o.value >= 98).map(o => optionMarkup(q,o)).join('')}</div>`;
    const selected = state.selected !== null && (!Array.isArray(state.selected) || state.selected.length > 0);
    const subtitle = q.block === 'present' ? 'Piensa en las últimas dos semanas.' : q.block === 'experiences' ? '' : '';
    return `<section class="view question-view">${top('back', state.editing ? 'Volver a mis respuestas' : 'Volver', state.editing ? 'Editar respuesta' : '')}${progress(q.block, pos, qs.length)}${q.block !== 'safety' ? `<p class="question-block">${esc(getBlock(q.block).title)}</p>` : ''}<form id="question-form"><fieldset class="question-form"><legend class="question-title" id="question-title">${esc(q.text)}</legend>${q.hint || subtitle ? `<p class="question-hint" id="question-hint">${esc(q.hint || subtitle)}</p>` : ''}${q.type === 'multi' ? '<p class="multiple-note">Puedes elegir más de una opción.</p>' : ''}${options}</fieldset><div class="question-actions"><button type="button" class="quiet-button" data-action="skip">Pasar por ahora</button><button type="submit" class="primary" id="question-next"${selected ? '' : ' disabled'}>${state.editing ? 'Guardar cambio' : 'Continuar'}${arrow}</button></div></form></section>`;
  }
  function answerGroups(editable = true, includeSafety = false) {
    const ids = includeSafety ? ['safety', ...blocks] : blocks;
    return ids.map(id => {
      const qs = answeredQuestions().filter(q => q.block === id);
      if (!qs.length) return '';
      return `<details class="answer-group"><summary>${esc(getBlock(id).title)}<small>${qs.length}</small></summary><ul class="answer-list">${qs.map(q => `<li>${editable ? `<button class="answer-edit" data-action="edit" data-id="${esc(q.id)}" aria-label="Editar: ${esc(q.text)}">Editar</button>` : ''}<strong>${esc(q.text)}</strong><span class="answer-value${state.answers[q.id] >= 98 ? ' skipped' : ''}">${esc(answerLabel(q,state.answers[q.id]))}</span></li>`).join('')}</ul></details>`;
    }).join('');
  }
  const exportsMarkup = () => '<div class="export-actions no-print"><button class="secondary" data-action="download">Guardar en mi dispositivo ↓</button><button class="secondary" data-action="print">Imprimir / PDF ↗</button></div>';
  function reviewView() {
    const c = counts();
    const enough = canAnalyze();
    const available = state.schema.ai_available;
    return `<section class="view"><div class="print-heading">TRAZA · Mis respuestas · ${esc(new Date().toLocaleDateString('es-MX'))}</div>${top(state.safetyReason ? 'safety-return' : 'review-back', 'Volver')}<div class="review-head"><p class="eyebrow"><span class="eyebrow-dot"></span>Lo que tú respondiste</p><h1>Tu recorrido, a la vista.</h1><p class="lead">Estas son tus respuestas, sin interpretación. Puedes revisar o cambiar lo que necesites.</p><div class="review-stats"><span class="small-tag">${c.known} respuestas elegidas</span>${c.skipped ? `<span class="small-tag lilac">${c.skipped} preguntas pasadas</span>` : ''}</div></div>${state.error ? `<div class="error-box" role="alert">${esc(state.error)}</div>` : ''}${answerGroups(!safetyBlocked(),true) || '<p class="empty-note">Todavía no hay respuestas. Puedes empezar cuando quieras.</p>'}${enough ? `<div class="review-ai-card no-print"><h2>¿Quieres unir las piezas?</h2><p>Una IA puede organizar lo que elegiste y proponer temas para explorar. Antes de enviar algo, verás exactamente qué se comparte.</p>${available ? primary('Crear mi mapa con IA', 'ai-consent') : '<p class="small">La IA no está disponible ahora. Tus respuestas siguen aquí y puedes guardarlas.</p>'}</div>` : `<div class="note-box no-print">${safetyBlocked() || state.safetyReason ? 'Este recorrido se detuvo para cuidar tu seguridad. Aquí puedes consultar lo que respondiste; no se enviará a la IA.' : 'Con lo que hay todavía no podemos crear un mapa con IA. Hace falta elegir al menos 3 respuestas sobre lo que notas hoy y 1 sobre cómo influye en tu día. Puedes retomarlas si quieres, sin responder experiencias que prefieras pasar.'}</div>`}${exportsMarkup()}<p class="tiny muted no-print" style="margin-top:14px">El archivo contiene información personal. Guárdalo solo donde tú decidas.</p></section>`;
  }
  function newUuid() {
    if (window.crypto.randomUUID) return window.crypto.randomUUID();
    const bytes = window.crypto.getRandomValues(new Uint8Array(16));
    bytes[6] = (bytes[6] & 15) | 64; bytes[8] = (bytes[8] & 63) | 128;
    const h = Array.from(bytes, b => b.toString(16).padStart(2,'0')).join('');
    return `${h.slice(0,8)}-${h.slice(8,12)}-${h.slice(12,16)}-${h.slice(16,20)}-${h.slice(20)}`;
  }
  function makePacket() {
    cleanHiddenAnswers();
    if (!state.requestId) state.requestId = newUuid();
    return {answers: {...state.answers}, consent: {adult: state.adult, processing: state.processing, ai: true, version: '2.0'}, request_id: state.requestId, safety_state: {...state.sticky}};
  }
  function aiConsentView() {
    if (!state.packet) state.packet = makePacket();
    const nonSafety = answeredQuestions().filter(q => q.block !== 'safety');
    return `<section class="view">${top('review', 'Volver a mis respuestas')}<div class="panel"><p class="eyebrow"><span class="eyebrow-dot"></span>Solo si tú decides</p><h1>Crea tu mapa con IA.</h1><p class="lead">La IA leerá las opciones que elegiste para agruparlas y proponer preguntas para explorar.</p><div class="note-box lilac"><strong>Qué se comparte</strong><br>TRAZA recibe tus respuestas y comprueba tu seguridad. A OpenAI se envían ${nonSafety.length} respuestas de los cuatro bloques; las tres respuestas de seguridad se quedan fuera del mensaje a OpenAI. No pedimos nombre, correo ni relatos.</div><details class="answer-group"><summary>Ver las respuestas que leerá la IA<small>${nonSafety.length}</small></summary><ul class="answer-list">${nonSafety.map(q => `<li><strong>${esc(q.text)}</strong><span class="answer-value">${esc(answerLabel(q,state.answers[q.id]))}</span></li>`).join('')}</ul></details><details class="simple-details"><summary>Ver el paquete exacto enviado a TRAZA</summary><p class="small muted">Los códigos son las opciones que elegiste. S1–S3 y safety_state se usan para comprobar seguridad en TRAZA; no se incluyen en el mensaje a OpenAI.</p><pre class="packet-preview">${esc(JSON.stringify(state.packet,null,2))}</pre></details><p class="small muted" style="margin-top:21px">TRAZA no guarda el recorrido en su base de datos; conserva temporalmente el resultado en memoria hasta 15 minutos para evitar repetir envíos. OpenAI puede conservar registros de seguridad hasta 30 días. El mapa puede equivocarse y no confirma un diagnóstico.</p>${state.error ? `<div class="error-box" role="alert">${esc(state.error)}</div>` : ''}<label class="consent-check"><input type="checkbox" id="ai-consent"><span><strong>Acepto este envío</strong> a TRAZA y OpenAI para crear mi mapa, con los datos y condiciones que acabo de revisar.</span></label><div class="action-row">${primary('Crear mi mapa con IA', 'analyze', true)}</div><button class="text-button" data-action="review">Seguir solo con mis respuestas</button></div></section>`;
  }
  function loadingView() {
    return `<section class="view loading-view"><div class="loading-symbol" aria-hidden="true"><div class="spinner"></div></div><p class="eyebrow" style="justify-content:center">La IA está leyendo tus respuestas</p><h1>Estamos armando tu mapa.</h1><p class="lead">Puede tardar alrededor de un minuto. No tienes que hacer nada más.</p><button class="quiet-button" data-action="cancel-ai">Volver a mis respuestas</button><p class="tiny muted">El envío ya se realizó. Volver detiene la espera, pero no retira los datos ya enviados.</p></section>`;
  }
  function recognizedExperiences(result) {
    const selected = (result.facts || []).filter(fact => /^E(?:[1-9]|10)$/.test(fact.id) && fact.answer_label === getQuestion(fact.id)?.options.find(option => option.value === 1)?.label);
    const list = facts => `<ul class="evidence-list">${facts.map(fact => `<li>${esc(fact.question)}<span>Marcaste: ${esc(fact.answer_label)}</span></li>`).join('')}</ul>`;
    return `<section class="result-section experience-record"><h2>Experiencias que reconociste</h2>${selected.length ? `${list(selected.slice(0,3))}${selected.length > 3 ? `<details class="simple-details"><summary>Ver ${selected.length - 3} experiencias más</summary>${list(selected.slice(3))}</details>` : ''}<p class="tiny muted">Esta lista solo reúne los «Sí» que elegiste. Las dudas y las preguntas pasadas no se interpretan como «No».</p>` : '<p class="small">No hay experiencias concretas elegidas en este registro. La IA no añade otras a partir de lo que sientes.</p><p class="tiny muted">Las dudas y las preguntas pasadas no se interpretan como «No».</p>'}</section>`;
  }
  function resultView() {
    const result = state.result;
    if (!result?.analysis) return reviewView();
    const a = result.analysis;
    const facts = new Map((result.facts || []).map(f => [f.id, f]));
    const generated = new Date(result.meta.generated_at);
    return `<section class="view result-view"><div class="print-heading">TRAZA · Mapa para explorar · ${esc(generated.toLocaleDateString('es-MX'))}</div>${top('review', 'Mis respuestas')}<p class="eyebrow"><span class="eyebrow-dot"></span>Tu mapa para explorar</p><h1 class="result-title">${esc(a.title)}</h1><p class="result-summary">${esc(a.summary)}</p><p class="result-boundary">Este mapa orienta; no confirma un diagnóstico.</p>${recognizedExperiences(result)}<section class="result-section"><h2>Respuestas que la IA agrupó</h2>${a.patterns.length ? a.patterns.map(pattern => `<article class="pattern-card"><h3>${esc(pattern.title)}</h3><p class="small muted">Agrupa ${pattern.evidence_ids.length} de tus respuestas.</p><p class="uncertainty">${esc(pattern.uncertainty)}</p><details class="simple-details evidence-details"><summary>¿En qué respuestas se apoya?</summary><ul class="evidence-list">${pattern.evidence_ids.map(id => {const fact=facts.get(id);return fact ? `<li>${esc(fact.question)}<span>${esc(fact.answer_label)}</span></li>` : '';}).join('')}</ul></details></article>`).join('') : '<p class="empty-note">La IA no propuso patrones con estas respuestas. Puedes consultar el registro de tus respuestas.</p>'}</section>${a.reflection_questions.length ? `<section class="result-section"><h2>Preguntas que puedes llevarte</h2><ul class="reflection-list">${a.reflection_questions.map(text => `<li>${esc(text)}</li>`).join('')}</ul></section>` : ''}${a.supports.length ? `<section class="result-section"><h2>Apoyos para tener presentes</h2><ul class="support-list">${a.supports.map(text => `<li>${esc(text)}</li>`).join('')}</ul></section>` : ''}<section class="result-section"><h2>Lo que tú respondiste</h2><p class="small muted">Tu registro se mantiene separado de las observaciones de la IA.</p>${answerGroups(false)}</section><div class="feedback-box no-print"><h2>¿Te hace sentido este mapa?</h2><div class="feedback-choices">${[['yes','Sí'],['partly','En parte'],['no','No']].map(([value,label]) => `<button data-action="feedback" data-value="${value}" aria-pressed="${state.feedback === value}">${label}</button>`).join('')}</div><p class="small" id="feedback-note">${state.feedback ? 'Tu opinión quedó marcada en esta pestaña. No se envía ni se usa para entrenar al modelo.' : 'Esto es para tu propia revisión. Tu respuesta no se envía ni entrena al modelo.'}</p></div><details class="simple-details metadata-details"><summary>Cómo se armó este mapa</summary><p class="small">${esc(a.limitations)}</p><dl class="metadata"><dt>Proveedor</dt><dd>${esc(result.meta.provider)}</dd><dt>Modelo</dt><dd>${esc(result.meta.model)}</dd><dt>Versión de instrucciones</dt><dd>${esc(result.meta.prompt_version)}</dd><dt>Creado</dt><dd>${esc(generated.toLocaleString('es-MX'))}</dd><dt>Solicitud</dt><dd>${esc(result.meta.request_id)}</dd></dl><p class="small muted">La IA agrupó tus respuestas y propuso preguntas para explorar. Los títulos, el resumen, las observaciones y los apoyos se construyen con las opciones que marcaste. No se buscó información externa. El mapa no demuestra causas ni identifica experiencias que no hayas reportado.</p></details>${exportsMarkup()}<div class="action-row result-actions no-print"><button class="quiet-button" data-action="restart">Cerrar este recorrido</button></div></section>`;
  }
  function resourceCards() {
    return '<div class="resource-card"><h3>Si hay peligro inmediato</h3><p>Busca un lugar más seguro si puedes y pide compañía a alguien de confianza.</p><a class="call" href="tel:911">Llamar al 911 <span aria-hidden="true">↗</span></a></div><div class="resource-card"><h3>Hablar con alguien ahora</h3><p>La Línea de la Vida ofrece orientación en salud mental en México, las 24 horas.</p><a class="call" href="tel:+528009112000?oai_link_source=model_response_hotline">800 911 2000 <span aria-hidden="true">↗</span></a><a class="source-link" href="https://www.gob.mx/conasama/articulos/linea-de-la-vida-800-911-2000?oai_link_source=model_response_hotline" target="_blank" rel="noopener noreferrer">Información oficial de la Línea de la Vida ↗</a></div>';
  }
  function safetyView() {
    const unclear = state.safetyReason === 'unclear';
    return `<section class="view safety-view"><div class="safety-symbol">${svg('safety')}</div><p class="eyebrow"><span class="eyebrow-dot"></span>Estado actual</p><h1>${unclear ? 'Falta comprobar el estado actual.' : 'El recorrido está detenido.'}</h1><p class="lead">${unclear ? 'Revisa las preguntas del estado actual para continuar.' : 'Marcaste peligro actual o malestar alto. El recorrido se detuvo y las respuestas no se enviarán a la IA.'}</p>${resourceCards()}<details class="simple-details"><summary>Tomarme un momento aquí</summary><p class="small">Si te resulta cómodo, mira a tu alrededor. Nota el apoyo del suelo o de la silla y ubica algo que puedas ver. No necesitas continuar ahora.</p></details><div class="action-row">${unclear ? '<button class="secondary" data-action="review-safety">Revisar mis respuestas de seguridad</button>' : ''}<button class="quiet-button" data-action="review">Ver lo que respondí</button><button class="quiet-button" data-action="restart">Cerrar este recorrido</button></div></section>`;
  }
  function pausedView() {
    return `<section class="view paused-view"><div class="block-icon">${svg('pause')}</div><p class="eyebrow" style="justify-content:center">Pausa</p><h1>Recorrido en pausa.</h1><p class="lead">Tus respuestas siguen aquí mientras mantengas esta pestaña abierta. Puedes volver cuando quieras.</p><div class="action-row">${primary('Retomar mi recorrido', 'resume')}<button class="quiet-button" data-action="review">Ver lo que llevo</button></div><button class="text-button" data-action="restart">Cerrar y borrar respuestas</button></section>`;
  }
  function openModal(title, content) {
    returnFocus = document.activeElement;
    modalRoot.innerHTML = `<div class="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title" tabindex="-1"><div class="modal-head"><h2 id="modal-title">${esc(title)}</h2><button class="modal-close" data-action="close-modal" aria-label="Cerrar">×</button></div>${content}</section></div>`;
    document.body.style.overflow = 'hidden';
    modalRoot.querySelector('.modal-close').focus();
  }
  function closeModal() { modalRoot.innerHTML = ''; document.body.style.overflow = ''; if (returnFocus?.isConnected) returnFocus.focus(); }
  function aboutModal() {
    openModal('Un recorrido para entenderte', '<p>TRAZA te ayuda a ordenar lo que notas hoy, las experiencias difíciles que tú reconoces y los apoyos con los que cuentas.</p><h3>¿Tengo que saber qué es un trauma?</h3><p>No. Algunas experiencias difíciles pueden dejar huella en cómo nos sentimos. Aquí no necesitas ponerles una etiqueta ni buscar recuerdos.</p><h3>¿Qué voy a hacer?</h3><p>Primero revisas cómo estás ahora. Después respondes cuatro bloques, una pregunta a la vez. Puedes pasar cualquier pregunta, volver o pausar.</p><h3>¿Qué obtengo?</h3><p>Un registro de tus respuestas. Si decides compartirlas con OpenAI, una IA crea un mapa con temas posibles para explorar y muestra en qué respuestas se apoya.</p><h3>¿Qué alcance tiene?</h3><p>Son preguntas originales de autoexploración, no una escala clínica validada. La IA puede equivocarse: no confirma traumas, diagnósticos, causas ni recuerdos. No sustituye una evaluación profesional ni atiende emergencias.</p><button class="primary" data-action="close-modal">Lo tengo claro →</button>');
  }
  function privacyModal() {
    openModal('Tus respuestas, tu decisión', '<h3>Mientras respondes</h3><p>Las respuestas se mantienen en la memoria de esta pestaña. No se guardan en el navegador ni se envían automáticamente. No pedimos nombre, correo, dirección ni relatos.</p><h3>Si eliges crear un mapa con IA</h3><p>Primero ves el paquete exacto y aceptas enviarlo. El servidor de TRAZA recibe tus opciones y la comprobación de seguridad; las respuestas de seguridad no se incluyen en el mensaje a OpenAI. OpenAI recibe las opciones de los cuatro bloques para generar el mapa.</p><p>TRAZA no guarda las respuestas ni el mapa en su base de datos. Para evitar repetir envíos conserva temporalmente el resultado en memoria hasta 15 minutos. OpenAI puede retener registros de seguridad hasta 30 días; desactivar el almacenamiento de la respuesta no garantiza retención cero.</p><h3>Información técnica</h3><p>El servicio usa contadores sin respuestas para limitar abusos. El servidor de alojamiento procesa datos técnicos de conexión, como la dirección IP. No se usan las respuestas para publicidad ni se recogen opiniones para entrenar al modelo.</p><h3>Guardar o cerrar</h3><p>Al cerrar o recargar se pierde el recorrido. Puedes descargar un archivo o imprimirlo: esos documentos sí pueden quedar en tu dispositivo. «Salir» borra el estado de esta pestaña y abre una página neutra; no borra el historial del navegador.</p><button class="primary" data-action="close-modal">Entendido →</button>');
  }
  function helpModal() { openModal('Ayuda a tu alcance', resourceCards() + '<p class="small muted" style="margin-top:19px">TRAZA no es un servicio de urgencias ni envía alertas a otras personas.</p>'); }
  function startQuestion(id, editing = false) {
    const q = getQuestion(id); if (!q) return;
    state.currentId = id; state.selected = has(state.answers,id) ? (Array.isArray(state.answers[id]) ? [...state.answers[id]] : state.answers[id]) : null;
    state.editing = editing; show('question');
  }
  function nextQuestion() {
    const q = getQuestion(state.currentId);
    const qs = visibleQuestions();
    const index = qs.findIndex(item => item.id === q.id);
    const next = qs[index + 1];
    if (q.block === 'safety' && next?.block !== 'safety' && !safetyClear()) { state.safetyReason = 'unclear'; show('safety'); return; }
    if (q.block === 'safety' && next?.block !== 'safety' && safetyClear()) state.safetyReason = '';
    if (!next) { show('review'); return; }
    if (next.block !== 'safety' && !state.introduced.has(next.block)) { state.block = next.block; show('block'); }
    else startQuestion(next.id);
  }
  function commitAnswer(value) {
    const q = getQuestion(state.currentId); if (!q) return;
    state.answers[q.id] = value;
    if (q.id === 'S1' && value === 0) state.sticky.unsafe = true;
    if (q.id === 'S3' && value === 1) state.sticky.current_risk = true;
    if (q.id === 'S2' && isKnown(value)) state.sticky.peak_distress = Math.max(state.sticky.peak_distress,value);
    cleanHiddenAnswers(); invalidateResult();
    if (safetyBlocked()) { state.safetyReason = 'risk'; state.editing = false; show('safety'); return; }
    if (state.editing) {
      state.editing = false;
      if (['S1','S2','S3'].includes(q.id) && !safetyClear()) { state.safetyReason = 'unclear'; show('safety'); }
      else { state.safetyReason = ''; show('review'); }
      return;
    }
    nextQuestion();
  }
  function backQuestion() {
    if (state.editing) { state.editing = false; show('review'); return; }
    const qs = visibleQuestions();
    const index = qs.findIndex(q => q.id === state.currentId);
    if (index <= 0) show('consent');
    else startQuestion(qs[index - 1].id);
  }
  function resetJourney() {
    if (state.controller) state.controller.abort();
    state.adult = false; state.processing = false; state.answers = {}; state.currentId = null; state.selected = null;
    state.introduced = new Set(); state.block = null; state.resume = null;
    state.sticky = {peak_distress:0,current_risk:false,unsafe:false};
    state.safetyReason = ''; state.result = null; state.feedback = null; state.error = ''; state.requestId = null; state.packet = null; state.controller = null; state.editing = false;
  }
  function restart() {
    if (Object.keys(state.answers).length) openModal('Cerrar este recorrido', '<p>Se borrarán las respuestas y el mapa de esta pestaña. Si quieres conservarlos, vuelve y guárdalos antes.</p><div class="action-row"><button class="primary" data-action="confirm-restart">Cerrar y borrar</button><button class="quiet-button" data-action="close-modal">Volver</button></div>');
    else { resetJourney(); show('home'); }
  }
  function safeExit() {
    state.exiting = true; resetJourney();
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    location.replace('https://www.google.com/');
  }
  async function analyze() {
    if (state.screen !== 'aiConsent' || state.controller || !document.getElementById('ai-consent')?.checked || !canAnalyze() || !state.schema.ai_available) return;
    const packet = state.packet || makePacket();
    state.error = ''; state.controller = new AbortController();
    const controller = state.controller;
    show('loading');
    const timeout = window.setTimeout(() => controller.abort('timeout'),70000);
    try {
      const response = await fetch('/api/explore/analyze', {method:'POST', credentials:'omit', headers:{'Content-Type':'application/json','Accept':'application/json'}, cache:'no-store', body:JSON.stringify(packet), signal:controller.signal});
      let data; try { data = await response.json(); } catch { throw new Error('No pudimos leer la respuesta del servicio. Tus respuestas siguen aquí.'); }
      if (!response.ok) {
        if (data.code === 'safety_blocked' || data.detail?.code === 'safety_blocked') { state.safetyReason = 'risk'; show('safety'); return; }
        const detail = typeof data.detail === 'string' ? data.detail : (data.detail?.message || data.message);
        throw new Error(detail || 'La IA no pudo crear el mapa ahora. Tus respuestas siguen aquí; puedes guardarlas o intentarlo después.');
      }
      if (!data.analysis || !Array.isArray(data.analysis.patterns) || !data.meta || !Array.isArray(data.facts)) throw new Error('La IA no devolvió un mapa válido. Tus respuestas siguen aquí y no mostraremos un resultado incompleto.');
      if (controller.signal.aborted || state.screen !== 'loading') return;
      state.result = data; show('result'); announce('Tu mapa está listo. Puedes revisar las observaciones y sus respuestas de apoyo.');
    } catch (error) {
      if (state.screen !== 'loading') return;
      state.error = error.name === 'AbortError' ? 'La respuesta está tardando más de lo esperado. Tus respuestas siguen aquí. Puedes volver a intentarlo con el mismo envío.' : error.message;
      show('aiConsent');
    } finally { window.clearTimeout(timeout); if (state.controller === controller) state.controller = null; }
  }
  async function loadSchema() {
    state.loadingSchema = true; state.schemaError = ''; render();
    const controller = new AbortController(); const timer = window.setTimeout(() => controller.abort(),15000);
    try {
      const response = await fetch('/api/explore/schema', {cache:'no-store',credentials:'omit',headers:{Accept:'application/json'},signal:controller.signal});
      if (!response.ok) throw new Error();
      const schema = await response.json();
      if (schema.version !== '2.0' || !Array.isArray(schema.questions) || !Array.isArray(schema.blocks) || !schema.questions.length) throw new Error();
      state.schema = schema;
    } catch { state.schemaError = 'No pudimos cargar las preguntas. Revisa tu conexión y vuelve a intentar.'; }
    finally { window.clearTimeout(timer); state.loadingSchema = false; if (state.screen === 'home') render(); }
  }
  function downloadReport() {
    const report = {product:'TRAZA',version:'2.0',exported_at:new Date().toISOString(),purpose:'Registro personal de autoexploración; no confirma un diagnóstico',answers:answeredQuestions().map(q => ({id:q.id,block:q.block,question:q.text,value:state.answers[q.id],answer:answerLabel(q,state.answers[q.id])})), ...(state.result ? {ai_map:state.result} : {}), ...(state.feedback ? {local_reflection:state.feedback} : {})};
    const url = URL.createObjectURL(new Blob([JSON.stringify(report,null,2)],{type:'application/json;charset=utf-8'}));
    const link = document.createElement('a'); link.href = url; link.download = `TRAZA-mi-recorrido-${new Date().toISOString().slice(0,10)}.json`; document.body.appendChild(link); link.click(); link.remove(); window.setTimeout(() => URL.revokeObjectURL(url),1500);
    announce('El archivo se preparó para guardarlo en tu dispositivo.');
  }
  function printReport() {
    const allDetails = [...main.querySelectorAll('details')];
    const openStates = allDetails.map(d => d.open);
    allDetails.forEach(d => { d.open = true; });
    window.print();
    allDetails.forEach((d,i) => { d.open = openStates[i]; });
  }
  document.addEventListener('change', event => {
    if (event.target.id === 'adult-consent' || event.target.id === 'processing-consent') {
      state.adult = document.getElementById('adult-consent').checked;
      state.processing = document.getElementById('processing-consent').checked;
      main.querySelector('[data-action="begin"]').disabled = !(state.adult && state.processing);
    }
    if (event.target.id === 'ai-consent') main.querySelector('[data-action="analyze"]').disabled = !event.target.checked;
    if (event.target.name === 'answer') {
      const q = getQuestion(state.currentId); const value = Number(event.target.value);
      if (q.type === 'multi') {
        let selected = Array.isArray(state.selected) ? [...state.selected] : [];
        if (event.target.checked && value >= 98) selected = [value];
        else if (event.target.checked) selected = [...selected.filter(v => v < 98),value];
        else selected = selected.filter(v => v !== value);
        state.selected = selected;
        main.querySelectorAll('input[name="answer"]').forEach(input => { input.checked = selected.includes(Number(input.value)); });
      } else state.selected = value;
      main.querySelectorAll('.option').forEach(label => label.classList.toggle('chosen',label.querySelector('input').checked));
      document.getElementById('question-next').disabled = state.selected === null || (Array.isArray(state.selected) && !state.selected.length);
    }
  });
  document.addEventListener('submit', event => {
    if (event.target.id !== 'question-form') return;
    event.preventDefault(); if (state.selected !== null && (!Array.isArray(state.selected) || state.selected.length)) commitAnswer(state.selected);
  });
  document.addEventListener('click', event => {
    const button = event.target.closest('[data-action]'); if (!button || button.disabled) return;
    const action = button.dataset.action; event.preventDefault();
    if (action === 'start') { if (state.schema) show('consent'); }
    else if (action === 'home') { if (Object.keys(state.answers).length) restart(); else show('home'); }
    else if (action === 'begin') { if (state.adult && state.processing) startQuestion(state.schema.questions[0].id); }
    else if (action === 'back') backQuestion();
    else if (action === 'skip') commitAnswer(getQuestion(state.currentId).type === 'multi' ? [98] : 98);
    else if (action === 'block-back') {
      const qs = visibleQuestions(); const index = qs.findIndex(q => q.block === state.block);
      if (index > 0) startQuestion(qs[index-1].id); else show('consent');
    }
    else if (action === 'enter-block') { state.introduced.add(state.block); const q = visibleQuestions().find(q => q.block === state.block); if (q) startQuestion(q.id); }
    else if (action === 'skip-block') {
      if (state.block !== 'experiences') return;
      for (const q of state.schema.questions.filter(q => q.block === 'experiences' && !q.show_if)) state.answers[q.id] = 98;
      cleanHiddenAnswers(); invalidateResult(); state.introduced.add(state.block); state.block = 'impact'; show('block');
    }
    else if (action === 'review') show('review');
    else if (action === 'review-back') { const qs = visibleQuestions(); const current = qs.find(q => q.id === state.currentId); if (current) startQuestion(current.id); else if (qs.length) startQuestion(qs[qs.length-1].id); else show('home'); }
    else if (action === 'safety-return') show('safety');
    else if (action === 'review-safety') startQuestion('S1');
    else if (action === 'edit') startQuestion(button.dataset.id,true);
    else if (action === 'ai-consent') { if (canAnalyze() && state.schema.ai_available) { state.error = ''; state.packet = makePacket(); show('aiConsent'); } }
    else if (action === 'analyze') analyze();
    else if (action === 'cancel-ai') { if (state.controller) state.controller.abort(); state.error = 'El envío ya se realizó. Dejaste de esperar el resultado; tus respuestas siguen aquí.'; show('review'); }
    else if (action === 'feedback') {
      state.feedback = button.dataset.value;
      main.querySelectorAll('[data-action="feedback"]').forEach(b => b.setAttribute('aria-pressed',String(b.dataset.value === state.feedback)));
      document.getElementById('feedback-note').textContent = 'Tu opinión quedó marcada en esta pestaña. No se envía ni se usa para entrenar al modelo.';
    }
    else if (action === 'pause') { state.resume = {screen:state.screen,selected:state.selected}; show('paused'); }
    else if (action === 'resume') { if (state.resume) { state.selected = state.resume.selected; show(state.resume.screen); } }
    else if (action === 'exit') safeExit();
    else if (action === 'restart') restart();
    else if (action === 'confirm-restart') { closeModal(); resetJourney(); show('home'); }
    else if (action === 'about') aboutModal();
    else if (action === 'privacy') privacyModal();
    else if (action === 'help') helpModal();
    else if (action === 'close-modal') closeModal();
    else if (action === 'motion') { state.reducedMotion = motionPreference.matches || !state.reducedMotion; document.documentElement.classList.toggle('reduce-motion',state.reducedMotion); button.setAttribute('aria-pressed',String(state.reducedMotion)); button.textContent = state.reducedMotion ? 'Movimiento reducido ✓' : 'Reducir movimiento'; announce(motionPreference.matches ? 'Se respeta la preferencia de movimiento reducido de tu dispositivo.' : state.reducedMotion ? 'Movimiento reducido.' : 'Movimiento suave activado.'); }
    else if (action === 'retry-schema') loadSchema();
    else if (action === 'download') downloadReport();
    else if (action === 'print') printReport();
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      const now = Date.now(); escapeTimes = [...escapeTimes.filter(time => now-time < 1800),now];
      if (escapeTimes.length >= 3) { safeExit(); return; }
      if (modalRoot.children.length) closeModal();
    }
    if (event.key === 'Tab' && modalRoot.children.length) {
      const focusable = [...modalRoot.querySelectorAll('button,a[href],input,[tabindex="0"]')].filter(el => !el.disabled);
      const first = focusable[0], last = focusable[focusable.length-1];
      if (event.shiftKey && document.activeElement === first) { last.focus(); event.preventDefault(); }
      else if (!event.shiftKey && document.activeElement === last) { first.focus(); event.preventDefault(); }
    }
  });
  window.addEventListener('beforeunload', event => { if (!state.exiting && Object.keys(state.answers).length) { event.preventDefault(); event.returnValue = ''; } });
  render(); loadSchema();
})();
