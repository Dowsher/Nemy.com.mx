"""Versioned forms and deterministic scoring; consented persistence is delegated to activity."""
from copy import deepcopy
import json
from pathlib import Path
from datetime import datetime, timezone

from fastapi import HTTPException, Request

VERSION = "3.1.1"
MISSING = (98, 99, None)
ROOT = Path(__file__).resolve().parent


class BatteryInputError(ValueError):
    pass


def visible(item, answers):
    rule = item.get("show_if")
    if not rule:
        return True
    if "any" in rule:
        return any(visible({"show_if": r}, answers) for r in rule["any"])
    if "all" in rule:
        return all(visible({"show_if": r}, answers) for r in rule["all"])
    value = answers.get(rule["id"])
    if "equals" in rule:
        return type(value) is type(rule["equals"]) and value == rule["equals"]
    if "includes" in rule:
        return isinstance(value, list) and rule["includes"] in value
    if "not_in" in rule:
        return value is not None and value not in rule["not_in"]
    return False


def form_items(form):
    return form.get("items", []) + form.get("additional_items", [])


def validate_answers(form, raw):
    if not isinstance(raw, dict) or len(raw) > 250:
        raise BatteryInputError("Respuestas inválidas.")
    index = {q["id"]: q for q in form_items(form)}
    if not set(raw) <= set(index):
        raise BatteryInputError("Hay respuestas que no pertenecen a este instrumento.")
    cleaned = {}
    for key, value in raw.items():
        item = index[key]
        if value is None or (item.get("type") == "number" and value in ("skipped", "unknown")) or (item.get("type") != "number" and type(value) is int and value in (98, 99)):
            cleaned[key] = value
            continue
        if item.get("type") == "number":
            if type(value) is not int or not item.get("min", 0) <= value <= item.get("max", 100):
                raise BatteryInputError("Revisa el valor de " + key + ".")
        elif item.get("type") == "text":
            maximum = min(500, int(item.get("max_length", 500)))
            if not isinstance(value, str) or len(value) > maximum or any(ord(c) < 32 and c not in '\r\n\t' for c in value) or '\x7f' in value:
                raise BatteryInputError(f"Usa una descripción de hasta {maximum} caracteres en {key}.")
            value = value.strip() or None
        else:
            choices = item.get("options", [])
            def allowed(v):
                return not isinstance(v, (bool, dict, list)) and any(type(v) is type(o["value"]) and v == o["value"] for o in choices)
            if item.get("multiple"):
                if not isinstance(value, list) or not value or len(value) > item.get("max_choices", len(choices)) or len({(type(v).__name__, str(v)) for v in value}) != len(value) or not all(allowed(v) for v in value):
                    raise BatteryInputError("Selección inválida en " + key + ".")
                if len(value) > 1 and any(v in item.get("exclusive_values", []) for v in value):
                    raise BatteryInputError("Esta opción debe seleccionarse por separado.")
            elif not allowed(value):
                raise BatteryInputError("Opción inválida en " + key + ".")
        cleaned[key] = value
    # Ignore stale conditional answers; never score invisible follow-ups.
    for item in form_items(form):
        if not visible(item, cleaned):
            cleaned.pop(item["id"], None)
    for key, value in cleaned.items():
        rules = index[key].get("filter_options_by_answers", {})
        if _known(value, index[key]) and rules and not visible({"show_if": rules.get(str(value), {"id": "__invalid", "equals": True})}, cleaned):
            raise BatteryInputError("La opción principal debe corresponder a una respuesta que marcaste.")
    return cleaned


def _known(v, item=None):
    if (item or {}).get("type") == "text":
        return isinstance(v, str) and bool(v.strip())
    if v is None or (isinstance(v, str) and v in ("skipped", "unknown")):
        return False
    return (item or {}).get("type") == "number" or not (type(v) is int and v in (98, 99))


def _label(item, value):
    if value is None:
        return "Sin responder"
    if item.get("type") == "text" and isinstance(value, str):
        return value
    if value == "skipped" or (item.get("type") != "number" and value == 98):
        return "Prefiero no responder"
    if value == "unknown" or (item.get("type") != "number" and value == 99):
        return "No sé"
    if isinstance(value, list):
        return " · ".join(_label(item, v) for v in value)
    return next((o["label"] for o in item.get("options", []) if type(o["value"]) is type(value) and o["value"] == value), str(value))


def score(form, raw):
    answers = validate_answers(form, raw)
    items = [q for q in form_items(form) if visible(q, answers)]
    settings = form.get("scoring", {})
    method = settings.get("method", "descriptive")
    required = settings.get("required_ids", [q["id"] for q in items if q.get("required_for_score", True) and not q.get("optional")])
    active = {q["id"] for q in items}
    required = [key for key in required if key in active]
    item_index = {q["id"]: q for q in items}
    missing = [key for key in required if not _known(answers.get(key), item_index[key])]
    result = {
        "id": form["id"], "name": form["name"], "version": form.get("version", "1.0"),
        "complete": not missing, "answered": len(required) - len(missing), "required": len(required),
        "total": None, "range": settings.get("range"), "band": None,
        "summary": "Faltan respuestas para calcular esta puntuación." if missing else "Cuestionario completado.",
        "subscales": [], "findings": [], "missing_ids": missing,
        "source_url": form.get("source", {}).get("url", ""),
        "attribution": form.get("attribution", ""), "content_license": form.get("content_license", ""),
        "presentation_note": form.get("presentation_note", ""),
        "registration": deepcopy(form.get("registration", {})),
        "language": form.get("language", ""), "edition_number": form.get("edition_number"),
        "translation_warning": form.get("translation_warning", ""), "intended_use": form.get("intended_use", ""),
        "safety": {"review": False, "urgent": False},
        "answers": [{"id": q["id"], "question": q.get("display_text", q["text"]), "value": answers.get(q["id"]), "label": _label(q, answers.get(q["id"]))} for q in items],
        "scoring_version": VERSION, "generated_at": datetime.now(timezone.utc).isoformat(),
    }
    if form["id"] == "PHQ9" and type(answers.get("PHQ9_9")) is int and 1 <= answers["PHQ9_9"] <= 3:
        result["safety"] = {"review": True, "urgent": False, "message": "Señalaste pensamientos de muerte o de hacerte daño. Comprueba si hay peligro ahora; esta respuesta por sí sola no predice el riesgo."}
    if form["id"] == "STATE":
        if answers.get("VE3") == "yes" or answers.get("VE1") == "hoy":
            result["findings"].append("El efecto o consumo de hoy puede influir en tus respuestas. Puedes repetir los cuestionarios en otro momento.")
    if form["id"] == "PCPTSD5":
        exposure = answers.get("PCPTSD5_EXPOSURE")
        if exposure == 0 and type(exposure) is int:
            result.update(complete=True, answered=1, required=1, total=0, range=[0, 5], missing_ids=[], summary="No marcaste exposición en la pregunta inicial. El cuestionario termina aquí con puntuación 0.")
        elif exposure == 1 and type(exposure) is int:
            keys = settings["required_ids_if_exposure_yes"]
            missing = [k for k in keys if not _known(answers.get(k))]
            result.update(complete=not missing, answered=1+len(keys)-len(missing), required=1+len(keys), missing_ids=missing)
            if not missing:
                total = sum(answers[k] for k in keys)
                result.update(total=total, summary=f"Marcaste {total} de 5 reacciones durante el último mes. La puntuación sirve para una evaluación posterior; no establece TEPT.")
                result["findings"].append("No se aplica un punto de corte universal: depende de la población y el propósito de la evaluación.")
        else:
            result.update(complete=False, answered=0, required=1, missing_ids=["PCPTSD5_EXPOSURE"], summary="Falta la respuesta de exposición para aplicar este cuestionario.")
        return result
    if method == "lec5":
        # Inventory categories and the extended descriptive follow-ups are separate.
        inventory_ids = settings.get("inventory_ids", [q["id"] for q in form.get("items", [])[:17]])
        inventory = [q for q in items if q["id"] in inventory_ids]
        inventory_missing = [q["id"] for q in inventory if not _known(answers.get(q["id"]), q)]
        counts = {o["value"]: 0 for o in inventory[0]["options"]}
        for item in inventory:
            value = answers.get(item["id"])
            if isinstance(value, list):
                for option in value:
                    counts[option] += 1
        result["inventory"] = {"complete": not inventory_missing, "answered": len(inventory)-len(inventory_missing), "required": len(inventory), "counts": counts}
        result["findings"] = [f"{o['label']}: {counts[o['value']]} categorías" for o in inventory[0]["options"]]
        if inventory_missing:
            result["summary"] = "El inventario tiene categorías sin responder. Se muestran únicamente las exposiciones registradas, sin puntuación total ni medida de gravedad."
        elif missing:
            result["summary"] = "Inventario de 17 categorías completado. Hay preguntas complementarias sin respuesta; puedes revisarlas. LEC-5 no calcula una puntuación total ni una medida de gravedad."
        elif not any(key not in inventory_ids for key in required):
            result["summary"] = "Inventario de 17 categorías completado. No se activaron preguntas complementarias con tus selecciones. LEC-5 no calcula una puntuación total ni una medida de gravedad."
        else:
            result["summary"] = "Registro de exposición y preguntas complementarias completado. Las respuestas describen el acontecimiento de referencia; no calculan una puntuación total ni una medida de gravedad."
        return result
    if missing:
        return result
    if method == "sum":
        total = sum(answers[key] for key in required)
        result["total"] = total
        bands = settings.get("bands", [])
        if bands:
            selected = max((b for b in bands if total >= b["min"]), key=lambda b: b["min"])
            result["band"] = selected["label"]
            result["summary"] = f"Tu puntuación es {total} de {settings['range'][1]}. Nivel de síntomas: {selected['label'].lower()}."
        else:
            result["summary"] = f"Tu puntuación es {total} de {settings.get('range', [0, total])[1]}."
        if total >= settings.get("review_threshold", float("inf")):
            result["findings"].append("Esta puntuación justifica una evaluación profesional para entender los síntomas y su contexto.")
    elif method == "cluster_algorithm":
        ptsd = all(any(answers[k] >= 2 for k in pair) for pair in settings["ptsd_pairs"]) and any(answers[k] >= 2 for k in settings["ptsd_impairment_any"])
        dso = all(any(answers[k] >= 2 for k in pair) for pair in settings["dso_pairs"]) and any(answers[k] >= 2 for k in settings["dso_impairment_any"])
        for name, ids in (("Síntomas de estrés postraumático", settings["ptsd_severity_ids"]), ("Dificultades emocionales, personales y relacionales", settings["dso_severity_ids"])):
            result["subscales"].append({"name": name, "value": sum(answers[k] for k in ids), "max": 24})
        result["algorithm"] = {"ptsd_screen": ptsd, "dso_screen": dso, "category": "CPTSD_screen" if ptsd and dso else "PTSD_screen" if ptsd else "criteria_not_met"}
        result["band"] = "Patrón de TEPT complejo para evaluar" if ptsd and dso else "Patrón de TEPT para evaluar" if ptsd else "No se reúne el patrón completo"
        result["summary"] = result["band"] + ". Se consideran los grupos de síntomas y su impacto, sin punto de corte por suma total."
    elif method == "asrs6":
        # ASRS-v1.1 Part A shaded thresholds: 2,2,2,3,3,3.
        thresholds = settings.get("thresholds", [2, 2, 2, 3, 3, 3])
        count = sum(answers[k] >= threshold for k, threshold in zip(required, thresholds))
        result.update(total=count, range=[0, 6], band="Requiere evaluación más detallada" if count >= 4 else "Por debajo del umbral de cribado", summary=f"{count} de 6 respuestas están en el rango señalado por ASRS. " + ("Conviene evaluar con más detalle los síntomas de atención e hiperactividad." if count >= 4 else "El resultado está por debajo del umbral de cribado de 4 respuestas; no descarta dificultades de atención."))
    elif method in ("mean", "reverse_mean", "subscales", "socrates", "mspss", "ders16", "desii", "brs"):
        self_subscales = settings.get("subscales", [])
        reverse = settings.get("reverse_ids", [])
        lo, hi = settings.get("item_range", [1, 7])
        def points(key):
            return lo + hi - answers[key] if key in reverse else answers[key]
        if self_subscales:
            for group in self_subscales:
                values = [points(key) for key in group["ids"]]
                value = sum(values) / len(values) if group.get("method", settings.get("subscale_method", "mean")) == "mean" else sum(values)
                result["subscales"].append({"name": group["name"], "value": round(value, 2), "max": hi if group.get("method", settings.get("subscale_method", "mean")) == "mean" else hi*len(values)})
        if settings.get("total_method", "mean") != "none":
            total = sum(points(k) for k in required)
            if settings.get("total_method", "mean") == "mean":
                total /= len(required)
            result["total"] = round(total, 2)
        result["summary"] = settings.get("result_text", "Puntuaciones calculadas a partir de tus respuestas. Consulta cada dimensión por separado.")
    else:
        # Original modules are a factual record, never a calibrated trauma score.
        result["summary"] = "Tus respuestas están organizadas por tema. Este módulo no tiene una puntuación clínica."
        if form["id"] == "MFC12":
            selected = [q for q in items if q["id"].startswith("MFC") and q["id"][3:].isdigit() and type(answers[q["id"]]) is int and answers[q["id"]] >= 2]
            result["findings"] = ["Marcaste «" + _label(q, answers[q["id"]]) + "»: " + q["text"] for q in selected]
        elif form["id"] == "CX17":
            result["findings"] = [q["text"] for q in items if "_" not in q["id"] and answers.get(q["id"]) == "yes"]
        elif form["id"] == "MDT24":
            result["findings"] = [q["text"] + ": " + _label(q, answers[q["id"]]) for q in items if q["id"] != "MD-T" and type(answers[q["id"]]) is int and answers[q["id"]] > 0]
        elif form["id"] == "LTC":
            ages = [(q["text"], answers[q["id"]]) for q in items if q.get("type") == "number"]
            result["findings"] = [f"{name}: {age} años aproximadamente" for name, age in ages]
    return result


def load_bank():
    return json.loads((ROOT / "battery_bank.json").read_text(encoding="utf-8"))


def attach_battery(application):
    bank = load_bank()
    forms = {f["id"]: f for f in bank["instruments"]}
    application.state.battery_forms = forms

    @application.get("/api/battery/catalog")
    async def catalog():
        instruments = []
        for form in forms.values():
            item = {key: form.get(key) for key in ("id", "name", "title", "topic", "description", "minutes", "status", "reason", "kind")}
            item["item_count"] = len(form_items(form))
            base_count = sum(not q.get("show_if") for q in form_items(form))
            item["question_count_label"] = (f"{base_count} pregunta" + ("s" if base_count != 1 else "") + " + seguimientos") if base_count < item["item_count"] else f"{item['item_count']} preguntas"
            item["source_url"] = form.get("source", {}).get("page_url", form.get("source", {}).get("url", ""))
            instruments.append(item)
        return {"version": VERSION, "instruments": instruments, "privacy": {"local_only": False, "stores_answers": True, "uses_ai": False, "retention_days": 90, "description": "Con tu autorización, las respuestas se guardan cifradas durante 90 días para administración y puntuación. El administrador autorizado puede revisarlas en su panel privado. En los cuestionarios individuales no se envían a OpenAI."}}

    @application.get("/api/battery/{instrument_id}")
    async def instrument(instrument_id: str):
        form = forms.get(instrument_id)
        if not form:
            raise HTTPException(404, "Instrumento no encontrado.")
        if form["status"] != "available":
            raise HTTPException(409, form.get("reason", "Requiere una autorización de uso electrónico."))
        return deepcopy(form)

    @application.post("/api/battery/{instrument_id}/score")
    async def score_route(instrument_id: str, request: Request):
        form = forms.get(instrument_id)
        if not form:
            raise HTTPException(404, "Instrumento no encontrado.")
        if form["status"] != "available":
            raise HTTPException(409, form.get("reason", "Instrumento sin contenido autorizado."))
        try:
            payload = await request.json()
        except Exception:
            raise HTTPException(422, "JSON inválido.")
        if not isinstance(payload, dict) or "answers" not in payload or not set(payload) <= {"answers", "form_version"}:
            raise HTTPException(422, "Envía únicamente las respuestas de este instrumento.")
        if (form.get("registration") or "form_version" in payload) and payload.get("form_version") != form.get("version", "1.0"):
            raise HTTPException(409, "La versión del cuestionario cambió. Descarga tus respuestas y vuelve a abrirlo antes de calcular el resultado.")
        activity = getattr(application.state, "activity", None)
        if activity is not None:
            activity.authorize_score(request.headers.get("X-Traza-Activity-Session"),
                                     request.headers.get("X-Traza-Visit"), instrument_id, payload["answers"])
        try:
            return score(form, payload["answers"])
        except BatteryInputError as error:
            raise HTTPException(422, str(error))
