"""Synthetic-only tests: no credential files, external traffic or patient data."""
import asyncio
import copy
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
import uuid

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from db import Database
import exploration as e


def sample_payload():
    return {"request_id": str(uuid.uuid4()),
            "consent": {"adult": True, "processing": True, "ai": True, "version": "2.0"},
            "answers": {"S1": 1, "S2": 2, "S3": 0, "P1": 2, "P2": 1, "P3": 0,
                        "I1": 1, "A1": 1},
            "safety_state": {"peak_distress": 2, "current_risk": False, "unsafe": False}}


def sample_analysis():
    return e.ground_observations({
        "patterns": [{"evidence_ids": ["P1", "P2"],
                      "uncertainty": "Estas respuestas no explican por qué ocurre ni muestran todo tu contexto."}],
        "reflection_questions": ["¿En qué momentos del día te sientes con más tranquilidad?"]}, sample_payload()["answers"])


def model_analysis(full):
    return {"patterns": [{"evidence_ids": p["evidence_ids"], "uncertainty": p["uncertainty"]} for p in full["patterns"]],
            "reflection_questions": full["reflection_questions"]}


def envelope(analysis=None):
    raw = model_analysis(copy.deepcopy(analysis or sample_analysis()))
    return {"id": "resp_synthetic", "status": "completed", "output": [{"type": "message",
            "content": [{"type": "output_text", "text": json.dumps(raw, ensure_ascii=False)}]}]}


class PayloadTests(unittest.TestCase):
    def assert_code(self, code, fn, *args):
        with self.assertRaises(e.ExplorationError) as ctx:
            fn(*args)
        self.assertEqual(ctx.exception.code, code)

    def test_original_bank_has_bounded_whitelisted_options(self):
        self.assertEqual(len(e.BANK["questions"]), 32)
        self.assertEqual(len(e.QUESTIONS), 32)
        self.assertTrue(all(len({o["value"] for o in q["options"]}) == len(q["options"]) for q in e.BANK["questions"]))
        self.assertTrue(all({98, 99} <= {o["value"] for o in q["options"]} for q in e.BANK["questions"]))

    def test_no_names_narratives_unknowns_or_boolean_numeric_inputs(self):
        for key, value in (("name", 1), ("P1", "a private story"), ("P1", True), ("P1", 4), ("P1", [1])):
            payload = sample_payload()
            payload["answers"][key] = value
            self.assert_code("invalid_answers", e.validate_payload, payload)

    def test_adult_processing_ai_and_version_each_required(self):
        for field in ("adult", "processing", "ai", "version"):
            payload = sample_payload()
            payload["consent"][field] = False
            self.assert_code("consent_required", e.validate_payload, payload)

    def test_uuid_required_and_unexpected_root_fields_rejected(self):
        payload = sample_payload()
        payload["request_id"] = "not-a-uuid"
        self.assert_code("invalid_request_id", e.validate_payload, payload)
        payload = sample_payload()
        payload["email"] = "someone@example.invalid"
        self.assert_code("invalid_payload", e.validate_payload, payload)

    def test_current_and_prior_safety_signals_block_deterministically(self):
        for key, value in (("S1", 0), ("S2", 8), ("S2", 10), ("S3", 1)):
            payload = sample_payload()
            payload["answers"][key] = value
            self.assert_code("safety_blocked", e.validate_payload, payload)
        for state in ({"peak_distress": 8}, {"current_risk": True}, {"unsafe": True}):
            payload = sample_payload()
            payload["safety_state"] = state
            self.assert_code("safety_blocked", e.validate_payload, payload)

    def test_unanswered_safety_does_not_become_safe(self):
        for key in ("S1", "S2", "S3"):
            for value in (98, 99, None):
                payload = sample_payload()
                if value is None:
                    payload["answers"].pop(key)
                else:
                    payload["answers"][key] = value
                self.assert_code("safety_incomplete", e.validate_payload, payload)

    def test_missing_current_reactions_are_not_counted_as_zero(self):
        payload = sample_payload()
        payload["answers"].update({"P1": 98, "P2": 99, "P3": 98})
        self.assert_code("insufficient_information", e.validate_payload, payload)
        facts = e.answer_facts(payload["answers"], provider=True)
        self.assertTrue(all(f["missing"] for f in facts if f["id"].startswith("P")))
        self.assertFalse(any(f["evidence_eligible"] for f in facts if f["id"].startswith("P")))

    def test_event_followups_need_an_explicit_event(self):
        payload = sample_payload()
        payload["answers"]["EC"] = 1
        self.assert_code("invalid_branch", e.validate_payload, payload)
        payload["answers"]["E7"] = 1
        self.assertEqual(e.validate_payload(payload)["answers"]["EC"], 1)

    def test_unsupported_zero_unknown_safety_or_hallucinated_evidence_rejected(self):
        for key in ("P3", "E1", "NONEXISTENT", "S1", "P8"):
            analysis = sample_analysis()
            analysis["patterns"][0]["evidence_ids"] = [key]
            self.assert_code("ai_invalid_response", e.validate_analysis, analysis, sample_payload()["answers"])
        payload = sample_payload()
        payload["answers"]["P8"] = 98
        analysis["patterns"][0]["evidence_ids"] = ["P8"]
        self.assert_code("ai_invalid_response", e.validate_analysis, analysis, payload["answers"])

    def test_experience_alone_cannot_become_a_pattern(self):
        answers = sample_payload()["answers"]
        answers["E7"] = 1
        analysis = sample_analysis()
        analysis["patterns"][0]["evidence_ids"] = ["E7"]
        self.assert_code("ai_invalid_response", e.validate_analysis, analysis, answers)

    def test_no_symptoms_no_patterns_even_when_events_or_supports_reported(self):
        answers = sample_payload()["answers"]
        answers.update({"P1": 0, "P2": 0, "I1": 0, "E7": 1})
        self.assert_code("ai_invalid_response", e.validate_analysis, sample_analysis(), answers)
        request = e.provider_request(answers, e.DEFAULT_MODEL)
        self.assertEqual(request["text"]["format"]["schema"]["properties"]["patterns"]["maxItems"], 0)

    def test_diagnoses_causes_hidden_memories_and_unreported_events_rejected(self):
        claims = ["Tienes TEPT por lo sucedido.", "Esto es un trauma complejo.",
                  "Lo actual se debe a una pérdida.", "Tu malestar fue causado por lo vivido.",
                  "Hay recuerdos reprimidos que puedes recuperar.",
                  "Lo que sientes sugiere una experiencia sexual.", "Las dificultades comenzaron en tu infancia.",
                  "Tu pareja pudo haberte lastimado."]
        for claim in claims:
            analysis = sample_analysis()
            analysis["summary"] = claim
            self.assert_code("ai_invalid_response", e.validate_analysis, analysis, sample_payload()["answers"])

    def test_strict_structure_lengths_html_and_limitations(self):
        for mutate in (lambda a: a.update(extra="x"), lambda a: a.update(title="x"),
                       lambda a: a.update(summary="<script>private</script>"),
                       lambda a: a.update(limitations="Este es un mapa perfecto que siempre tiene razón.")):
            analysis = sample_analysis()
            mutate(analysis)
            self.assert_code("ai_invalid_response", e.validate_analysis, analysis, sample_payload()["answers"])

    def test_server_grounds_observation_frequency_and_rejects_rewritten_claims(self):
        analysis = sample_analysis()
        analysis["patterns"][0]["observation"] = "Marcaste que duermes mal casi todas las noches."
        self.assert_code("ai_invalid_response", e.validate_analysis, analysis, sample_payload()["answers"])
        raw = model_analysis(copy.deepcopy(analysis))
        grounded = e.ground_observations(raw, sample_payload()["answers"])
        self.assertIn("→ A menudo", grounded["patterns"][0]["observation"])
        self.assertNotIn("noches", grounded["patterns"][0]["observation"])

    def test_unreported_sleep_and_exaggerated_frequency_are_rejected(self):
        answers = sample_payload()["answers"]
        answers["P1"] = 0
        analysis = sample_analysis()
        analysis["patterns"][0].update(title="Tu alerta", evidence_ids=["P2"])
        analysis["patterns"][0]["observation"] = e.QUESTIONS["P2"]["text"] + " → A veces"
        self.assert_code("ai_invalid_response", e.validate_analysis, analysis, answers)
        analysis = sample_analysis()
        analysis["summary"] = "Te sientes alerta casi todas las noches."
        self.assert_code("ai_invalid_response", e.validate_analysis, analysis, sample_payload()["answers"])

    def test_supports_are_exact_selected_options_and_absent_support_not_inferred(self):
        answers = sample_payload()["answers"]
        answers["A1"] = 0
        analysis = sample_analysis()
        self.assert_code("ai_invalid_response", e.validate_analysis, analysis, answers)
        analysis["supports"] = []
        analysis["reflection_questions"] = ["Cuentas con una persona que te escucha y te acompaña."]
        self.assert_code("ai_invalid_response", e.validate_analysis, analysis, answers)

    def test_negated_causal_caveat_is_allowed_and_before18_does_not_mean_childhood(self):
        analysis = sample_analysis()
        analysis["patterns"][0]["uncertainty"] = "No podemos establecer una causa con estas respuestas seleccionadas."
        self.assertEqual(e.validate_analysis(analysis, sample_payload()["answers"]), analysis)
        answers = sample_payload()["answers"]
        answers.update(E7=1, EC=1)
        analysis["summary"] = "Marcaste dificultades que comenzaron en tu infancia."
        self.assert_code("ai_invalid_response", e.validate_analysis, analysis, answers)

    def test_combined_category_cannot_be_rewritten_as_one_event_subtype(self):
        answers = sample_payload()["answers"]
        for event, claim in (("E7", "Describiste el duelo por una pérdida."),
                             ("E8", "Describiste que viviste un delito."),
                             ("E10", "Describiste que viviste acoso.")):
            analysis = sample_analysis()
            answers[event] = 1
            analysis["summary"] = claim
            self.assert_code("ai_invalid_response", e.validate_analysis, analysis, answers)

    def test_provider_packet_is_strict_stateless_and_excludes_all_safety_values(self):
        request = e.provider_request(sample_payload()["answers"], e.DEFAULT_MODEL)
        self.assertFalse(request["store"])
        self.assertEqual(request["max_output_tokens"], 2000)
        self.assertTrue(request["text"]["format"]["strict"])
        self.assertNotIn("tools", request)
        self.assertNotIn("previous_response_id", request)
        facts = json.loads(request["input"][1]["content"][0]["text"])["facts"]
        self.assertFalse(any(f["id"].startswith("S") for f in facts))
        self.assertFalse(any(f["id"] == "P3" and f["evidence_eligible"] for f in facts))
        self.assertNotIn("safety_state", json.dumps(request))

    def test_schema_readiness_and_privacy_are_honest(self):
        with patch.dict(os.environ, {"OPENAI_API_KEY": "", "TRAZA_AI_ENABLED": "1"}):
            schema = e.get_schema()
            self.assertFalse(schema["ai_available"])
        self.assertFalse(schema["privacy"]["server_persists_answers"])
        self.assertEqual(schema["privacy"]["transient_memory_minutes"], 15)
        self.assertEqual(schema["privacy"]["provider_security_retention_days_up_to"], 30)
        self.assertFalse(schema["privacy"]["safety_sent_to_provider"])


class ProviderAndServiceTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.env = patch.dict(os.environ, {"OPENAI_API_KEY": "synthetic-not-a-real-key", "TRAZA_AI_MODEL": e.DEFAULT_MODEL,
            "TRAZA_AI_ENABLED": "1", "TRAZA_AI_IP_HOURLY_LIMIT": "5", "TRAZA_AI_DAILY_LIMIT": "40"})
        self.env.start()
        self.addCleanup(self.env.stop)
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = Database(self.tmp.name)
        self.service = e.ExplorationService(self.db)
        self.requests = []

    def client(self, status=200, body=None):
        async def handler(request):
            self.requests.append(request)
            return httpx.Response(status, json=body if body is not None else envelope())
        return httpx.AsyncClient(transport=httpx.MockTransport(handler))

    async def test_real_http_request_shape_and_generative_metadata_with_mock_transport(self):
        async with self.client() as client:
            result = await self.service.analyze(sample_payload(), "192.0.2.4", client=client)
        self.assertEqual(len(self.requests), 1)
        self.assertEqual(str(self.requests[0].url), e.PROVIDER_URL)
        sent = json.loads(self.requests[0].content)
        self.assertEqual(sent["model"], e.DEFAULT_MODEL)
        self.assertEqual(result["meta"]["source"], "generative_ai")
        self.assertEqual(result["meta"]["prompt_version"], e.PROMPT_VERSION)
        self.assertEqual(result["analysis"], sample_analysis())

    async def test_unsafe_missing_and_unconsented_inputs_never_call_provider(self):
        cases = []
        p = sample_payload(); p["answers"]["S2"] = 9; cases.append(p)
        p = sample_payload(); p["consent"]["ai"] = False; cases.append(p)
        p = sample_payload(); p["answers"].update({"P1": 98, "P2": 99}); cases.append(p)
        async with self.client() as client:
            for payload in cases:
                with self.assertRaises(e.ExplorationError):
                    await self.service.analyze(payload, "192.0.2.4", client=client)
        self.assertEqual(self.requests, [])
        with self.db.connection() as con:
            self.assertEqual(con.execute("SELECT count(*) FROM exploration_usage").fetchone()[0], 0)

    async def test_provider_errors_incomplete_and_refusals_never_fake_success(self):
        responses = [(401, {"error": {"message": "SECRET-PROVIDER-MESSAGE"}}),
                     (429, {"error": {"message": "SECRET-PROVIDER-MESSAGE"}}),
                     (200, {"status": "incomplete", "output": []}),
                     (200, {"status": "completed", "output": [{"type": "message", "content": [{"type": "refusal", "refusal": "PRIVATE"}]}]})]
        for status, body in responses:
            async with self.client(status, body) as client:
                with self.assertRaises(e.ExplorationError) as ctx:
                    await e.analyze_payload(sample_payload(), client=client)
            self.assertNotIn("SECRET", ctx.exception.detail)
            self.assertNotIn("PRIVATE", ctx.exception.detail)

    async def test_provider_timeout_is_a_safe_unavailable_error(self):
        async def handler(request):
            raise httpx.ReadTimeout("SECRET-TIMEOUT", request=request)
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            with self.assertRaises(e.ExplorationError) as ctx:
                await e.analyze_payload(sample_payload(), client=client)
        self.assertEqual(ctx.exception.code, "ai_provider_error")
        self.assertNotIn("SECRET", ctx.exception.detail)

    async def test_unavailable_or_disabled_does_not_call_or_consume_budget(self):
        for settings in ({"OPENAI_API_KEY": ""}, {"TRAZA_AI_ENABLED": "0"}):
            with patch.dict(os.environ, settings):
                async with self.client() as client:
                    with self.assertRaises(e.ExplorationError) as ctx:
                        await self.service.analyze(sample_payload(), "192.0.2.4", client=client)
                self.assertEqual(ctx.exception.code, "ai_unavailable")
        self.assertEqual(self.requests, [])

    async def test_idempotency_avoids_cost_and_changed_payload_conflicts(self):
        payload = sample_payload()
        async with self.client() as client:
            result = await self.service.analyze(payload, "192.0.2.4", client=client)
            repeat = await self.service.analyze(copy.deepcopy(payload), "192.0.2.4", client=client)
            self.assertEqual(result, repeat)
            payload["answers"]["P1"] = 3
            with self.assertRaises(e.ExplorationError) as ctx:
                await self.service.analyze(payload, "192.0.2.4", client=client)
            self.assertEqual(ctx.exception.code, "request_conflict")
        self.assertEqual(len(self.requests), 1)

    async def test_cache_expires_without_another_request(self):
        with patch.object(e, "CACHE_TTL_SECONDS", 0.02):
            async with self.client() as client:
                await self.service.analyze(sample_payload(), "192.0.2.4", client=client)
            self.assertEqual(len(self.service.cache), 1)
            await asyncio.sleep(0.05)
            self.assertEqual(len(self.service.cache), 0)

    async def test_hourly_budget_persists_after_service_restart_without_health_data(self):
        with patch.dict(os.environ, {"TRAZA_AI_IP_HOURLY_LIMIT": "1"}):
            async with self.client() as client:
                await self.service.analyze(sample_payload(), "192.0.2.4", client=client)
                other = e.ExplorationService(self.db)
                with self.assertRaises(e.ExplorationError) as ctx:
                    await other.analyze(sample_payload(), "192.0.2.4", client=client)
                self.assertEqual(ctx.exception.code, "rate_limited")
        with self.db.connection() as con:
            rows = [dict(r) for r in con.execute("SELECT * FROM exploration_usage")]
            self.assertEqual(con.execute("SELECT count(*) FROM records").fetchone()[0], 0)
            self.assertEqual(con.execute("SELECT count(*) FROM record_versions").fetchone()[0], 0)
        dumped = json.dumps(rows)
        self.assertNotIn("192.0.2.4", dumped)
        self.assertNotIn("answers", dumped)
        self.assertNotIn("P1", dumped)

    async def test_global_budget_is_shared_across_different_ips(self):
        with patch.dict(os.environ, {"TRAZA_AI_DAILY_LIMIT": "1"}):
            async with self.client() as client:
                await self.service.analyze(sample_payload(), "192.0.2.4", client=client)
                with self.assertRaises(e.ExplorationError) as ctx:
                    await self.service.analyze(sample_payload(), "192.0.2.5", client=client)
                self.assertEqual(ctx.exception.code, "rate_limited")

    async def test_only_two_provider_calls_may_be_in_flight(self):
        gate = asyncio.Event()
        entered = 0
        async def handler(request):
            nonlocal entered
            entered += 1
            await gate.wait()
            return httpx.Response(200, json=envelope())
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            first = asyncio.create_task(self.service.analyze(sample_payload(), "192.0.2.4", client=client))
            second = asyncio.create_task(self.service.analyze(sample_payload(), "192.0.2.5", client=client))
            for _ in range(30):
                if entered == 2:
                    break
                await asyncio.sleep(0.005)
            self.assertEqual(entered, 2)
            with self.assertRaises(e.ExplorationError) as ctx:
                await self.service.analyze(sample_payload(), "192.0.2.6", client=client)
            self.assertEqual(ctx.exception.code, "ai_busy")
            gate.set()
            await asyncio.gather(first, second)
        self.assertEqual(self.service.active, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
