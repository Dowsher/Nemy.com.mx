"""Actual SQLite/TestClient checks; synthetic data only, no provider or secrets."""
from copy import deepcopy
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import AsyncMock, patch
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from db import Database
from activity import attach_activity
import battery
import journey


def uid():
    return str(uuid.uuid4())


class ActivityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.db = Database(self.tmp.name)
        self.app = FastAPI()
        journey.attach_journey(self.app, self.db)
        battery.attach_battery(self.app)
        def admin(request):
            if not request.headers.get("X-Admin-Role"):
                raise HTTPException(401, "Login")
            if request.headers.get("X-Admin-MFA") != "1" or request.headers.get("X-Admin-Password") != "1":
                raise HTTPException(403, "Setup")
            return {"role": request.headers["X-Admin-Role"], "id": "synthetic-owner"}
        self.svc = attach_activity(self.app, self.db, admin)
        self.client = TestClient(self.app)
        self.addCleanup(self.client.close)
        self.admin_headers = {"X-Admin-Role": "admin", "X-Admin-MFA": "1", "X-Admin-Password": "1"}
        self.visit_payload = {"event_id": uid(), "device": {"kind": "desktop", "os": "Windows", "browser": "Chrome"}, "viewport": {"width": 1447, "height": 923}, "entry": "home"}
        visit = self.client.post("/api/activity/visits", json=self.visit_payload)
        self.assertEqual(visit.status_code, 200, visit.text)
        self.visit = visit.json()
        self.headers = {"X-Traza-Visit": self.visit["visit_token"]}
        self.seq = {}

    def start(self, route="basico", form=None, consent=True):
        payload = {"event_id": uid(), "kind": "battery" if form else "journey", "route_id": None if form else route,
                   "form_id": form, "consent": {"adult": True, "storage": consent, "version": "5.0"}}
        response = self.client.post("/api/activity/sessions", json=payload, headers=self.headers)
        if consent:
            self.assertEqual(response.status_code, 200, response.text)
            self.seq[response.json()["session_id"]] = 0
            return response.json()["session_id"]
        return response

    def event(self, sid, typ="answer", fid="context", qid="E2", value=1, sequence=None, event_id=None):
        sequence = self.seq[sid] + 1 if sequence is None else sequence
        payload = {"event_id": event_id or uid(), "sequence": sequence, "type": typ, "form_id": fid, "question_id": qid, "value": value}
        response = self.client.post(f"/api/activity/sessions/{sid}/events", json=payload, headers=self.headers)
        if response.status_code == 200:
            self.seq[sid] = max(self.seq[sid], sequence)
        return response

    def detail(self, sid):
        response = self.client.get(f"/api/admin/activity/{sid}", headers=self.admin_headers)
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()

    def dashboard(self, **params):
        response = self.client.get("/api/admin/activity", params=params, headers=self.admin_headers)
        self.assertEqual(response.status_code, 200, response.text)
        return response.json()

    def test_visit_idempotency_token_only_hash_and_coarse_device(self):
        again = self.client.post("/api/activity/visits", json=self.visit_payload)
        self.assertEqual(again.json(), self.visit)
        changed = deepcopy(self.visit_payload); changed["device"]["kind"] = "mobile"
        self.assertEqual(self.client.post("/api/activity/visits", json=changed).status_code, 409)
        with self.db.connection() as con:
            row = con.execute("SELECT * FROM activity_visits").fetchone()
        self.assertNotIn(self.visit["visit_token"], json.dumps(dict(row)))
        self.assertEqual(row["viewport_width"], 1400)
        self.assertEqual(row["viewport_height"], 900)
        self.assertNotIn("ip", row.keys()); self.assertNotIn("user_agent", row.keys())

    def test_visit_rejects_raw_user_agent_and_invalid_types(self):
        bad = deepcopy(self.visit_payload); bad["event_id"] = uid(); bad["user_agent"] = "private-agent"
        self.assertEqual(self.client.post("/api/activity/visits", json=bad).status_code, 422)
        for section, key, value in [("device", "kind", []), ("device", "os", {}), ("viewport", "width", True), ("viewport", "height", 0)]:
            bad = deepcopy(self.visit_payload); bad[section][key] = value
            self.assertEqual(self.client.post("/api/activity/visits", json=bad).status_code, 422)

    def test_consent_required_before_any_answer(self):
        response = self.start(consent=False)
        self.assertEqual(response.status_code, 403)
        with self.db.connection() as con:
            self.assertEqual(con.execute("SELECT count(*) FROM activity_sessions").fetchone()[0], 0)
            self.assertEqual(con.execute("SELECT count(*) FROM activity_events").fetchone()[0], 0)

    def test_sessions_validate_route_and_active_form(self):
        for route, form in [("imaginary", None), ([], None), ("basico", "SDS")]:
            p = {"event_id": uid(), "kind": "battery" if form else "journey", "route_id": None if form else route, "form_id": form,
                 "consent": {"adult": True, "storage": True, "version": "5.0"}}
            self.assertEqual(self.client.post("/api/activity/sessions", json=p, headers=self.headers).status_code, 422)

    def test_another_visit_cannot_read_or_mutate_session(self):
        sid = self.start()
        second = deepcopy(self.visit_payload); second["event_id"] = uid()
        token = self.client.post("/api/activity/visits", json=second).json()["visit_token"]
        payload = {"event_id": uid(), "sequence": 1, "type": "answer", "form_id": "context", "question_id": "E2", "value": 1}
        response = self.client.post(f"/api/activity/sessions/{sid}/events", json=payload, headers={"X-Traza-Visit": token})
        self.assertEqual(response.status_code, 404)
        self.assertEqual(self.client.get(f"/api/admin/activity/{sid}", headers={"X-Traza-Visit": token}).status_code, 401)
        self.assertEqual(self.client.delete(f"/api/activity/sessions/{sid}", headers={"X-Traza-Visit": token}).status_code, 404)

    def test_event_idempotency_and_conflict(self):
        sid = self.start(); event_id = uid()
        first = self.event(sid, event_id=event_id)
        again = self.event(sid, sequence=1, event_id=event_id)
        self.assertEqual(first.json(), again.json())
        self.assertEqual(self.event(sid, value=0, sequence=1, event_id=event_id).status_code, 409)
        self.assertEqual(len(self.detail(sid)["event_history"]), 1)

    def test_out_of_order_rejected_without_revision_loss(self):
        sid = self.start()
        self.assertEqual(self.event(sid, sequence=2).status_code, 409)
        self.assertEqual(self.detail(sid)["session"]["revision"], 0)
        self.assertEqual(self.event(sid).status_code, 200)
        self.assertEqual(self.event(sid, sequence=1).status_code, 409)
        self.assertEqual(self.event(sid, qid="E3").status_code, 200)

    def test_answers_snapshot_history_encrypted_and_missing_not_zero(self):
        sid = self.start()
        self.assertEqual(self.event(sid, fid="PHQ9", qid="PHQ9_1", value=98).status_code, 200)
        self.assertEqual(self.event(sid, fid="PHQ9", qid="PHQ9_2", value=99).status_code, 200)
        self.assertEqual(self.event(sid, fid="PHQ9", qid="PHQ9_3", value=None).status_code, 200)
        detail = self.detail(sid)
        self.assertEqual(detail["answers"]["forms"]["PHQ9"]["answers"], {"PHQ9_1": 98, "PHQ9_2": 99})
        with self.db.connection() as con:
            snapshot = con.execute("SELECT snapshot_enc FROM activity_sessions WHERE id=?", (sid,)).fetchone()[0]
            event = con.execute("SELECT payload_enc FROM activity_events WHERE session_id=? LIMIT 1", (sid,)).fetchone()[0]
        self.assertTrue(snapshot.startswith("gAAAA")); self.assertTrue(event.startswith("gAAAA"))
        self.assertNotIn("PHQ9_1", snapshot); self.assertNotIn("PHQ9_1", event)

    def test_invalid_answer_types_ranges_ids_are_not_persisted(self):
        sid = self.start()
        for fid, qid, value in [("PHQ9", "PHQ9_1", True), ("PHQ9", "PHQ9_1", 7), ("PHQ9", "NO_SUCH_Q", 0), ("SDS", "SDS_1", 1), ("context", "E2", {}), ("context", "E2", 1.0)]:
            self.assertEqual(self.event(sid, fid=fid, qid=qid, value=value).status_code, 422)
        self.assertEqual(self.detail(sid)["session"]["revision"], 0)

    def test_conditional_questions_rejected_then_pruned(self):
        sid = self.start()
        self.assertEqual(self.event(sid, fid="PCPTSD5", qid="PCPTSD5_1", value=1).status_code, 422)
        self.assertEqual(self.event(sid, fid="PCPTSD5", qid="PCPTSD5_EXPOSURE", value=1).status_code, 200)
        self.assertEqual(self.event(sid, fid="PCPTSD5", qid="PCPTSD5_1", value=1).status_code, 200)
        self.assertEqual(self.event(sid, fid="PCPTSD5", qid="PCPTSD5_EXPOSURE", value=0).status_code, 200)
        detail = self.detail(sid)
        self.assertNotIn("PCPTSD5_1", detail["answers"]["forms"]["PCPTSD5"]["answers"])
        self.assertEqual(detail["event_history"][1]["value"], 1)

    def test_context_branch_clears_dependent_answer(self):
        sid = self.start()
        self.assertEqual(self.event(sid, qid="EC", value=2).status_code, 422)
        self.assertEqual(self.event(sid).status_code, 200)
        self.assertEqual(self.event(sid, qid="EC", value=2).status_code, 200)
        self.assertEqual(self.event(sid, value=0).status_code, 200)
        self.assertNotIn("EC", self.detail(sid)["answers"]["context"])

    def test_substance_filter_excludes_modules_and_prunes_previous_answers(self):
        sid = self.start(route="completo")
        self.assertEqual(self.event(sid, qid="USE_ALCOHOL", value=1).status_code, 422)
        self.assertEqual(self.event(sid, qid="INCLUDE_SUBSTANCES", value=1).status_code, 200)
        self.assertEqual(self.event(sid, qid="USE_ALCOHOL", value=1).status_code, 200)
        form = self.svc.forms["SOCRATES8A"]; question = battery.form_items(form)[0]
        self.assertEqual(self.event(sid, fid="SOCRATES8A", qid=question["id"], value=question["options"][0]["value"]).status_code, 200)
        self.assertEqual(self.event(sid, qid="INCLUDE_SUBSTANCES", value=0).status_code, 200)
        detail = self.detail(sid)
        self.assertNotIn("USE_ALCOHOL", detail["answers"]["context"])
        self.assertNotIn("SOCRATES8A", detail["answers"]["forms"])
        self.assertEqual(self.event(sid, fid="SOCRATES8A", qid=question["id"], value=question["options"][0]["value"]).status_code, 422)

    def test_edit_inventory_prunes_stale_filtered_followup(self):
        sid = self.start(form="MFC12")
        self.assertEqual(self.event(sid, fid="MFC12", qid="MFC1", value=1).status_code, 200)
        self.assertEqual(self.event(sid, fid="MFC12", qid="MFC-R", value="MFC1").status_code, 200)
        self.assertEqual(self.event(sid, fid="MFC12", qid="MFC2", value=1).status_code, 200)
        self.assertEqual(self.event(sid, fid="MFC12", qid="MFC1", value=0).status_code, 200)
        self.assertNotIn("MFC-R", self.detail(sid)["answers"]["forms"]["MFC12"]["answers"])
        self.assertEqual(self.event(sid, fid="MFC12", qid="MFC-R", value="MFC1").status_code, 422)

    def test_omit_resume_and_route_change_prune_snapshot(self):
        sid = self.start(route="completo")
        self.assertEqual(self.event(sid, fid="PHQ9", qid="PHQ9_1", value=2).status_code, 200)
        self.assertEqual(self.event(sid, typ="omit_form", fid="PHQ9", qid=None, value=None).status_code, 200)
        self.assertNotIn("PHQ9", self.detail(sid)["answers"]["forms"])
        self.assertEqual(self.event(sid, fid="PHQ9", qid="PHQ9_1", value=1).status_code, 422)
        self.assertEqual(self.event(sid, typ="resume_form", fid="PHQ9", qid=None, value=None).status_code, 200)
        self.assertEqual(self.event(sid, typ="route_change", fid=None, qid=None, value="basico").status_code, 200)
        self.assertEqual(self.detail(sid)["session"]["route_id"], "basico")
        self.assertEqual(self.event(sid, fid="ITQ", qid="ITQ_P1", value=1).status_code, 422)

    def test_text_limit_control_characters_and_markup_preserved_safely(self):
        sid = self.start(form="LEC5")
        form = self.svc.forms["LEC5"]
        text = next(q for q in battery.form_items(form) if q.get("type") == "text")
        # Open the source bank's branch with exact allowed answers.
        answers = {}
        for q in battery.form_items(form):
            if q["id"] == text["id"]:
                break
            if battery.visible(q, answers) and q.get("type") != "text":
                v = q["options"][0]["value"] if q.get("type") != "number" else q.get("min", 0)
                if q.get("multiple"): v = [v]
                r = self.event(sid, fid="LEC5", qid=q["id"], value=v)
                if r.status_code == 200: answers[q["id"]] = v
        if not battery.visible(text, answers):
            self.skipTest("Text branch not selected by source's first options")
        self.assertEqual(self.event(sid, fid="LEC5", qid=text["id"], value="x" * 501).status_code, 422)
        self.assertEqual(self.event(sid, fid="LEC5", qid=text["id"], value="bad\x01value").status_code, 422)
        self.assertEqual(self.event(sid, fid="LEC5", qid=text["id"], value="<script>synthetic</script>").status_code, 200)
        self.assertIn("<script>", self.detail(sid)["answers"]["forms"]["LEC5"]["answers"][text["id"]])

    def test_battery_complete_stats_recomputed(self):
        sid = self.start(form="GAD7")
        for q in battery.form_items(self.svc.forms["GAD7"]):
            self.assertEqual(self.event(sid, fid="GAD7", qid=q["id"], value=0).status_code, 200)
        self.assertEqual(self.event(sid, typ="complete", fid=None, qid=None, value=None).status_code, 200)
        data = self.dashboard()
        self.assertEqual(data["summary"], {"visits": 1, "started": 1, "completed": 1, "reports": 0, "answers": 7})
        self.assertEqual(data["tests"], [{"id": "GAD7", "name": "GAD-7", "started": 1, "completed": 1}])
        self.assertEqual(self.event(sid, fid="GAD7", qid="GAD7_1", value=98).status_code, 200)
        self.assertEqual(self.dashboard()["tests"][0]["completed"], 0)

    def test_battery_safety_answer_is_saved_without_changing_scale(self):
        sid = self.start(form="GAD7")
        self.assertEqual(self.event(sid, fid="context", qid="S3", value=99).status_code, 200)
        self.assertEqual(self.event(sid, fid="context", qid="E2", value=1).status_code, 422)
        detail = self.detail(sid)
        self.assertEqual(detail["answers"]["context"], {"S3": 99})
        self.assertEqual(detail["scores"], [])

    def test_battery_score_requires_consent_and_acknowledged_answers(self):
        sid = self.start(form="GAD7")
        payload = {"answers": {"GAD7_1": 2}, "form_version": self.svc.forms["GAD7"].get("version", "1.0")}
        path = "/api/battery/GAD7/score"
        self.assertEqual(self.client.post(path, json=payload).status_code, 401)
        headers = {**self.headers, "X-Traza-Activity-Session": sid}
        self.assertEqual(self.client.post(path, json=payload, headers=headers).status_code, 409)
        self.assertEqual(self.event(sid, fid="GAD7", qid="GAD7_1", value=2).status_code, 200)
        response = self.client.post(path, json=payload, headers=headers)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertFalse(response.json()["complete"])
        self.assertIsNone(response.json()["total"])

    def test_dashboard_role_mfa_password_boundaries(self):
        self.start()
        for headers, status in [({}, 401), ({**self.admin_headers, "X-Admin-Role": "clinician"}, 403), ({**self.admin_headers, "X-Admin-Role": "participant"}, 403), ({**self.admin_headers, "X-Admin-MFA": "0"}, 403), ({**self.admin_headers, "X-Admin-Password": "0"}, 403)]:
            self.assertEqual(self.client.get("/api/admin/activity", headers=headers).status_code, status)

    def test_dashboard_has_no_answer_consent_tokens_or_health_content(self):
        sid = self.start()
        self.event(sid, fid="PHQ9", qid="PHQ9_1", value=3)
        raw = json.dumps(self.dashboard())
        for forbidden in ("PHQ9_1", "consent", "event_history", "visit_token", "snapshot_enc", self.visit["visit_token"], '"value"', '"analysis"'):
            self.assertNotIn(forbidden, raw)
        with self.db.connection() as con:
            audit = [dict(r) for r in con.execute("SELECT * FROM audit")]
        self.assertNotIn("PHQ9_1", json.dumps(audit))
        self.assertNotIn("synthetic-owner", json.dumps(audit))

    def test_pagination_filters_and_bad_cursor(self):
        ids = {self.start(), self.start(), self.start(form="GAD7")}
        data = self.dashboard(limit=2)
        self.assertEqual(len(data["sessions"]), 2); self.assertTrue(data["next_cursor"])
        next_page = self.dashboard(limit=2, cursor=data["next_cursor"])
        listed = {s["id"] for s in data["sessions"] + next_page["sessions"]}
        self.assertEqual(listed, ids)
        self.assertEqual(self.dashboard(device="mobile")["summary"]["visits"], 0)
        self.assertEqual(self.dashboard(route="basico")["summary"]["started"], 2)
        self.assertEqual(self.dashboard(form="GAD7")["summary"]["started"], 1)
        for params in [{"limit": 101}, {"cursor": "not-a-cursor"}, {"device": "PHONE"}, {"form": "SDS"}, {"from": "2026-04-01", "to": "2025-01-01"}, {"from": "bad"}, {"unknown": 1}]:
            self.assertEqual(self.client.get("/api/admin/activity", params=params, headers=self.admin_headers).status_code, 422)

    def test_detail_access_audited_without_answers_in_audit(self):
        sid = self.start(); self.event(sid)
        detail = self.detail(sid)
        self.assertEqual(detail["answers"]["context"], {"E2": 1})
        with self.db.connection() as con:
            row = con.execute("SELECT * FROM audit WHERE action='activity_session_viewed'").fetchone()
        self.assertIsNotNone(row); self.assertNotEqual(row["subject"], sid)
        self.assertNotIn("E2", json.dumps(dict(row)))

    def make_report(self, sid):
        payload = {"version": "4.0", "route_id": "basico", "request_id": uid(),
                   "consent": {"adult": True, "processing": True, "ai": True, "version": "4.0"},
                   "context_answers": {"E2": 0}, "forms": {}, "safety_state": {"current_risk": False, "unsafe": False}}
        self.event(sid, qid="E2", value=0)
        for fid in journey.expected_forms("basico", payload["context_answers"]):
            answers = {}
            for q in battery.form_items(self.svc.forms[fid]):
                if not battery.visible(q, answers) or q.get("type") == "text": continue
                v = q["options"][0]["value"] if q.get("type") != "number" else q.get("min", 0)
                if q.get("multiple"): v = [v]
                self.assertEqual(self.event(sid, fid=fid, qid=q["id"], value=v).status_code, 200)
                answers[q["id"]] = v
            payload["forms"][fid] = {"version": self.svc.forms[fid].get("version", "1.0"), "answers": answers}
        clean = journey.validate_payload(payload)
        # Signing requires no API call. The service authenticates actual app
        # signatures; text below is deliberately synthetic and never published.
        analysis = {"summary": "Synthetic integration fixture", "profile": {}, "patterns": [], "next_steps": [], "questions_for_professional": [], "professional": {}}
        report = journey.build_report(clean, analysis)
        return {"report": report, "signature": self.app.state.journey.sign_report(report)}

    def test_report_signature_snapshot_binding_idempotency_and_encryption(self):
        sid = self.start(); packet = self.make_report(sid)
        payload = {"event_id": uid(), "packet": packet}
        path = f"/api/activity/sessions/{sid}/report"
        response = self.client.post(path, json=payload, headers=self.headers)
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(self.client.post(path, json=payload, headers=self.headers).json(), response.json())
        tampered = deepcopy(payload); tampered["packet"]["report"]["analysis"]["summary"] = "altered"
        self.assertEqual(self.client.post(path, json=tampered, headers=self.headers).status_code, 403)
        self.assertEqual(self.detail(sid)["report"], packet)
        with self.db.connection() as con:
            encrypted = con.execute("SELECT payload_enc FROM activity_reports").fetchone()[0]
        self.assertNotIn("Synthetic integration fixture", encrypted)
        self.assertTrue(encrypted.startswith("gAAAA"))
        self.assertEqual(self.dashboard()["summary"]["reports"], 1)
        self.event(sid, qid="E2", value=1)
        different = {"event_id": uid(), "packet": packet}
        self.assertEqual(self.client.post(path, json=different, headers=self.headers).status_code, 409)

    def test_report_from_other_route_or_empty_session_rejected(self):
        sid = self.start(); packet = self.make_report(sid)
        second = self.start()
        response = self.client.post(f"/api/activity/sessions/{second}/report", json={"event_id": uid(), "packet": packet}, headers=self.headers)
        self.assertEqual(response.status_code, 409)
        third = self.start(route="intermedio")
        response = self.client.post(f"/api/activity/sessions/{third}/report", json={"event_id": uid(), "packet": packet}, headers=self.headers)
        self.assertEqual(response.status_code, 409)

    def query_payload(self, sid):
        detail = self.detail(sid)
        answers = detail["answers"]
        expected = set(journey.expected_forms(detail["session"]["route_id"], answers["context"])) - set(answers["omitted_form_ids"])
        return {"version": "4.0", "route_id": detail["session"]["route_id"], "request_id": uid(),
                "consent": {"adult": True, "processing": True, "ai": True, "version": "4.0"},
                "context_answers": answers["context"],
                "forms": {fid: answers["forms"].get(fid, {"version": self.svc.forms[fid].get("version", "1.0"), "answers": {}}) for fid in expected},
                "safety_state": {"current_risk": False, "unsafe": False}}

    def test_ai_route_requires_storage_session_before_cost(self):
        sid = self.start(); packet = self.make_report(sid); payload = self.query_payload(sid)
        with patch.object(self.app.state.journey, "report", new_callable=AsyncMock, return_value=packet) as model:
            self.assertEqual(self.client.post("/api/journey/report", json=payload).status_code, 401)
            headers = {**self.headers, "X-Traza-Activity-Session": sid}
            altered = deepcopy(payload); altered["forms"]["PHQ9"]["answers"]["PHQ9_1"] = 3
            self.assertEqual(self.client.post("/api/journey/report", json=altered, headers=headers).status_code, 409)
            model.assert_not_awaited()
        self.assertEqual(self.detail(sid)["queries"], [])

    def test_ai_request_response_saved_before_return_and_retried_without_cost(self):
        sid = self.start(); packet = self.make_report(sid); payload = self.query_payload(sid)
        headers = {**self.headers, "X-Traza-Activity-Session": sid}
        with patch.object(self.app.state.journey, "report", new_callable=AsyncMock, return_value=packet) as model:
            first = self.client.post("/api/journey/report", json=payload, headers=headers)
            self.assertEqual(first.status_code, 200, first.text)
            self.assertEqual(self.client.post("/api/journey/report", json=payload, headers=headers).json(), packet)
            self.assertEqual(model.await_count, 1)
        detail = self.detail(sid)
        self.assertEqual(detail["queries"][0]["status"], "succeeded")
        self.assertEqual(detail["queries"][0]["payload"], payload)
        self.assertEqual(detail["queries"][0]["packet"], packet)
        self.assertEqual(self.dashboard()["summary"]["reports"], 1)
        # The UI's explicit receipt is safe after automatic server persistence.
        receipt = {"event_id": uid(), "packet": packet}
        path = f"/api/activity/sessions/{sid}/report"
        self.assertEqual(self.client.post(path, json=receipt, headers=self.headers).status_code, 200)
        self.assertEqual(self.client.post(path, json=receipt, headers=self.headers).status_code, 200)
        self.assertEqual(self.dashboard()["summary"]["reports"], 1)
        with self.db.connection() as con:
            row = dict(con.execute("SELECT * FROM activity_queries").fetchone())
        self.assertNotIn("PHQ9_1", json.dumps(row)); self.assertNotIn("Synthetic integration", json.dumps(row))

    def test_failed_ai_query_records_generic_error_and_allows_retry(self):
        sid = self.start(); packet = self.make_report(sid); payload = self.query_payload(sid)
        headers = {**self.headers, "X-Traza-Activity-Session": sid}
        error = journey.JourneyError("provider_error", "Synthetic private provider detail", 503)
        with patch.object(self.app.state.journey, "report", new_callable=AsyncMock, side_effect=[error, packet]) as model:
            response = self.client.post("/api/journey/report", json=payload, headers=headers)
            self.assertEqual(response.status_code, 503)
            detail = self.detail(sid)
            self.assertEqual(detail["queries"][0]["status"], "error")
            self.assertEqual(detail["queries"][0]["error_code"], "provider_error")
            self.assertNotIn("private provider detail", json.dumps(detail["queries"]))
            response = self.client.post("/api/journey/report", json=payload, headers=headers)
            self.assertEqual(response.status_code, 200, response.text)
            self.assertEqual(model.await_count, 2)
        self.assertEqual(self.detail(sid)["queries"][0]["attempt_count"], 2)

    def test_pending_ai_query_and_changed_idempotency_payload_blocked(self):
        sid = self.start(); self.make_report(sid); payload = self.query_payload(sid)
        clean = journey.validate_payload(payload)
        query = self.svc.begin_query(sid, self.visit["visit_token"], payload, clean)
        headers = {**self.headers, "X-Traza-Activity-Session": sid}
        with patch.object(self.app.state.journey, "report", new_callable=AsyncMock) as model:
            self.assertEqual(self.client.post("/api/journey/report", json=payload, headers=headers).status_code, 409)
            model.assert_not_awaited()
        self.svc.fail_query(query, "bad:error contains secret")
        self.assertEqual(self.detail(sid)["queries"][0]["error_code"], "internal_error")
        changed = deepcopy(payload); changed["safety_state"]["unsafe"] = True
        self.assertEqual(self.client.post("/api/journey/report", json=changed, headers=headers).status_code, 409)

    def test_rate_limits_before_database_only_hmac_keys_in_ram(self):
        # Initial setUp visit consumed one slot.
        for _ in range(119):
            self.svc.rate("visits", "testclient")
        with self.assertRaises(HTTPException) as error:
            self.svc.rate("visits", "testclient")
        self.assertEqual(error.exception.status_code, 429)
        self.assertNotIn("testclient", repr(self.svc.rate_buckets))
        before = self.dashboard()["summary"]["visits"]
        payload = deepcopy(self.visit_payload); payload["event_id"] = uid()
        self.assertEqual(self.client.post("/api/activity/visits", json=payload).status_code, 429)
        self.assertEqual(self.dashboard()["summary"]["visits"], before)
        # Distinct visitors are independently limited within the global ceiling.
        self.svc.rate("visits", "synthetic-other-network")

    def test_rate_buckets_expire_after_one_hour(self):
        with patch("activity.time.monotonic", return_value=10000):
            for _ in range(90): self.svc.rate("sessions", "synthetic-network")
            with self.assertRaises(HTTPException): self.svc.rate("sessions", "synthetic-network")
        with patch("activity.time.monotonic", return_value=13601):
            self.svc.rate("sessions", "synthetic-network")

    def test_delete_cascades_health_and_leaves_only_minimal_visit(self):
        sid = self.start(); packet = self.make_report(sid)
        self.client.post(f"/api/activity/sessions/{sid}/report", json={"event_id": uid(), "packet": packet}, headers=self.headers)
        response = self.client.delete(f"/api/activity/sessions/{sid}", headers=self.headers)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.client.get(f"/api/admin/activity/{sid}", headers=self.admin_headers).status_code, 404)
        with self.db.connection() as con:
            for table in ("activity_sessions", "activity_events", "activity_reports", "activity_session_forms", "activity_queries", "activity_report_receipts"):
                self.assertEqual(con.execute("SELECT count(*) FROM " + table).fetchone()[0], 0)
            self.assertEqual(con.execute("SELECT count(*) FROM activity_visits").fetchone()[0], 1)

    def test_retention_purges_health_and_old_visits(self):
        sid = self.start(); self.event(sid)
        with self.db.connection(transaction=True) as con:
            con.execute("UPDATE activity_visits SET created_at=?", (time.time() - 91 * 86400,))
        self.svc.purge(force=True)
        with self.db.connection() as con:
            self.assertEqual(con.execute("SELECT count(*) FROM activity_events").fetchone()[0], 0)
            self.assertEqual(con.execute("SELECT count(*) FROM activity_sessions").fetchone()[0], 0)
        self.assertEqual(self.dashboard()["summary"]["visits"], 0)

    def test_battery_ai_events_and_invalid_event_data_rejected(self):
        sid = self.start(form="GAD7")
        self.assertEqual(self.event(sid, typ="ai_request", fid=None, qid=None, value=None).status_code, 422)
        self.assertEqual(self.event(sid, typ="export", fid=None, qid=None, value="private note").status_code, 422)
        self.assertEqual(self.event(sid, typ="complete", fid="GAD7", qid=None, value=None).status_code, 422)
        self.assertEqual(self.event(sid, typ="route_change", fid=None, qid=None, value={}).status_code, 422)


if __name__ == "__main__":
    unittest.main(verbosity=2)
