import os,sys,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
IMPORT=tempfile.TemporaryDirectory()
with patch.dict(os.environ,{'TRAZA_DATA_DIR':IMPORT.name}):from server import create_app

class CrioTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.app=create_app(self.temp.name);self.client=TestClient(self.app);self.client.__enter__();self.addCleanup(self.client.__exit__,None,None,None);self.addCleanup(self.temp.cleanup)
 def test_crio_routes_and_sources(self):
  page=self.client.get('/crio');self.assertEqual(page.status_code,200)
  for text in ['Wim Hof','24 voluntarios sanos','No aisló el efecto del frío','pubmed.ncbi.nlm.nih.gov/24799686','guinnessworldrecords.com','No intentar reproducir']:
   self.assertIn(text,page.text)
  for path in ['/crio.css','/media/crio-hielo.webp','/media/crio-hielo-mobile.webp']:
   self.assertEqual(self.client.get(path).status_code,200,path)
 def test_payment_is_optional_and_points_to_supplied_account(self):
  r=self.client.get('/donar');self.assertEqual(r.status_code,200)
  self.assertIn('https://link.mercadopago.com.mx/nemy',r.text)
  self.assertIn('donar es completamente opcional',r.text)
  for path in ['/dtr.js','/journey.js']:
   text=self.client.get(path).text;self.assertIn('href="/donar"',text);self.assertIn('Descargar mi PDF',text)
 def test_home_links_crio_and_donation(self):
  html=self.client.get('/').text
  self.assertIn('href="/crio"',html);self.assertIn('href="/donar"',html)

if __name__=='__main__':unittest.main()
