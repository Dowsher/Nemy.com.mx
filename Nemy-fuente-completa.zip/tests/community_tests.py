"""Isolated synthetic membership/community checks; no real messages or provider calls."""
import asyncio
from copy import deepcopy
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import AsyncMock, patch
import uuid

import httpx
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from db import Database
from community import attach_community, CommunityService, COOKIE, OtpDeliveryUncertain, HttpOtpSender
from moderation import CommentModerator, ModerationUnavailable

newid=lambda:str(uuid.uuid4())


class Sender:
    def __init__(self):self.sent=[];self.error=None
    def available(self):return True
    async def send(self,request_id,phone,code):
        self.sent.append({"request_id":request_id,"phone":phone,"code":code})
        if self.error:raise self.error


class Moderator:
    def __init__(self):self.calls=[];self.error=False;self.decision={"action":"publish","category":"none","reason":""}
    def available(self):return True
    async def review(self,body,context):
        self.calls.append((body,context))
        if self.error:raise ModerationUnavailable()
        return self.decision


class CommunityTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.db=Database(self.tmp.name);self.sender=Sender();self.mod=Moderator()
        self.app=FastAPI()
        def admin(req):
            if req.headers.get('X-Test-Admin')!='verified-admin':raise HTTPException(401,'Inicia sesión.')
            return {"id":"isolated-admin","role":"admin"}
        with patch.dict(os.environ,{"TRAZA_SECURE_COOKIE":"1"}):self.svc=attach_community(self.app,self.db,admin,self.sender,self.mod)
        self.client=TestClient(self.app,base_url='https://nemy.test');self.addCleanup(self.client.close)
        self.admin={'X-Test-Admin':'verified-admin'}
        self.phone_index=0

    def request(self,phone=None,client=None):
        self.phone_index+=1;phone=phone or '+52550000'+str(self.phone_index).zfill(4)
        payload={'phone':phone,'adult':True,'consent':True,'request_id':newid()}
        response=(client or self.client).post('/api/community/auth/request-code',json=payload)
        self.assertEqual(response.status_code,200,response.text)
        return response.json(),payload

    def login(self,client=None):
        client=client or self.client;challenge,p=self.request(client=client)
        response=client.post('/api/community/auth/verify-code',json={'challenge_id':challenge['challenge_id'],'code':self.sender.sent[-1]['code']})
        self.assertEqual(response.status_code,200,response.text)
        return response.json()['user'],challenge,response

    def other(self):
        c=TestClient(self.app,base_url='https://nemy.test');self.addCleanup(c.close);u,_,_=self.login(c);return c,u

    def post(self,client=None,**extra):
        payload={'request_id':newid(),'topic':'emotions','body':'Una experiencia propia sin datos personales.',**extra}
        r=(client or self.client).post('/api/community/posts',json=payload);self.assertEqual(r.status_code,200,r.text)
        return r.json()['post'],payload

    def comment(self,post,client=None,**extra):
        payload={'request_id':newid(),'body':'Qué pinche semana. Me identifico con lo que cuentas.','ai_consent':True,**extra}
        r=(client or self.client).post('/api/community/posts/'+post['id']+'/comments',json=payload)
        self.assertEqual(r.status_code,200,r.text);return r.json(),payload

    def test_public_visibility_requires_explicit_consent_and_never_exposes_comments(self):
        self.login();private,_=self.post();public,_=self.post(publicly_visible=True)
        self.assertFalse(private['publicly_visible']);self.assertTrue(public['publicly_visible'])
        self.comment(public)
        anonymous=TestClient(self.app,base_url='https://nemy.test');self.addCleanup(anonymous.close)
        r=anonymous.get('/api/community/public-posts');self.assertEqual(r.status_code,200)
        posts=r.json()['posts'];self.assertEqual([p['id'] for p in posts],[public['id']])
        self.assertEqual(set(posts[0]),{'id','topic','body','author','created_at','updated_at'})
        self.assertEqual(set(posts[0]['author']),{'alias','avatar'})
        self.assertNotIn('comments',r.text);self.assertNotIn('reactions',r.text);self.assertNotIn('phone',r.text)
        self.assertEqual(anonymous.get('/api/community/posts').status_code,401)
        self.assertEqual(anonymous.get('/api/community/posts/'+public['id']+'/comments').status_code,401)
        self.assertEqual(anonymous.post('/api/community/posts/'+public['id']+'/reaction',json={'kind':'support'}).status_code,401)
        self.assertEqual(anonymous.post('/api/community/posts/'+public['id']+'/comments',json={}).status_code,401)

    def test_author_can_opt_in_and_revoke_existing_post_but_others_cannot(self):
        self.login();post,_=self.post();other,_=self.other();path='/api/community/posts/'+post['id']
        edit={'body':post['body'],'topic':post['topic'],'publicly_visible':True}
        self.assertEqual(other.patch(path,json=edit).status_code,403)
        r=self.client.patch(path,json=edit);self.assertEqual(r.status_code,200);self.assertTrue(r.json()['post']['publicly_visible'])
        anon=TestClient(self.app,base_url='https://nemy.test');self.addCleanup(anon.close)
        self.assertEqual([p['id'] for p in anon.get('/api/community/public-posts').json()['posts']],[post['id']])
        # An old client editing text without a visibility field preserves consent.
        self.assertTrue(self.client.patch(path,json={'body':post['body'],'topic':post['topic']}).json()['post']['publicly_visible'])
        self.assertFalse(self.client.patch(path,json={**edit,'publicly_visible':False}).json()['post']['publicly_visible'])
        self.assertEqual(anon.get('/api/community/public-posts').json()['posts'],[])
        with self.db.connection() as c:
            actions=[r[0] for r in c.execute("SELECT action FROM audit WHERE action LIKE 'nemy_post_public_%'")]
        self.assertIn('nemy_post_public_consent',actions);self.assertIn('nemy_post_public_revoked',actions)

    def test_public_opt_in_validation_pagination_and_deleted_or_disabled_accounts(self):
        user,_,_=self.login()
        payload={'request_id':newid(),'topic':'emotions','body':'Texto','publicly_visible':'true'}
        self.assertEqual(self.client.post('/api/community/posts',json=payload).status_code,422)
        p1,_=self.post(publicly_visible=True);p2,_=self.post(publicly_visible=True,topic='addictions')
        anon=TestClient(self.app,base_url='https://nemy.test');self.addCleanup(anon.close)
        page=anon.get('/api/community/public-posts?limit=1').json();self.assertEqual(len(page['posts']),1);self.assertTrue(page['next_cursor'])
        more=anon.get('/api/community/public-posts',params={'limit':1,'cursor':page['next_cursor']}).json();self.assertEqual(len(more['posts']),1)
        self.assertNotEqual(page['posts'][0]['id'],more['posts'][0]['id'])
        self.assertEqual([p['id'] for p in anon.get('/api/community/public-posts?topic=addictions').json()['posts']],[p2['id']])
        self.assertEqual(anon.get('/api/community/public-posts?mine=1').status_code,422)
        self.assertEqual(self.client.request('DELETE','/api/community/posts/'+p1['id'],json={}).status_code,200)
        with self.db.connection() as c:self.assertIsNone(c.execute('SELECT 1 FROM nemy_public_post_consents WHERE post_id=?',(p1['id'],)).fetchone())
        with self.db.connection(transaction=True) as c:c.execute('UPDATE nemy_members SET disabled=1 WHERE id=?',(user['id'],))
        self.assertEqual(anon.get('/api/community/public-posts').json()['posts'],[])

    def test_config_discloses_alias_phone_context_and_exact_topics(self):
        c=self.client.get('/api/community/config').json()
        self.assertTrue(c['otp_available']);self.assertEqual(c['otp_digits'],4);self.assertEqual(c['phone_region'],'MX')
        self.assertEqual([r['id'] for r in c['topics']],['emotions','addictions','stagnation'])
        self.assertIn('fragmento',c['privacy']);self.assertIn('no se muestra',c['privacy'])
        self.assertEqual(self.client.get('/api/community/auth/me').json(),{'user':None})

    def test_otp_no_secret_in_api_database_or_audit_and_cookie_isolated(self):
        u,ch,r=self.login();s=self.sender.sent[-1]
        self.assertRegex(s['code'],r'^[0-9]{4}$');self.assertNotIn('code',ch)
        self.assertEqual(ch['masked_phone'],'•••• '+s['phone'][-4:]);self.assertLessEqual(ch['expires_in'],300)
        self.assertNotIn('phone',u);self.assertIn('HttpOnly',r.headers['set-cookie']);self.assertIn('Secure',r.headers['set-cookie'])
        self.assertIn('SameSite=strict',r.headers['set-cookie']);self.assertIn(COOKIE,r.headers['set-cookie'])
        with self.db.connection()as c:
            otp=dict(c.execute('SELECT * FROM nemy_otp').fetchone());member=dict(c.execute('SELECT * FROM nemy_members').fetchone());audit=[dict(x)for x in c.execute('SELECT * FROM audit')]
        self.assertEqual(otp['code_hash'],'');self.assertNotIn(s['phone'],json.dumps([otp,member,audit]));self.assertNotIn(s['phone'],r.text)
        self.assertEqual(self.client.get('/api/community/profile').json()['user']['id'],u['id'])
        self.assertEqual(self.client.post('/api/community/auth/verify-code',json={'challenge_id':ch['challenge_id'],'code':s['code']}).status_code,401)

    def test_otp_attempts_commit_and_five_wrong_codes_lock(self):
        ch,_=self.request();code=self.sender.sent[-1]['code'];wrong='9999'if code!='9999'else'8888'
        for _ in range(5):self.assertEqual(self.client.post('/api/community/auth/verify-code',json={'challenge_id':ch['challenge_id'],'code':wrong}).status_code,401)
        with self.db.connection()as c:
            row=c.execute('SELECT attempts,status FROM nemy_otp WHERE id=?',(ch['challenge_id'],)).fetchone()
        self.assertEqual(tuple(row),(5,'locked'))
        self.assertEqual(self.client.post('/api/community/auth/verify-code',json={'challenge_id':ch['challenge_id'],'code':code}).status_code,401)
        self.assertEqual(self.client.get('/api/community/auth/me').json()['user'],None)

    def test_expiry_consent_and_invalid_phone_do_not_sign_in(self):
        ch,p=self.request()
        with self.db.connection(transaction=True)as c:c.execute('UPDATE nemy_otp SET expires_at=? WHERE id=?',(time.time()-1,ch['challenge_id']))
        self.assertEqual(self.client.post('/api/community/auth/verify-code',json={'challenge_id':ch['challenge_id'],'code':self.sender.sent[-1]['code']}).status_code,401)
        for field,value in (('adult',False),('consent',1),('phone','bad'),('phone','+15555555555')):
            pp={**p,'request_id':newid(),field:value};self.assertIn(self.client.post('/api/community/auth/request-code',json=pp).status_code,(403,422))
        self.assertEqual(len(self.sender.sent),1)

    def test_request_id_is_idempotent_and_different_body_conflicts(self):
        ch,p=self.request();r=self.client.post('/api/community/auth/request-code',json=p)
        self.assertEqual(r.status_code,200);self.assertEqual(r.json()['challenge_id'],ch['challenge_id']);self.assertEqual(len(self.sender.sent),1)
        self.assertEqual(self.client.post('/api/community/auth/request-code',json={**p,'phone':'+525500009999'}).status_code,409)
        self.assertEqual(self.client.post('/api/community/auth/request-code',json={**p,'request_id':newid()}).status_code,429)

    def test_uncertain_delivery_preserves_one_usable_code_and_never_resends(self):
        self.sender.error=OtpDeliveryUncertain();ch,p=self.request()
        self.assertEqual(ch['delivery_status'],'uncertain');self.assertIn('no se confirmó',ch['notice'])
        self.assertEqual(self.client.post('/api/community/auth/request-code',json=p).json()['challenge_id'],ch['challenge_id'])
        self.assertEqual(len(self.sender.sent),1)
        r=self.client.post('/api/community/auth/verify-code',json={'challenge_id':ch['challenge_id'],'code':self.sender.sent[-1]['code']})
        self.assertEqual(r.status_code,200,r.text)

    def test_explicit_sender_failure_does_not_fake_sent_or_usable_code(self):
        self.sender.error=RuntimeError('PRIVATE_SENDER_DETAIL')
        p={'phone':'+525500001111','adult':True,'consent':True,'request_id':newid()}
        r=self.client.post('/api/community/auth/request-code',json=p);self.assertEqual(r.status_code,503);self.assertNotIn('PRIVATE',r.text)
        with self.db.connection()as c:row=c.execute('SELECT * FROM nemy_otp').fetchone()
        self.assertEqual(row['status'],'failed');self.assertEqual(row['code_hash'],'')
        self.assertEqual(self.client.post('/api/community/auth/verify-code',json={'challenge_id':row['id'],'code':self.sender.sent[0]['code']}).status_code,401)

    def test_rate_limits_survive_service_restart_and_do_not_store_ip(self):
        for _ in range(2):self.svc.limit('isolated-rate','PRIVATE_NETWORK_ADDRESS',2,900)
        other=CommunityService(self.db,self.sender,self.mod)
        with self.assertRaises(HTTPException)as e:other.limit('isolated-rate','PRIVATE_NETWORK_ADDRESS',2,900)
        self.assertEqual(e.exception.status_code,429)
        with self.db.connection()as c:rows=[dict(r)for r in c.execute('SELECT * FROM nemy_limits')]
        self.assertNotIn('PRIVATE_NETWORK_ADDRESS',json.dumps(rows))

    def test_hourly_cleanup_retires_expired_identity_challenges_but_preserves_active(self):
        old,_=self.request();active,_=self.request()
        with self.db.connection(transaction=True)as c:
            c.execute('UPDATE nemy_otp SET expires_at=? WHERE id=?',(time.time()-90000,old['challenge_id']))
        self.svc.last_purge=0
        self.client.get('/api/community/config')
        with self.db.connection()as c:
            self.assertIsNone(c.execute('SELECT 1 FROM nemy_otp WHERE id=?',(old['challenge_id'],)).fetchone())
            self.assertIsNotNone(c.execute('SELECT 1 FROM nemy_otp WHERE id=?',(active['challenge_id'],)).fetchone())

    def test_profile_alias_validation_uniqueness_and_no_phone(self):
        u,_,_=self.login();other,ou=self.other()
        r=self.client.patch('/api/community/profile',json={'alias':'Mi alias','bio':'Un paso a la vez.','avatar':'mint'})
        self.assertEqual(r.status_code,200,r.text);self.assertEqual(r.json()['user']['alias'],'Mi alias');self.assertNotIn('phone',r.text)
        self.assertEqual(other.patch('/api/community/profile',json={'alias':'MI ALIAS','bio':'','avatar':'blue'}).status_code,409)
        self.assertEqual(self.client.patch('/api/community/profile',json={'alias':'<script>x','bio':'','avatar':'blue'}).status_code,422)
        self.assertEqual(self.client.patch('/api/community/profile',json={'alias':'Valid','bio':'','avatar':'unlisted'}).status_code,422)
        for field,value in (('alias',[]),('bio',{}),('avatar',[])):
            self.assertEqual(self.client.patch('/api/community/profile',json={**{'alias':'Mi alias','bio':'','avatar':'blue'},field:value}).status_code,422)
        self.assertEqual(self.client.patch('/api/community/profile',json={'alias':'Mi alias','bio':'','avatar':'blue','phone':'+525500009999'}).status_code,422)
        self.assertEqual(self.client.get('/api/community/auth/me').json()['user']['alias'],'Mi alias')

    def test_feed_requires_membership_and_clinical_cookie_cannot_substitute(self):
        self.client.cookies.set('traza_session','synthetic-clinical-token')
        self.assertEqual(self.client.get('/api/community/posts').status_code,401)
        self.login();post,p=self.post(body='Texto original con groserías sin filtro automático.')
        feed=self.client.get('/api/community/posts').json()
        self.assertEqual(feed['posts'][0]['body'],p['body']);self.assertEqual(self.mod.calls,[])
        self.assertEqual(set(feed['posts'][0]['author']),{'id','alias','avatar'})
        with self.db.connection()as c:raw=c.execute('SELECT body_enc FROM nemy_posts').fetchone()[0]
        self.assertNotIn(p['body'],raw)

    def test_post_idempotency_edit_owner_delete_and_scopes(self):
        u,_,_=self.login();post,p=self.post()
        same=self.client.post('/api/community/posts',json=p);self.assertEqual(same.json()['post']['id'],post['id'])
        self.assertEqual(self.client.post('/api/community/posts',json={**p,'body':'changed'}).status_code,409)
        other,ou=self.other()
        self.assertEqual(other.patch('/api/community/posts/'+post['id'],json={'topic':'emotions','body':'stolen'}).status_code,403)
        self.assertEqual(other.request('DELETE','/api/community/posts/'+post['id'],json={}).status_code,403)
        r=self.client.patch('/api/community/posts/'+post['id'],json={'topic':'stagnation','body':'Edité mi propia publicación.'})
        self.assertEqual(r.status_code,200);self.assertEqual(r.json()['post']['topic'],'stagnation');self.assertEqual(self.mod.calls,[])
        self.assertEqual(other.get('/api/community/posts?mine=1').json()['posts'],[])
        self.assertEqual(self.client.request('DELETE','/api/community/posts/'+post['id'],json={}).status_code,200)
        self.assertEqual(other.get('/api/community/posts/'+post['id']).status_code,404)

    def test_invalid_json_types_fail_cleanly_and_cannot_change_owner(self):
        self.login();post,_=self.post()
        for topic in ([],{},True,1,None):
            self.assertEqual(self.client.patch('/api/community/posts/'+post['id'],json={'topic':topic,'body':'Una edición.'}).status_code,422)
        self.assertEqual(self.client.post('/api/community/posts',json={'request_id':newid(),'topic':'emotions','body':'hola','member_id':newid()}).status_code,422)

    def test_signed_cursor_and_topic_filter_use_real_pagination(self):
        self.login()
        for i in range(3):self.post(body='Publicación '+str(i))
        page=self.client.get('/api/community/posts?limit=2').json();self.assertEqual(len(page['posts']),2);self.assertTrue(page['next_cursor'])
        nextpage=self.client.get('/api/community/posts',params={'limit':2,'cursor':page['next_cursor']}).json();self.assertEqual(len(nextpage['posts']),1)
        self.assertEqual(self.client.get('/api/community/posts?topic=addictions').json()['posts'],[])
        self.assertEqual(self.client.get('/api/community/posts?cursor=bad').status_code,422)
        self.assertEqual(self.client.get('/api/community/posts?limit=500').status_code,422)

    def test_reactions_toggle_per_user_and_valid_enum(self):
        self.login();post,_=self.post();other,ou=self.other()
        path='/api/community/posts/'+post['id']+'/reaction'
        self.assertEqual(self.client.post(path,json={'kind':'support'}).json()['post']['reactions']['support'],1)
        self.assertEqual(other.post(path,json={'kind':'support'}).json()['post']['reactions']['support'],2)
        r=self.client.post(path,json={'kind':'support'}).json()['post'];self.assertEqual(r['reactions']['support'],1);self.assertEqual(r['my_reactions'],[])
        self.assertEqual(self.client.post(path,json={'kind':'dislike'}).status_code,422)

    def test_comment_approval_not_profane_wordlist_and_idempotent(self):
        self.login();post,_=self.post();result,p=self.comment(post)
        self.assertEqual(result['status'],'approved');self.assertEqual(result['comment']['body'],p['body'])
        self.assertEqual(self.mod.calls[0][0],p['body']);self.assertTrue(self.mod.calls[0][1])
        again=self.client.post('/api/community/posts/'+post['id']+'/comments',json=p)
        self.assertEqual(again.json()['comment']['id'],result['comment']['id']);self.assertEqual(len(self.mod.calls),1)
        other,_=self.other();comments=other.get('/api/community/posts/'+post['id']+'/comments').json()['comments']
        self.assertEqual(comments[0]['body'],p['body']);self.assertNotIn('notice',comments[0])
        self.assertEqual(self.client.get('/api/community/posts/'+post['id']).json()['post']['comment_count'],1)

    def test_long_thread_reload_keeps_latest_comment_and_reports_older_history(self):
        user,_,_=self.login();post,_=self.post();now=time.time()-300
        with self.db.connection(transaction=True)as con:
            for i in range(201):
                con.execute("INSERT INTO nemy_comments VALUES(?,?,?,?,?,?,?,NULL,0,0,?,?)",(newid(),post['id'],user['id'],newid(),'synthetic-'+str(i),self.db.encrypt('Comentario sintético '+str(i)),'approved',now+i,now+i))
        path='/api/community/posts/'+post['id']+'/comments'
        loaded=self.client.get(path).json()
        self.assertTrue(loaded['has_more']);self.assertEqual(len(loaded['comments']),200)
        self.assertEqual(loaded['comments'][0]['body'],'Comentario sintético 1')
        self.assertEqual(loaded['comments'][-1]['body'],'Comentario sintético 200')
        self.assertEqual(self.mod.calls,[])
        # Retrying the load preserves the same latest window and order.
        self.assertEqual(self.client.get(path).json(),loaded)

    def test_intervened_comment_notice_only_author_and_post_untouched(self):
        u,_,_=self.login();post,p=self.post();self.mod.decision={'action':'intervene','category':'harassment','reason':'Se detuvo porque descalifica a otra persona.'}
        r,cp=self.comment(post,body='Ataque sintético dirigido para verificar el flujo.')
        self.assertEqual(r['status'],'intervened');self.assertIn('descalifica',r['notice'])
        other,_=self.other();self.assertEqual(other.get('/api/community/posts/'+post['id']+'/comments').json()['comments'],[])
        self.assertEqual(self.client.get('/api/community/posts/'+post['id']).json()['post']['body'],p['body'])
        with self.db.connection()as c:row=dict(c.execute('SELECT * FROM nemy_comments').fetchone())
        self.assertNotIn(cp['body'],json.dumps(row));self.assertNotIn(r['notice'],json.dumps(row))

    def test_comment_provider_failure_pending_saved_and_manual_retry(self):
        self.login();post,_=self.post();self.mod.error=True;r,p=self.comment(post)
        self.assertEqual(r['status'],'pending');self.assertIn('guardado',r['notice'])
        other,_=self.other();self.assertEqual(other.get('/api/community/posts/'+post['id']+'/comments').json()['comments'],[])
        self.mod.error=False;retry=self.client.post('/api/community/comments/'+r['comment']['id']+'/retry',json={'ai_consent':True})
        self.assertEqual(retry.status_code,200);self.assertEqual(retry.json()['status'],'approved')
        self.assertEqual(len(self.mod.calls),2)

    def test_comment_consent_and_ownership_enforced(self):
        self.login();post,_=self.post()
        self.assertEqual(self.client.post('/api/community/posts/'+post['id']+'/comments',json={'request_id':newid(),'body':'hola','ai_consent':False}).status_code,403)
        r,_=self.comment(post);other,_=self.other();path='/api/community/comments/'+r['comment']['id']
        self.assertEqual(other.request('DELETE',path,json={}).status_code,403)
        self.assertEqual(other.post(path+'/retry',json={'ai_consent':True}).status_code,404)
        self.assertEqual(self.client.request('DELETE',path,json={}).status_code,200)

    def test_block_hides_posts_and_comments_and_unblock_restores(self):
        u,_,_=self.login();post,_=self.post();other,ou=self.other();self.comment(post,other)
        self.assertEqual(self.client.post('/api/community/blocks',json={'member_id':ou['id']}).status_code,200)
        self.assertEqual(other.get('/api/community/posts').json()['posts'],[])
        self.assertEqual(other.get('/api/community/posts/'+post['id']).status_code,404)
        self.assertEqual(self.client.get('/api/community/posts/'+post['id']+'/comments').json()['comments'],[])
        self.assertEqual(self.client.get('/api/community/blocks').json()['blocks'][0]['id'],ou['id'])
        self.assertEqual(self.client.request('DELETE','/api/community/blocks/'+ou['id'],json={}).status_code,200)
        self.assertEqual(len(other.get('/api/community/posts').json()['posts']),1)

    def test_report_admin_auth_read_review_and_audit_without_phone(self):
        u,_,_=self.login();post,_=self.post();self.mod.error=True;r,_=self.comment(post)
        self.assertEqual(self.client.get('/api/admin/community').status_code,401)
        self.assertEqual(self.client.post('/api/community/reports',json={'target_type':'post','target_id':post['id'],'reason':'Razón sintética para el equipo.'}).status_code,200)
        dashboard=self.client.get('/api/admin/community',headers=self.admin).json();self.assertEqual(dashboard['summary']['pending'],1);self.assertEqual(dashboard['summary']['reports'],1)
        self.assertNotIn('phone',json.dumps(dashboard))
        path='/api/admin/community/comments/'+r['comment']['id']
        response=self.client.patch(path,json={'action':'approve','reason':'Revisión manual sintética.'},headers=self.admin)
        self.assertEqual(response.status_code,200);self.assertEqual(response.json()['comment']['status'],'approved')
        self.assertEqual(self.client.get('/api/admin/community/posts/'+post['id'],headers=self.admin).json()['post']['body'],post['body'])
        with self.db.connection()as c:events=[dict(e)for e in c.execute('SELECT * FROM audit')]
        self.assertTrue(any(e['action']=='nemy_comment_reviewed'for e in events));self.assertNotIn('Revisión manual',json.dumps(events))

    def test_disable_revokes_sessions_and_admin_can_review_disabled_post(self):
        u,_,_=self.login();post,_=self.post()
        r=self.client.post('/api/admin/community/members/'+u['id']+'/status',json={'disabled':True,'reason':'Estado sintético.'},headers=self.admin)
        self.assertEqual(r.status_code,200);self.assertEqual(self.client.get('/api/community/auth/me').json()['user'],None)
        self.assertEqual(self.client.get('/api/admin/community/posts/'+post['id'],headers=self.admin).status_code,200)

    def test_account_delete_cascades_only_community_and_logout(self):
        u,_,_=self.login();post,_=self.post();self.comment(post)
        self.assertEqual(self.client.request('DELETE','/api/community/profile',json={}).status_code,200)
        self.assertEqual(self.client.get('/api/community/auth/me').json()['user'],None)
        with self.db.connection()as c:
            for table in ('nemy_members','nemy_sessions','nemy_posts','nemy_comments','nemy_otp'):self.assertEqual(c.execute('SELECT count(*) FROM '+table).fetchone()[0],0)
            self.assertEqual(c.execute('SELECT count(*) FROM users').fetchone()[0],0)
        self.login();self.assertEqual(self.client.post('/api/community/auth/logout',json={}).status_code,200)
        self.assertEqual(self.client.get('/api/community/auth/me').json()['user'],None)


class ProviderTests(unittest.IsolatedAsyncioTestCase):
    async def test_structured_provider_request_has_no_storage_and_no_secret_in_failure(self):
        captured=[]
        def handle(req):
            captured.append(json.loads(req.content))
            return httpx.Response(200,json={'status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':json.dumps({'action':'publish','category':'none','reason':''})}]}]})
        async with httpx.AsyncClient(transport=httpx.MockTransport(handle))as client:
            with patch.dict(os.environ,{'OPENAI_API_KEY':'synthetic-unit-key'}):decision=await CommentModerator(client).review('Qué pinche semana','Contexto original')
        self.assertEqual(decision['action'],'publish');self.assertFalse(captured[0]['store']);self.assertTrue(captured[0]['text']['format']['strict'])
        self.assertEqual(captured[0]['max_output_tokens'],600)

    async def test_provider_corruption_refusal_timeout_and_mismatch_fail_closed(self):
        examples=[{'status':'incomplete'}, {'status':'completed','output':[]}, {'status':'completed','output':[{'type':'message','content':[{'type':'output_text','text':'{"action":"publish","category":"hate","reason":""}'}]}]}]
        for envelope in examples:
            async with httpx.AsyncClient(transport=httpx.MockTransport(lambda req:httpx.Response(200,json=envelope)))as client:
                with patch.dict(os.environ,{'OPENAI_API_KEY':'synthetic-unit-key'}):
                    with self.assertRaises(ModerationUnavailable):await CommentModerator(client).review('hola')

    async def test_sender_endpoint_and_uncertain_state_contract(self):
        sender=HttpOtpSender()
        with patch.dict(os.environ,{'NEMY_OTP_SENDER_URL':'http://127.0.0.1:3247','NEMY_OTP_SENDER_TOKEN':'unit-synthetic-token'}):
            response=httpx.Response(409,json={'detail':{'code':'delivery_requires_review'}})
            with patch('community.httpx.AsyncClient')as factory:
                client=factory.return_value.__aenter__.return_value;client.post=AsyncMock(return_value=response)
                with self.assertRaises(OtpDeliveryUncertain):await sender.send(newid(),'+525500001111','1234')
                self.assertEqual(client.post.call_args.args[0],'http://127.0.0.1:3247/otp/send')
                self.assertEqual(client.post.call_args.kwargs['json']['brand'],'Nemy')


if __name__=='__main__':unittest.main(verbosity=2)

