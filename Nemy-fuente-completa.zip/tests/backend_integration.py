"""Behavioral checks for security boundaries, clinical gates and persistence."""
import json
import os
from pathlib import Path
import secrets
import sys
import tempfile
import time
import unittest
import uuid
from datetime import datetime,timezone,timedelta

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
IMPORT_DATA=tempfile.TemporaryDirectory()
os.environ["TRAZA_DATA_DIR"]=IMPORT_DATA.name
os.environ["TRAZA_PUBLIC_ORIGIN"]="https://pilot.test"
os.environ["TRAZA_SECURE_COOKIE"]="1"
from fastapi.testclient import TestClient
from server import create_app,password_hash,now_iso,digest,totp,AUTH_LIMIT,COOKIE
from engine import evaluate,hypotheses,validate_answers,InputError

class BackendTests(unittest.TestCase):
    def setUp(self):
        AUTH_LIMIT.clear()
        self.tmp=tempfile.TemporaryDirectory()
        self.app=create_app(self.tmp.name)
        self.db=self.app.state.db
        self.client=TestClient(self.app,base_url="https://pilot.test",headers={"Origin":"https://pilot.test"})
        self.addCleanup(self.client.close); self.addCleanup(self.tmp.cleanup)
        self.p1=self.user("person_one","participant")
        self.p2=self.user("person_two","participant")
        self.admin=self.user("owner_admin","admin")
        self.clinician=self.user("review_clinician","clinician",profile=True)
        self.unverified=self.user("unverified_clinician","clinician")
        self.configure_ready()

    def user(self,name,role,profile=False):
        uid=uuid.uuid4().hex
        with self.db.connection(transaction=True) as con:
            con.execute("INSERT INTO users(id,username_hash,username_enc,password,role,must_change,mfa_enabled,clinical_profile,created_at) VALUES(?,?,?,?,?,?,?,?,?)",(uid,self.db.username_hash(name),self.db.encrypt(name),password_hash("testing-password-123!"),role,0,role!="participant",self.db.encrypt({"clinical_name":"Test professional","clinical_license":"TEST-123","license_attested":True}) if profile else None,now_iso()))
        return uid
    def as_user(self,uid,verified=True):
        self.client.cookies.clear(); token=secrets.token_urlsafe(32)
        with self.db.connection(transaction=True) as con: con.execute("INSERT INTO sessions VALUES(?,?,?,?,?)",(digest(token),uid,time.time()+3600,int(verified),time.time()))
        self.client.cookies.set(COOKIE,token)
    def configure_ready(self):
        self.as_user(self.admin)
        cfg={"privacy_notice":"Aviso de prueba de tratamiento sensible.","privacy_contact":"test@example.org","clinical_name":"Responsable de prueba","clinical_license":"TEST-123","service_hours":"Horario de prueba","guard_contact":"PRIVATE-GUARD-MARKER","readiness":{k:True for k in ("privacy","clinician","guard","licenses","clinical_validation")},"enrollment_open":True}
        self.assertEqual(self.client.put("/api/admin/config",json=cfg).status_code,200)
    def safe_answers(self):
        return {"consent":{"adult":True,"care":True,"storage":True,"version":"1.0"},"session":{"number":1,"phase":"active","suds_before":2},"S1":"yes","S2":"no","S3":"no","VE1":"mas-1-mes","VE2":["none"],"VE3":"no","VE4":0,"VE5":7,"VE6":8}
    def save(self,answers=None,rev=0):
        return self.client.put("/api/record",json={"answers":answers or self.safe_answers(),"revision":rev})
    def revision(self): return self.client.get("/api/record").json()["revision"]
    def review(self,uid,rev,**extra):
        payload={"action":"approve","patient_summary":"Resumen clínico revisado para la persona.","clinical_notes":"PRIVATE-CLINICAL-NOTES","revision":rev,"interview_completed":True}; payload.update(extra)
        return self.client.post(f"/api/staff/cases/{uid}/review",json=payload)

    def test_role_and_participant_isolation(self):
        self.as_user(self.p1); self.assertEqual(self.save().status_code,200)
        self.assertEqual(self.client.get("/api/staff/cases").status_code,403)
        self.as_user(self.p2); self.assertEqual(self.client.get("/api/record").json()["answers"],{})
        self.assertEqual(self.client.get(f"/api/staff/cases/{self.p1}").status_code,403)
        self.as_user(self.admin); self.assertEqual(self.client.get("/api/staff/cases").status_code,403)
        self.as_user(self.clinician); self.assertEqual(self.client.get(f"/api/staff/cases/{self.p1}").status_code,200)
        self.assertEqual(self.client.get("/api/admin/config").status_code,403)

    def test_consent_readiness_validation_and_disabled_scales(self):
        self.as_user(self.p1)
        self.assertEqual(self.save({"MFC1":2}).status_code,403)
        self.assertEqual(self.save({**self.safe_answers(),"consent":{"adult":False,"care":True,"storage":True,"version":"1.0"}}).status_code,422)
        self.assertEqual(self.save({**self.safe_answers(),"PHQ9_9":1}).status_code,422)
        self.assertEqual(self.save({**self.safe_answers(),"MFC1":True}).status_code,422)
        self.assertEqual(self.save({**self.safe_answers(),"MFC1":99}).status_code,200)
        self.as_user(self.admin)
        self.assertEqual(self.client.put("/api/admin/config",json={"enrollment_open":False}).status_code,200)
        self.as_user(self.p1); self.assertEqual(self.save({"MFC1":3},1).status_code,403)

    def test_revision_conflict_review_gate_and_private_notes(self):
        self.as_user(self.p1); self.assertEqual(self.save().status_code,200)
        self.assertEqual(self.save({"MFC1":2},0).status_code,409)
        self.as_user(self.unverified); self.assertEqual(self.review(self.p1,1).status_code,403)
        self.as_user(self.clinician)
        self.assertEqual(self.review(self.p1,1,interview_completed=False).status_code,422)
        self.assertEqual(self.review(self.p1,1,action="approve-anything").status_code,422)
        response=self.review(self.p1,1); self.assertEqual(response.status_code,200,response.text)
        self.as_user(self.p1)
        record=self.client.get("/api/record").json()
        self.assertEqual(record["review"]["status"],"approved")
        self.assertNotIn("PRIVATE-CLINICAL-NOTES",json.dumps(record))
        self.assertNotIn("hypotheses",record)
        self.assertEqual(self.save({"MFC1":2},2).status_code,200)
        self.assertEqual(self.client.get("/api/record").json()["review"]["status"],"pending")

    def test_persistent_risk_cannot_clear_by_editing_and_real_resolution(self):
        self.as_user(self.p1)
        answers=self.safe_answers(); answers["S3"]="yes"
        self.assertEqual(self.save(answers).status_code,200)
        self.assertEqual(self.save({"MFC1":2},1).status_code,403)
        self.assertEqual(self.save({"S3":"no"},1).status_code,200)
        self.assertEqual(self.save({"MFC1":2},2).status_code,403)
        self.as_user(self.clinician)
        self.assertEqual(self.review(self.p1,2).status_code,409)
        response=self.client.post(f"/api/staff/cases/{self.p1}/alerts/resolve",json={"reason":"evaluacion-presencial","note":"Evaluación clínica y medidas de apoyo documentadas."})
        self.assertEqual(response.status_code,200,response.text)
        self.assertEqual(self.review(self.p1,3).status_code,200)
        self.as_user(self.p1)
        self.assertEqual(self.save({"S3":"yes"},4).status_code,200)
        flags=self.client.get("/api/record").json()["flags"]
        self.assertTrue(any(f["code"]=="current_self_harm" and f["status"]=="open" for f in flags))

    def test_session_spacing_reset_and_trauma_gate(self):
        self.as_user(self.p1); self.assertEqual(self.save().status_code,200)
        self.assertEqual(self.save({"CX1":"yes"},1).status_code,403)
        self.assertEqual(self.save({"session":{"number":1,"phase":"complete","suds_after":2}},1).status_code,200)
        self.assertEqual(self.save({"session":{"number":2,"phase":"active","suds_before":1}},2).status_code,409)
        with self.db.connection(transaction=True) as con:
            r=con.execute("SELECT payload FROM records WHERE user_id=?",(self.p1,)).fetchone(); data=self.db.decrypt(r[0]); data["sessions"][-1]["completed_at"]=(datetime.now(timezone.utc)-timedelta(hours=25)).isoformat()
            con.execute("UPDATE records SET payload=? WHERE user_id=?",(self.db.encrypt(data),self.p1))
        self.assertEqual(self.save({"session":{"number":2,"phase":"active","suds_before":1}},2).status_code,200)
        current=self.client.get("/api/record").json()["answers"]
        self.assertNotIn("S1",current); self.assertNotIn("suds_after",current["session"])
        self.assertEqual(self.save({"CX1":"yes"},3).status_code,403)
        patch=self.safe_answers(); patch.pop("consent"); patch["session"]={"number":2,"phase":"active","suds_before":2}; patch["CX1"]="yes"
        self.assertEqual(self.save(patch,3).status_code,200)

    def test_session_peak_cannot_be_overwritten_to_resume_trauma(self):
        self.as_user(self.p1)
        safe=self.safe_answers()
        safe["session"]={"number":1,"phase":"complete","suds_before":2,"suds_after":2}
        self.assertEqual(self.save(safe).status_code,200)
        with self.db.connection(transaction=True) as con:
            row=con.execute("SELECT payload FROM records WHERE user_id=?",(self.p1,)).fetchone()
            r=self.db.decrypt(row[0]); r["sessions"][-1]["completed_at"]=(datetime.now(timezone.utc)-timedelta(hours=25)).isoformat()
            con.execute("UPDATE records SET payload=? WHERE user_id=?",(self.db.encrypt(r),self.p1))
        second=self.safe_answers(); second["session"]={"number":2,"phase":"active","suds_before":8}
        self.assertEqual(self.save(second,1).status_code,200)
        self.assertEqual(self.save({"session":{"number":2,"phase":"active","suds_before":3}},2).status_code,200)
        self.assertEqual(self.save({"CX1":"no"},3).status_code,403)
        self.assertIn("distress_high",self.client.get("/api/record").json()["progress"]["block_reasons"])
        self.as_user(self.clinician)
        self.assertEqual(self.client.post(f"/api/staff/cases/{self.p1}/alerts/resolve",json={"reason":"apoyo-presencial","note":"Se realizó orientación y apoyo clínico presencial."}).status_code,200)
        self.as_user(self.p1)
        self.assertEqual(self.save({"CX1":"no"},4).status_code,403)
        self.assertEqual(self.save({"session":{"number":2,"phase":"complete","suds_after":2}},4).status_code,200)
        with self.db.connection() as con:
            r=self.db.decrypt(con.execute("SELECT payload FROM records WHERE user_id=?",(self.p1,)).fetchone()[0])
            self.assertEqual(r["sessions"][-1]["peak_suds"],8)

    def test_safety_stop_and_repeated_high_distress(self):
        safe=self.safe_answers()
        for patch,code in (({"VE1":"hoy"},"postpone"),({"VE6":3},"postpone"),({"PS2":2},"psychosis"),({"PS5":"yes"},"psychosis"),({"SR2":99},"suicide_SR2")):
            self.assertTrue(any(f["code"]==code for f in evaluate({**safe,**patch})))
        self.assertFalse(any(f["code"]=="postpone" for f in evaluate({**safe,"VE6":99,"VE5":98})))
        repeated=evaluate({**safe,"session":{"number":2,"suds_before":8,"suds_after":4}},sessions=[{"number":1,"suds_before":8,"suds_after":4}])
        self.assertTrue(any(f["code"]=="specialist_only" for f in repeated))
        once=evaluate({**safe,"session":{"number":1,"suds_before":8,"suds_after":4}},sessions=[{"number":1,"suds_before":8,"suds_after":4}])
        self.assertFalse(any(f["code"]=="specialist_only" for f in once))

    def test_ema_idempotence_three_calendar_days_and_validation(self):
        self.as_user(self.p1); self.assertEqual(self.save().status_code,200)
        def entry(day): return {"id":str(uuid.uuid4()),"date":day,"craving":3,"emotion":"tristeza","intensity":9,"trigger":"recuerdo","context":"casa","sleep":"6-8","used":False,"strategy":"respirar"}
        dates=[(datetime.now(timezone.utc)-timedelta(days=i)).date().isoformat() for i in (2,1,0)]
        first=entry(dates[0]); self.assertEqual(self.client.post("/api/ema",json=first).status_code,200)
        before=self.revision(); self.assertTrue(self.client.post("/api/ema",json=first).json()["idempotent"])
        self.assertEqual(self.revision(),before)
        self.assertEqual(self.client.post("/api/ema",json={**first,"craving":4}).status_code,409)
        for day in dates[1:]: self.assertEqual(self.client.post("/api/ema",json=entry(day)).status_code,200)
        record=self.client.get("/api/record").json()
        self.assertTrue(any(f["code"]=="ema_persistent_distress" for f in record["flags"]))
        bad=entry(dates[0]); bad["emotion"]="PRIVATE NARRATIVE"
        self.assertEqual(self.client.post("/api/ema",json=bad).status_code,422)

    def test_database_encryption_export_and_health_deletion(self):
        self.as_user(self.p1); answers=self.safe_answers(); answers["strengths"]=["espiritualidad"]
        self.assertEqual(self.save(answers).status_code,200)
        exported=self.client.get("/api/export"); self.assertEqual(exported.status_code,200)
        self.assertIn("attachment",exported.headers["content-disposition"])
        for path in Path(self.tmp.name).glob("db.sqlite*"):
            raw=path.read_bytes()
            self.assertNotIn(b"espiritualidad",raw); self.assertNotIn(b"person_one",raw)
        self.assertEqual(self.client.request("DELETE","/api/record",json={}).status_code,200)
        self.assertEqual(self.client.get("/api/record").json()["answers"],{})
        with self.db.connection() as con:
            for table in ("records","record_versions","review_versions"):
                self.assertEqual(con.execute(f"SELECT COUNT(*) FROM {table} WHERE user_id=?",(self.p1,)).fetchone()[0],0)

    def test_mfa_real_enrollment_password_change_and_cookie_security(self):
        # New staff setup must be restricted until both initial password and TOTP complete.
        with self.db.connection(transaction=True) as con:
            con.execute("UPDATE users SET must_change=1,mfa_enabled=0,mfa_secret=NULL WHERE id=?",(self.admin,))
        self.client.cookies.clear()
        response=self.client.post("/api/auth/login",json={"username":"owner_admin","password":"testing-password-123!"})
        self.assertEqual(response.status_code,200)
        cookie=response.headers["set-cookie"]
        for flag in ("HttpOnly","Secure","SameSite=strict"): self.assertIn(flag,cookie)
        self.assertEqual(self.client.get("/api/admin/config").status_code,403)
        self.assertEqual(self.client.post("/api/auth/mfa/setup",json={}).status_code,403)
        self.assertEqual(self.client.post("/api/auth/password",json={"current_password":"testing-password-123!","new_password":"another-testing-pass123!"}).status_code,200)
        setup=self.client.post("/api/auth/mfa/setup",json={}); self.assertEqual(setup.status_code,200)
        secret=setup.json()["secret"]
        self.assertEqual(self.client.post("/api/auth/mfa/verify",json={"code":"invalid"}).status_code,401)
        self.assertEqual(self.client.post("/api/auth/mfa/verify",json={"code":totp(secret)}).status_code,200)
        self.assertEqual(self.client.get("/api/admin/config").status_code,200)
        self.client.post("/api/auth/logout",json={})
        challenge=self.client.post("/api/auth/login",json={"username":"owner_admin","password":"another-testing-pass123!"})
        self.assertTrue(challenge.json()["mfa_required"])
        self.assertEqual(self.client.get("/api/admin/config").status_code,401)
        self.assertEqual(self.client.post("/api/auth/login",json={"username":"owner_admin","password":"another-testing-pass123!","totp":totp(secret)}).status_code,401)

    def test_invitation_single_use_and_clinician_identity_binding(self):
        self.as_user(self.admin)
        invite=self.client.post("/api/admin/invitations",json={"role":"clinician","clinical_name":"Invited professional","clinical_license":"LIC123","license_attested":True})
        self.assertEqual(invite.status_code,200)
        payload={"token":invite.json()["token"],"username":"new_clinician","password":"new-clinician-password!"}
        redeemed=self.client.post("/api/auth/redeem",json=payload); self.assertEqual(redeemed.status_code,200)
        self.assertEqual(redeemed.json()["user"]["clinical_profile"]["clinical_license"],"LIC123")
        self.assertEqual(self.client.get("/api/staff/cases").status_code,403)
        self.assertEqual(self.client.post("/api/auth/redeem",json={**payload,"username":"other_alias"}).status_code,400)
        with self.db.connection() as con:
            row=con.execute("SELECT token_hash FROM invitations").fetchone()
            self.assertNotEqual(row[0],invite.json()["token"])

    def test_public_metadata_redaction_csrf_and_cache(self):
        self.client.cookies.clear()
        response=self.client.get("/api/config")
        self.assertNotIn("PRIVATE-GUARD-MARKER",response.text)
        for instrument in response.json()["instruments"]:
            self.assertNotIn("items",instrument); self.assertNotIn("scoring",instrument)
            if instrument.get("enabled",False):
                self.assertEqual(instrument["status"],"available")
                self.assertTrue(instrument["license_verified"])
                self.assertTrue(instrument["source"].get("url"))
                self.assertFalse(instrument.get("psychometrist_verified",False))
        self.assertIn("no-store",response.headers["cache-control"])
        self.assertEqual(self.client.post("/api/auth/login",json={},headers={"Origin":"https://evil.test"}).status_code,403)
        self.assertEqual(self.client.get("/.env").status_code,404)
        self.as_user(self.admin)
        self.assertNotIn("PRIVATE-GUARD-MARKER",self.client.get("/api/admin/audit").text)

    def test_missing_data_not_zero_or_diagnosis(self):
        result=hypotheses({"MFC1":98,"MFC8":99,"MFC3":3,"MFC-R":"MFC3"})
        self.assertFalse(any(h["function"]=="F1" for h in result))
        self.assertTrue({"F6","F8","F10"} <= {h["function"] for h in result})
        self.assertTrue(all(h["confidence"]=="insuficiente" and "probability" not in h for h in result))
        with self.assertRaises(InputError): validate_answers({"MFC1":None})

if __name__=="__main__": unittest.main(verbosity=2)
