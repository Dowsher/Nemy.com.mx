"""Routing boundaries: Nemy's new entry must preserve TRAZA and private portals."""
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
IMPORT_DATA=tempfile.TemporaryDirectory()
from fastapi.testclient import TestClient
with patch.dict(os.environ,{'TRAZA_DATA_DIR':IMPORT_DATA.name}):
    from server import create_app

class NemyRoutesTests(unittest.TestCase):
    def setUp(self):
        environment=patch.dict(os.environ,{'TRAZA_PUBLIC_ORIGIN':'https://nemy.test','TRAZA_SECURE_COOKIE':'1'})
        environment.start();self.addCleanup(environment.stop)
        self.tmp=tempfile.TemporaryDirectory()
        self.app=create_app(self.tmp.name)
        self.client=TestClient(self.app,base_url='https://nemy.test',headers={'Origin':'https://nemy.test'})
        self.addCleanup(self.client.close);self.addCleanup(self.tmp.cleanup)

    def test_new_topics_and_social_routes_load_the_same_nemy_shell(self):
        for route in ('/emociones','/estancamiento','/mapa','/ayuda','/comunidad','/perfil','/acceso'):
            with self.subTest(route=route):
                response=self.client.get(route)
                self.assertEqual(response.status_code,200)
                self.assertIn('/nemy.js',response.text)
                self.assertIn('href="/traza"',response.text)
                self.assertIn('Cache-Control',response.headers)

    def test_addictions_uses_immersive_source_without_weakening_script_policy(self):
        response=self.client.get('/adicciones')
        self.assertEqual(response.status_code,200)
        self.assertIn('/umbral.js',response.text)
        self.assertIn('/umbral.css',response.text)
        self.assertNotIn('/nemy.js',response.text)
        self.assertIn("script-src 'self'",response.headers['content-security-policy'])
        self.assertNotIn("script-src 'self' 'unsafe-inline'",response.headers['content-security-policy'])
        for path in ('/umbral.js','/umbral.css','/umbral-pizarron.webp'):
            asset=self.client.get(path)
            self.assertEqual(asset.status_code,200)
            self.assertTrue(asset.content)
        self.assertEqual(self.client.get('/umbral-source/index.html').status_code,404)

    def test_generated_photography_is_allowlisted_and_not_a_general_file_server(self):
        for name in ('hero-valle','emociones-ventana','consumo-reflejo','impulso-montana','espejo-emocional','ciclo-alivio','acompanar-conversacion','nuevo-amanecer'):
            for suffix in ('','-mobile'):
                with self.subTest(asset=name+suffix):
                    response=self.client.get('/media/'+name+suffix+'.webp')
                    self.assertEqual(response.status_code,200)
                    self.assertEqual(response.headers['content-type'],'image/webp')
                    self.assertGreater(len(response.content),1000)
        for path in ('/media/server.py','/media/.env','/media/other.webp','/media/../db.sqlite'):
            self.assertEqual(self.client.get(path).status_code,404)

    def test_relapse_video_is_available_for_streaming_and_home_is_opt_in(self):
        page=self.client.get('/')
        self.assertIn('id="video-recaidas"',page.text)
        self.assertIn('preload="none"',page.text)
        self.assertNotIn('autoplay',page.text)
        poster=self.client.get('/media/recaidas-cartel.webp')
        self.assertEqual(poster.status_code,200)
        self.assertEqual(poster.headers['content-type'],'image/webp')
        part=self.client.get('/media/nemy-recaidas.mp4',headers={'Range':'bytes=0-31'})
        self.assertEqual(part.status_code,206)
        self.assertEqual(part.headers['content-type'],'video/mp4')
        self.assertEqual(len(part.content),32)
        self.assertTrue(part.headers['content-range'].startswith('bytes 0-31/'))
        self.assertEqual(self.client.get('/media/other.mp4').status_code,404)

    def test_seo_describes_public_areas_without_private_data(self):
        robots=self.client.get('/robots.txt')
        self.assertEqual(robots.status_code,200)
        self.assertIn('Disallow: /api/',robots.text)
        sitemap=self.client.get('/sitemap.xml')
        self.assertEqual(sitemap.status_code,200)
        self.assertIn('https://nemy.com.mx/mapa',sitemap.text)
        self.assertNotIn('/perfil',sitemap.text)
        self.assertNotIn('/equipo',sitemap.text)

    def test_traza_keeps_its_forms_and_old_exploration_redirects_there(self):
        response=self.client.get('/traza')
        self.assertEqual(response.status_code,200)
        self.assertIn('/journey.js',response.text)
        self.assertIn('href="/">← Nemy',response.text)
        response=self.client.get('/explorar',follow_redirects=False)
        self.assertEqual(response.status_code,307)
        self.assertEqual(response.headers['location'],'/traza')
        schema=self.client.get('/api/journey/schema').json()
        self.assertEqual({r['id']for r in schema['routes']},{'basico','intermedio','completo'})
        self.assertEqual(len([r for r in self.client.get('/api/battery/catalog').json()['instruments']if r['status']=='available']),22)

    def test_admin_shell_contains_no_data_and_both_apis_stay_private(self):
        for route in ('/admin-actividad','/administracion-comunidad'):
            self.assertEqual(self.client.get(route).status_code,200)
        for route in ('/api/admin/activity','/api/admin/community'):
            self.assertEqual(self.client.get(route).status_code,401)
        self.assertEqual(self.client.get('/api/auth/me').status_code,401)

    def test_new_mutations_keep_origin_json_and_private_file_boundaries(self):
        response=self.client.post('/api/community/posts',json={},headers={'Origin':'https://other.test'})
        self.assertEqual(response.status_code,403)
        response=self.client.post('/api/community/posts',content='x',headers={'Content-Type':'text/plain'})
        self.assertEqual(response.status_code,415)
        for path in ('/.env','/community.py','/moderation.py','/db.sqlite','/data.key','/community.env'):
            self.assertEqual(self.client.get(path).status_code,404)

if __name__=='__main__':unittest.main()
