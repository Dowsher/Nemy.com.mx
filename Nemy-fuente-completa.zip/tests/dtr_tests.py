"""Anonymous end-to-end isolation, lifecycle, safety and actual engine/PDF checks."""
import copy,json,os,sys,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
IMPORT_DIR=tempfile.TemporaryDirectory()
from fastapi.testclient import TestClient
with patch.dict(os.environ,{'TRAZA_DATA_DIR':IMPORT_DIR.name}):
    from server import create_app
from dtr_api import validate,TTL,COOKIE,SCHEMA,MEDICAL

def fixture(complete=True):
    profile={f['key']:f['default'] if complete else None for f in SCHEMA['fields'] if f['key']!='id'}
    profile.update(edad=32,dias_uso_ultimos_30=16,anios_uso=3,dias_abstinencia_actual=0,craving_eva=5,etapa_cambio='preparacion',horas_disponibles_semana=6,presupuesto_semanal_mxn=800,riesgo_suicida='ninguno',psicosis_actual=False,sintomas_cardiacos_agudos=False,rechaza_medicacion=True)
    return {'perfil':profile,'contexto':{},'mode':'quick','consent':True,'understood':True,'scope_confirmed':True}

class DTRTests(unittest.TestCase):
    def setUp(self):
        env=patch.dict(os.environ,{'TRAZA_PUBLIC_ORIGIN':'https://nemy.test','TRAZA_SECURE_COOKIE':'1'})
        env.start();self.addCleanup(env.stop)
        self.tmp=tempfile.TemporaryDirectory();self.app=create_app(self.tmp.name);self.db=self.app.state.db
        self.client=TestClient(self.app,base_url='https://nemy.test',headers={'Origin':'https://nemy.test'})
        self.client.__enter__();self.addCleanup(self.tmp.cleanup);self.addCleanup(self.client.__exit__,None,None,None)
        self.data=fixture()
    def start(self,data=None):return self.client.post('/api/dtr/jobs',json=data or self.data)
    def wait(self,key):
        end=time.monotonic()+120
        while time.monotonic()<end:
            response=self.client.get('/api/dtr/jobs/'+key);self.assertEqual(response.status_code,200,response.text[:250]);data=response.json()
            if data['status']!='running':return data
            time.sleep(.1)
        self.fail('Worker timed out')
    def test_public_pages_schema_and_no_demo(self):
        for path in ['/','/mi-recuperacion','/acompanar','/dtr-ga','/privacidad','/nemy-life.css','/nemy-neon.css','/nemy-neon.js','/dtr.js']:
            r=self.client.get(path);self.assertEqual(r.status_code,200,path);self.assertIn("script-src 'self'",r.headers['content-security-policy'])
        schema=self.client.get('/api/dtr/schema');self.assertEqual(schema.status_code,200);self.assertEqual(len(schema.json()['fields']),67)
        self.assertNotIn('set-cookie',schema.headers)
        html=self.client.get('/dtr-ga').text
        self.assertIn('Comenzar sin cuenta',html);self.assertNotIn('show-demo',html);self.assertNotIn('professional-login',html)
        for path in ['/api/dtr/demo','/dtr-demo.json','/dtr-demo-input.json','/dtr_worker.py','/dtr-schema.json','/dtr_ga/dtr_base.py']:
            self.assertEqual(self.client.get(path).status_code,404,path)
    def test_consent_origin_and_types(self):
        self.assertEqual(self.client.post('/api/dtr/jobs',json=self.data,headers={'Origin':'https://other.test'}).status_code,403)
        self.assertEqual(self.client.post('/api/dtr/jobs',content='{}',headers={'Content-Type':'text/plain'}).status_code,415)
        for key in ('consent','understood','scope_confirmed'):
            d=copy.deepcopy(self.data);d[key]=False;self.assertEqual(self.start(d).status_code,422)
    def test_strict_inputs_and_no_override(self):
        for key,value in [('edad',17),('edad',None),('edad',22.7),('edad',True),('edad','35'),('dias_uso_ultimos_30',31),('psicosis_actual','false'),('sexo',['M'])]:
            d=copy.deepcopy(self.data);d['perfil'][key]=value;self.assertEqual(self.start(d).status_code,422,(key,value))
        for key in ['id','name','phone']:
            d=copy.deepcopy(self.data);d['perfil'][key]='unwanted';self.assertEqual(self.start(d).status_code,422)
        d=copy.deepcopy(self.data);del d['perfil']['psicosis_actual'];self.assertEqual(self.start(d).status_code,422)
        for key in ['ignorar_interlock','investigacion','salida','semilla','generaciones','professional_review']:
            d=copy.deepcopy(self.data);d[key]=True;self.assertEqual(self.start(d).status_code,422,key)
    def test_context_limits(self):
        for ctx in [{'disponibles':{'bad':True}},{'disponibles':{'bup':'yes'}},{'niveles_no_disponibles':{'bup':[99]}},{'costos_mxn':{'cm':[0,-1,10]}},{'costos_mxn':{'cm':[0]}},{'max_farmacos':False},{'max_farmacos':99},{'r2_perfil':2}]:
            d=copy.deepcopy(self.data);d['contexto']=ctx;self.assertEqual(self.start(d).status_code,422,ctx)
        d=copy.deepcopy(self.data);d['perfil']['anios_uso']=float('nan')
        with self.assertRaises(Exception):validate(d)
    def test_each_urgent_flag_stops_and_pdf_works(self):
        for key,value in [('riesgo_suicida','alto'),('psicosis_actual',True),('sintomas_cardiacos_agudos',True)]:
            d=fixture(False);d['perfil'][key]=value;started=self.start(d);self.assertEqual(started.status_code,202,started.text)
            job=started.json()['id'];result=self.wait(job);self.assertEqual(result['status'],'interlock');self.assertNotIn('report',result)
            pdf=self.client.get('/api/dtr/jobs/'+job+'/pdf');self.assertEqual(pdf.status_code,200,pdf.text[:100] if pdf.status_code!=200 else '')
            self.assertTrue(pdf.content.startswith(b'%PDF-'));self.assertIn('no-store',pdf.headers['cache-control'])
            self.assertEqual(self.client.request('DELETE','/api/dtr/jobs/'+job,json={}).status_code,200)
    def test_unknown_safety_does_not_become_negative(self):
        d=fixture(False);d['perfil']['psicosis_actual']=None;job=self.start(d).json()['id'];r=self.wait(job)
        self.assertEqual(r['status'],'needs_review');self.assertNotIn('report',r)
    def test_moderate_self_harm_signal_stops(self):
        d=fixture(False);d['perfil']['riesgo_suicida']='moderado';r=self.wait(self.start(d).json()['id']);self.assertEqual(r['status'],'interlock')
    def test_urgent_capture_can_skip_remaining_questions(self):
        d=fixture(False)
        for k in d['perfil']:d['perfil'][k]=None
        d['perfil'].update(edad=25,riesgo_suicida='alto',psicosis_actual=False,sintomas_cardiacos_agudos=False)
        self.assertEqual(self.wait(self.start(d).json()['id'])['status'],'interlock')
    def test_unknown_history_excludes_medical_and_is_visible(self):
        d=fixture(False);d['contexto']={'disponibles':{k:True for k in MEDICAL},'max_farmacos':3}
        validated=validate(d);self.assertTrue(validated['unknown']);self.assertEqual(validated['contexto']['max_farmacos'],0)
        self.assertTrue(all(validated['contexto']['disponibles'][k] is False for k in MEDICAL))
        r=self.wait(self.start(d).json()['id']);self.assertEqual(r['status'],'completed',r)
        self.assertTrue(r['assumptions']);self.assertIsNone(r['report']['perfil']['antecedente_convulsiones'])
        for p in r['report']['regimen_recomendado']:self.assertFalse(set(p['componentes'])&MEDICAL)
    def test_real_motor_anonymous_isolation_and_pdf(self):
        before={}
        with self.db.connection() as con:
            for table in ('users','records'):before[table]=con.execute('SELECT count(*) FROM '+table).fetchone()[0]
        started=self.start();self.assertEqual(started.status_code,202,started.text);job=started.json()['id']
        cookie=started.headers['set-cookie'];self.assertIn('HttpOnly',cookie);self.assertIn('Secure',cookie);self.assertIn('SameSite=strict',cookie);self.assertIn('Path=/api/dtr',cookie)
        token=self.client.cookies.get(COOKIE);self.client.cookies.clear()
        for path in ['/api/dtr/jobs/'+job,'/api/dtr/jobs/'+job+'/pdf']:self.assertEqual(self.client.get(path).status_code,404)
        self.assertEqual(self.client.request('DELETE','/api/dtr/jobs/'+job,json={}).status_code,404)
        self.client.cookies.set(COOKIE,token,domain='nemy.test',path='/api/dtr')
        self.assertEqual(self.start().status_code,429);self.assertEqual(self.client.get('/api/dtr/jobs/'+job+'/pdf').status_code,409)
        self.assertEqual(self.client.get('/api/health').status_code,200)
        r=self.wait(job);self.assertEqual(r['status'],'completed',r);self.assertEqual(len(r['report']['curva_semanal_recomendado']),36)
        self.assertTrue(r['report']['configuracion']['rapido']);self.assertFalse(r['report']['configuracion']['ignorar_interlock']);self.assertNotIn('owner',r)
        pdf=self.client.get('/api/dtr/jobs/'+job+'/pdf');self.assertEqual(pdf.status_code,200);self.assertGreater(len(pdf.content),10000)
        with self.db.connection() as con:
            for table,n in before.items():self.assertEqual(con.execute('SELECT count(*) FROM '+table).fetchone()[0],n)
        self.assertNotIn('pdf',self.client.get('/api/dtr/jobs/'+job).json())
        self.assertEqual(self.client.request('DELETE','/api/dtr/jobs/'+job,json={}).status_code,200)
        self.assertEqual(self.client.get('/api/dtr/jobs/'+job+'/pdf').status_code,404)
    def test_expiration_and_cancel(self):
        job=self.start().json()['id'];self.assertEqual(self.client.request('DELETE','/api/dtr/jobs/'+job,json={}).status_code,200)
        self.assertFalse(self.app.state.dtr_jobs)
        self.data['perfil']['psicosis_actual']=True;job=self.start().json()['id'];self.wait(job)
        self.app.state.dtr_jobs[job]['finished']-=TTL+1;self.assertEqual(self.client.get('/api/dtr/jobs/'+job).status_code,404)
    def test_network_quota_survives_clearing_cookie(self):
        self.data['perfil']['psicosis_actual']=True
        for _ in range(3):
            self.client.cookies.clear();r=self.start();self.assertEqual(r.status_code,202);self.wait(r.json()['id'])
        self.client.cookies.clear();self.assertEqual(self.start().status_code,429)
    def test_complete_mode_original_engine(self):
        self.data['mode']='complete';r=self.wait(self.start().json()['id']);self.assertEqual(r['status'],'completed',r)
        self.assertFalse(r['report']['configuracion']['rapido']);self.assertEqual(r['report']['configuracion']['generaciones'],120)
        self.assertEqual(r['report']['configuracion']['poblacion'],96);self.assertIn('robustez',r['report']);self.assertTrue(r['report']['ablacion'])

if __name__=='__main__':unittest.main(verbosity=2)
