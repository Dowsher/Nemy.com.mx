"""Synthetic journey checks. No real provider, credential files or patient data."""
import asyncio
from copy import deepcopy
import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch
import uuid

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import battery
from db import Database
import exploration
import journey as j


def sample_payload(route="basico", full=False):
    forms = j._forms()
    context = {"S1": 1, "S2": 2, "S3": 0, **{f"E{i}": 0 for i in range(1, 11)}, "E2": 1, "EC": 2}
    payload = {"version": "4.0", "route_id": route, "request_id": str(uuid.uuid4()),
               "consent": {"adult": True, "processing": True, "ai": True, "version": "4.0"},
               "context_answers": context, "forms": {}, "safety_state": {"current_risk": False, "unsafe": False}}
    for ident in j.expected_forms(route, context) if full else ["PHQ9", "GAD7"]:
        form = forms[ident]
        answers = {}
        for q in battery.form_items(form):
            if not battery.visible(q, answers):
                continue
            if q.get("type") == "text":
                continue
            if q.get("type") == "number":
                value = q.get("min", 0)
            else:
                value = q["options"][0]["value"]
                if q.get("multiple"):
                    value = [value]
            answers[q["id"]] = value
        if ident == "PHQ9":
            answers["PHQ9_1"] = 2
        payload["forms"][ident] = {"version": form.get("version", "1.0"), "answers": answers}
    return payload


def sample_analysis(clean=None):
    clean = clean or j.validate_payload(sample_payload())
    facts, events, reactions = j.evidence_for(clean)
    ids = [facts[0]["id"]]
    patterns = []
    if events and reactions:
        primary_events = events - {"PCPTSD5:PCPTSD5_EXPOSURE"} or events
        patterns = [{"title": "Experiencias reconocidas y bienestar actual",
            "explanation": "Las respuestas permiten explorar si hay una relación entre las experiencias reconocidas y las reacciones actuales.",
            "evidence_ids": [sorted(primary_events)[0], sorted(reactions)[0]],
            "uncertainty": "La coexistencia de estas respuestas no demuestra una relación ni explica su origen.",
            "professional_work": "Revisar en entrevista el contexto de las respuestas y qué significado tienen para la persona."}]
    return {"summary": "El registro organiza las respuestas disponibles y señala aspectos que pueden conversarse en consulta.",
        "profile": {"description": "El perfil describe el funcionamiento reportado y conserva las áreas sin información.",
                    "emotional_patterns": "Las respuestas de los cuestionarios ofrecen referencias para explorar emociones.",
                    "daily_impact": "Conviene precisar el impacto cotidiano en una entrevista individual.",
                    "resources": "Los apoyos se describen sólo cuando aparecen seleccionados; faltan detalles para ampliarlos.", "evidence_ids": ids},
        "patterns": patterns, "next_steps": ["Lleva este registro a una consulta para contrastarlo con tu experiencia."],
        "questions_for_professional": ["¿Qué aspectos del registro conviene explorar primero en una entrevista?"],
        "professional": {"synthesis": "Síntesis de autorreporte generada por IA para revisión profesional, con cobertura limitada a las respuestas disponibles.",
                         "hypotheses": "Explorar de manera condicional las reacciones reportadas, sin establecer un diagnóstico.",
                         "differential": "La entrevista puede valorar distintas explicaciones del malestar y su contexto.",
                         "priorities": "Contrastar frecuencias, períodos y funcionamiento antes de formular conclusiones.",
                         "limitations": "No hay entrevista, evaluación clínica ni inferencia causal. Los campos libres no se usaron en esta síntesis."}}


def sample_report(route="basico", full=False):
    clean = j.validate_payload(sample_payload(route, full))
    return j.build_report(clean, sample_analysis(clean))


def to_wire(analysis):
    result = deepcopy(analysis)
    for pattern in result["patterns"]:
        ids = pattern.pop("evidence_ids")
        pattern.pop("title")
        pattern["event_evidence_id"] = ids[0]
        pattern["reaction_evidence_ids"] = ids[1:]
    return result


def provider_envelope(analysis):
    return {"id": "resp_synthetic", "status": "completed", "output": [{"type": "message", "content": [{"type": "output_text", "text": json.dumps(to_wire(analysis), ensure_ascii=False)}]}]}


class PayloadTests(unittest.TestCase):
    def assert_code(self, code, function, *args):
        with self.assertRaises(j.JourneyError) as ctx:
            function(*args)
        self.assertEqual(ctx.exception.code, code)

    def test_routes_and_available_forms_are_exact(self):
        schema = j.get_schema()
        self.assertEqual(schema["version"], "4.0")
        self.assertEqual([r["id"] for r in schema["routes"]], ["basico", "intermedio", "completo"])
        self.assertEqual([len(r["form_ids"]) for r in schema["routes"]], [4, 6, 11])
        self.assertEqual(len(schema["context_questions"]), 18)
        available = j._forms()
        for route in schema["routes"]:
            self.assertTrue(set(route["form_ids"]) <= set(available))
        self.assertNotIn("SDS", j.expected_forms("completo", {}))
        self.assertNotIn("DESII", j.expected_forms("completo", {}))

    def test_consent_version_and_root_fields_are_enforced(self):
        for field in ("adult", "processing", "ai", "version"):
            p = sample_payload(); p["consent"][field] = False
            self.assert_code("consent_required", j.validate_payload, p)
        p = sample_payload(); p["version"] = "3.0"
        self.assert_code("version_conflict", j.validate_payload, p)
        p = sample_payload(); p["total"] = 0
        self.assert_code("invalid_payload", j.validate_payload, p)
        p = sample_payload(); p["request_id"] = "fake"
        self.assert_code("invalid_request_id", j.validate_payload, p)

    def test_context_has_no_coercion_and_does_not_accept_identity_or_out_of_route_use(self):
        for field, value in (("E1", True), ("E1", "1"), ("E1", 1.0), ("E1", 2), ("name", 1), ("USE_ALCOHOL", 1)):
            p = sample_payload(); p["context_answers"][field] = value
            self.assert_code("invalid_context", j.validate_payload, p)

    def test_conditions_do_not_activate_on_unknown_or_omitted_context(self):
        expected = j.expected_forms("completo", {"USE_ALCOHOL": 98, "USE_COCAINE": 99})
        self.assertEqual(len(expected), 11)
        expected = j.expected_forms("completo", {"INCLUDE_SUBSTANCES": 1, "USE_COCAINE": 1})
        self.assertEqual(expected[-2:], ["SOCRATES", "CCQBRIEF"])
        self.assertNotIn("SOCRATES8A", expected)
        expected = j.expected_forms("completo", {"INCLUDE_SUBSTANCES": 1, "USE_ALCOHOL": 1})
        self.assertIn("SOCRATES8A", expected); self.assertNotIn("SOCRATES", expected)
        p = sample_payload(); p["context_answers"].update({f"E{i}": 0 for i in range(1, 11)})
        self.assertNotIn("EC", j.validate_payload(p)["context_answers"])

    def test_substance_opt_out_prunes_stale_selections_and_rejects_forms(self):
        p = sample_payload("completo")
        p["context_answers"].update(INCLUDE_SUBSTANCES=0, USE_COCAINE=1, USE_ALCOHOL=1)
        clean = j.validate_payload(p)
        self.assertNotIn("USE_COCAINE", clean["context_answers"])
        self.assertNotIn("SOCRATES", clean["expected_form_ids"])
        f = j._forms()["CCQBRIEF"]
        p["forms"]["CCQBRIEF"] = {"version": f["version"], "answers": {}}
        self.assert_code("invalid_forms", j.validate_payload, p)
        self.assertEqual(len(j.expected_forms("completo", {"USE_COCAINE": 1})), 11)

    def test_form_route_version_and_client_scores_cannot_be_fabricated(self):
        p = sample_payload(); p["forms"]["PHQ9"]["version"] = "old"
        self.assert_code("form_version_conflict", j.validate_payload, p)
        p = sample_payload(); p["forms"]["PHQ9"]["total"] = 0
        self.assert_code("invalid_form", j.validate_payload, p)
        p = sample_payload(); p["forms"]["LEC5"] = {"version": "anything", "answers": {}}
        self.assert_code("invalid_forms", j.validate_payload, p)
        clean = j.validate_payload(sample_payload())
        self.assertEqual(next(s for s in clean["scores"] if s["id"] == "PHQ9")["total"], 2)

    def test_safety_positives_block_but_distress_unknown_and_phq9_do_not_invent_urgency(self):
        for key, value in (("S1", 0), ("S3", 1)):
            p = sample_payload(); p["context_answers"][key] = value
            self.assert_code("safety_blocked", j.validate_payload, p)
        for key in ("unsafe", "current_risk"):
            p = sample_payload(); p["safety_state"][key] = True
            self.assert_code("safety_blocked", j.validate_payload, p)
        p = sample_payload(); p["context_answers"].update(S1=99, S2=10, S3=98)
        p["forms"]["PHQ9"]["answers"]["PHQ9_9"] = 1
        c = j.validate_payload(p); r = j.build_report(c, sample_analysis(c))
        self.assertIn("incertidumbre", r["safety_note"]); self.assertIn("malestar alto", r["safety_note"])
        self.assertIn("por sí sola no determina urgencia", r["safety_note"])

    def test_minimum_information_before_provider_accepts_complete_scale_without_exposure_disclosure(self):
        p = sample_payload(); p["forms"] = {}
        self.assert_code("insufficient_data", j.validate_payload, p)
        p = sample_payload(); p["forms"] = {"PHQ9": {"version": j._forms()["PHQ9"]["version"], "answers": {"PHQ9_1": 1, "PHQ9_2": 98, "PHQ9_3": 99}}}
        self.assert_code("insufficient_data", j.validate_payload, p)
        p = sample_payload(); p["context_answers"] = {"S1": 99, "S3": 99}
        clean = j.validate_payload(p)
        self.assertEqual(j.output_schema(clean)["properties"]["patterns"]["maxItems"], 0)
        self.assertEqual(sample_analysis(clean)["patterns"], [])

    def test_omitted_and_partial_forms_remain_distinct_and_missing_is_not_zero(self):
        p = sample_payload(); p["forms"]["PHQ9"]["answers"]["PHQ9_2"] = 98
        c = j.validate_payload(p); r = j.build_report(c, sample_analysis(c))
        self.assertEqual(r["coverage"]["completed_form_ids"], ["GAD7"])
        self.assertEqual(r["coverage"]["incomplete_form_ids"], ["PHQ9"])
        self.assertEqual(r["coverage"]["omitted_form_ids"], ["PCPTSD5", "APOYOS"])
        self.assertIsNone(next(s for s in r["scores"] if s["id"] == "PHQ9")["total"])
        self.assertNotIn("PHQ9:PHQ9_2", {e["id"] for e in r["evidence"]})

    def test_lec_narrative_is_retained_only_for_person_and_never_in_model_trace(self):
        p = sample_payload("completo", True)
        marker = "MARCADOR_PRIVADO_SINTETICO_NO_ENVIAR_IA"
        p["forms"]["LEC5"]["answers"]["LEC5_P2_1"] = marker
        c = j.validate_payload(p)
        request = j.provider_request(c)
        trace = json.dumps(request, ensure_ascii=False)
        self.assertNotIn(marker, trace)
        provider_data = json.loads(request["input"][1]["content"][0]["text"])
        self.assertFalse(any(f["id"] in {"context:S1", "context:S2", "context:S3"} for f in provider_data["facts"]))
        self.assertFalse(any(f["id"].endswith("LEC5_P2_1") for f in provider_data["facts"]))
        self.assertNotIn("answers", provider_data["scores"][0])
        self.assertIn("instructions", provider_data["scores"][0])
        self.assertIn(marker, json.dumps(j.build_report(c, sample_analysis(c)), ensure_ascii=False))

    def test_strict_provider_shape_store_false_and_evidence_enums(self):
        c = j.validate_payload(sample_payload()); request = j.provider_request(c)
        self.assertFalse(request["store"]); self.assertNotIn("tools", request)
        self.assertNotIn("conversation", request); self.assertNotIn("previous_response_id", request)
        self.assertTrue(request["text"]["format"]["strict"])
        self.assertFalse(request["text"]["format"]["schema"]["additionalProperties"])
        self.assertLessEqual(request["max_output_tokens"], 9000)

    def test_provider_pattern_requires_separate_event_and_reaction_and_server_builds_title(self):
        c = j.validate_payload(sample_payload()); schema = j.provider_output_schema(c)
        props = schema["properties"]["patterns"]["items"]["properties"]
        self.assertNotIn("title", props); self.assertNotIn("evidence_ids", props)
        self.assertEqual(props["event_evidence_id"]["enum"], ["context:E2"])
        self.assertEqual(props["reaction_evidence_ids"]["minItems"], 1)
        wire = to_wire(sample_analysis(c)); output = j.normalize_provider_analysis(wire, c)
        self.assertEqual(output["patterns"][0]["title"], "Posible huella de humillación, desvalorización o control")
        self.assertEqual(output["patterns"][0]["evidence_ids"], ["context:E2", "PHQ9:PHQ9_1"])
        for mutation in (lambda p: p.update(event_evidence_id="PHQ9:PHQ9_1"),
                         lambda p: p.update(reaction_evidence_ids=[]),
                         lambda p: p.update(reaction_evidence_ids=["GAD7:GAD7_1"])):
            invalid = deepcopy(wire); mutation(invalid["patterns"][0])
            self.assert_code("ai_invalid_response", j.normalize_provider_analysis, invalid, c)

    def test_generic_exposure_gate_does_not_add_another_trauma_or_repeat_one_event(self):
        c = j.validate_payload(sample_payload("intermedio", True))
        _, events, _ = j.evidence_for(c)
        self.assertIn("PCPTSD5:PCPTSD5_EXPOSURE", events)
        schema = j.provider_output_schema(c)
        self.assertEqual(schema["properties"]["patterns"]["maxItems"], 1)
        self.assertEqual(schema["properties"]["patterns"]["items"]["properties"]["event_evidence_id"]["enum"], ["context:E2"])
        wire = to_wire(sample_analysis(c))
        wire["patterns"].append(deepcopy(wire["patterns"][0]))
        self.assert_code("ai_invalid_response", j.normalize_provider_analysis, wire, c)

    def test_known_provider_language_mix_is_translated_without_inventing_clinical_content(self):
        c = j.validate_payload(sample_payload())
        wire = to_wire(sample_analysis(c))
        wire["professional"]["differential"] = "Estas experiencias merecen уточación clínica; faltan datos para concluir."
        result = j.normalize_provider_analysis(wire, c)
        self.assertEqual(result["professional"]["differential"], "Estas experiencias merecen aclaración clínica; faltan datos para concluir.")
        wire["professional"]["differential"] = "La respuesta añade непроверено dentro del texto clínico."
        self.assert_code("ai_invalid_response", j.normalize_provider_analysis, wire, c)

    def test_conditional_professional_event_inquiry_is_allowed_but_personal_narrowing_is_not(self):
        p = sample_payload(); p["context_answers"].update(E2=0, E7=1)
        c = j.validate_payload(p); wire = to_wire(sample_analysis(c))
        wire["patterns"][0]["professional_work"] = "Explorar cronología, significado subjetivo de la pérdida y posibles explicaciones, sin asumir cuál alternativa ocurrió."
        wire["professional"]["differential"] = "Podría explorarse si hay duelo u otras reacciones, sin afirmar que haya ocurrido una pérdida específica."
        self.assertEqual(j.normalize_provider_analysis(wire, c)["patterns"][0]["title"], "Posible huella de pérdida, separación o abandono")
        wire["profile"]["description"] = "Tus respuestas muestran que has vivido abandono y que eso forma parte de tu historia."
        self.assert_code("ai_invalid_response", j.normalize_provider_analysis, wire, c)

    def test_patterns_require_visible_affirmative_event_and_reaction_ids(self):
        c = j.validate_payload(sample_payload())
        for ids in (["context:E2"], ["context:E2", "GAD7:GAD7_1"], ["context:E1", "PHQ9:PHQ9_1"], ["context:E2", "NOPE"]):
            a = sample_analysis(c); a["patterns"][0]["evidence_ids"] = ids
            self.assert_code("ai_invalid_response", j.validate_analysis, a, c)
        p = sample_payload(); p["context_answers"].update({f"E{i}": 0 for i in range(1, 11)})
        c = j.validate_payload(p); a = sample_analysis(c)
        self.assertEqual(a["patterns"], []); self.assertEqual(j.validate_analysis(a, c), a)

    def test_attention_symptoms_alone_do_not_link_a_reported_event_to_traumatic_reactions(self):
        p = sample_payload("completo", True)
        for ident in ("PHQ9", "GAD7", "PCPTSD5", "ITQ", "DEST"):
            for key, value in p["forms"][ident]["answers"].items():
                if type(value) is int:
                    p["forms"][ident]["answers"][key] = 0
        p["forms"]["ASRS6"]["answers"] = {f"ASRS6_{i}": 4 for i in range(1, 7)}
        p["forms"]["LEC5"]["answers"] = {f"LEC5_{i}": [6] for i in range(1, 18)}
        c = j.validate_payload(p)
        facts, events, reactions = j.evidence_for(c)
        self.assertTrue(events); self.assertFalse(reactions)
        self.assertTrue(any(f["id"].startswith("ASRS6:") for f in facts))
        self.assertEqual(j.output_schema(c)["properties"]["patterns"]["maxItems"], 0)

    def test_event_guard_allows_symptom_terms_without_inventing_an_event(self):
        c = j.validate_payload(sample_payload()); a = sample_analysis(c)
        a["profile"]["emotional_patterns"] = "La respuesta sobre pérdida de interés merece precisarse en entrevista."
        a["professional"]["differential"] = "Explorar de manera condicional temor al rechazo si aparece al ampliar la entrevista."
        self.assertEqual(j.validate_analysis(a, c), a)

    def test_missing_support_cannot_become_factual_friends_but_proposals_remain_possible(self):
        c = j.validate_payload(sample_payload()); a = sample_analysis(c)
        a["profile"]["resources"] = "Cuentas con amigos que te ayudan a diario."
        self.assert_code("ai_invalid_response", j.validate_analysis, a, c)
        for proposal in ("Podrías buscar una persona de confianza y averiguar qué apoyo necesitas.",
                         "No se conocen tus apoyos actuales; conviene explorar si tienes amigos con quienes hablar.",
                         "¿Tienes amigos o familiares que te apoyen? Conviene preguntarlo en consulta."):
            a = sample_analysis(c); a["profile"]["resources"] = proposal
            self.assertEqual(j.validate_analysis(a, c), a)

    def test_a_trusted_person_does_not_identify_friends_or_family(self):
        p = sample_payload(); form = j._forms()["APOYOS"]
        p["forms"]["APOYOS"] = {"version": form["version"], "answers": {"strengths": ["persona"], "readiness": 6}}
        c = j.validate_payload(p); a = sample_analysis(c)
        a["profile"]["resources"] = "Cuentas con una persona de confianza que reconoces como apoyo."
        self.assertEqual(j.validate_analysis(a, c), a)
        for false_claim in ("Cuentas con amigos que te escuchan.", "Tienes apoyo familiar para continuar."):
            a = sample_analysis(c); a["profile"]["resources"] = false_claim
            self.assert_code("ai_invalid_response", j.validate_analysis, a, c)

    def test_sleep_zero_cannot_become_affirmed_sleep_symptoms_or_nightly_frequency(self):
        c = j.validate_payload(sample_payload()); a = sample_analysis(c)
        a["patterns"][0]["explanation"] = "Reportas alteración del sueño todas las noches. Vale la pena explorar si hay relación."
        self.assert_code("ai_invalid_response", j.validate_analysis, a, c)
        a["patterns"][0]["explanation"] = "Conviene explorar si hay alteración del sueño. No se conoce ese aspecto con detalle."
        self.assertEqual(j.validate_analysis(a, c), a)
        a["questions_for_professional"] = ["¿Te cuesta dormir y qué convendría explorar sobre tu descanso?"]
        self.assertEqual(j.validate_analysis(a, c), a)

    def test_combined_phq_sleep_does_not_specify_insomnia_and_pc_does_not_specify_nightmares(self):
        p = sample_payload(); p["forms"]["PHQ9"]["answers"]["PHQ9_3"] = 1
        c = j.validate_payload(p); a = sample_analysis(c)
        a["profile"]["emotional_patterns"] = "Señalas alteración del sueño en el reactivo combinado, junto con otras respuestas."
        self.assertEqual(j.validate_analysis(a, c), a)
        a["profile"]["emotional_patterns"] = "Reportas insomnio durante las últimas dos semanas."
        self.assert_code("ai_invalid_response", j.validate_analysis, a, c)
        p["forms"]["PHQ9"]["answers"]["PHQ9_3"] = 3
        c = j.validate_payload(p); a = sample_analysis(c)
        a["profile"]["emotional_patterns"] = "Señalas alteración del sueño casi todos los días en las últimas dos semanas."
        self.assertEqual(j.validate_analysis(a, c), a)
        pc = j._forms()["PCPTSD5"]
        p["forms"]["PCPTSD5"] = {"version": pc["version"], "answers": {"PCPTSD5_EXPOSURE": 1, **{f"PCPTSD5_{i}": 1 if i == 1 else 0 for i in range(1,6)}}}
        c = j.validate_payload(p); a = sample_analysis(c)
        a["profile"]["emotional_patterns"] = "Señalas pesadillas o pensamientos no deseados en la pregunta combinada."
        self.assertEqual(j.validate_analysis(a, c), a)
        a["profile"]["emotional_patterns"] = "Señalas pesadillas durante el último mes."
        self.assert_code("ai_invalid_response", j.validate_analysis, a, c)

    def test_unfinished_foreign_alphabet_or_inline_ids_are_not_publishable_prose(self):
        c = j.validate_payload(sample_payload())
        for bad in ("Tu perfil tiene malestar en ", "Conviene уточar tus apoyos actuales.", "Tu respuesta (context:E2) merece explorarse en consulta."):
            a = sample_analysis(c); a["profile"]["description"] = bad
            self.assert_code("ai_invalid_response", j.validate_analysis, a, c)

    def test_des_t_frequency_is_not_a_dissociation_severity_band(self):
        c = j.validate_payload(sample_payload("completo", True)); a = sample_analysis(c)
        for false_band in ("Conviene explorar síntomas disociativos leves y su contexto.",
                           "Podría tratarse de disociación moderada sin diagnóstico confirmado."):
            a["professional"]["hypotheses"] = false_band
            self.assert_code("ai_invalid_response", j.validate_analysis, a, c)

    def test_neutral_reassurance_item_cannot_become_high_need_but_inquiry_is_allowed(self):
        p = sample_payload("completo", True); p["forms"]["ECR12CL"]["answers"]["ECR12CL_7"] = 4
        c = j.validate_payload(p); a = sample_analysis(c)
        a["patterns"][0]["explanation"] = "Vale la pena explorar si esa experiencia se relaciona con necesidad de mucha reafirmación en los vínculos."
        self.assert_code("ai_invalid_response", j.validate_analysis, a, c)
        a = sample_analysis(c); a["profile"]["emotional_patterns"] = "Refieres una necesidad elevada de reafirmación en tus relaciones actuales."
        self.assert_code("ai_invalid_response", j.validate_analysis, a, c)
        a = sample_analysis(c)
        a["professional"]["hypotheses"] = "Conviene explorar si existe una necesidad elevada de reafirmación, sin asumir que el punto medio indique acuerdo."
        a["questions_for_professional"] = ["¿Tienes una necesidad elevada de reafirmación y qué habría que precisar al respecto?"]
        self.assertEqual(j.validate_analysis(a, c), a)

    def test_pattern_explanation_does_not_repeat_an_anchor_heading(self):
        c = j.validate_payload(sample_payload()); a = sample_analysis(c)
        a["patterns"][0]["explanation"] = "Posible huella de una situación aterradora. Vale la pena explorar su relación con las respuestas actuales."
        self.assert_code("ai_invalid_response", j.validate_analysis, a, c)

    def test_captured_event_synonyms_remain_rejected_while_generic_references_are_valid(self):
        c = j.validate_payload(sample_payload())
        for section, field, claim in (
                (None, "summary", "Se reporta una experiencia de humillación, menosprecio o control, con malestar emocional."),
                ("profile", "description", "Tus respuestas señalan una experiencia marcada de trato humillante o controlador.")):
            a = sample_analysis(c)
            (a if section is None else a[section])[field] = claim
            self.assert_code("ai_invalid_response", j.validate_analysis, a, c)
        a = sample_analysis(c)
        a["summary"] = "Tus respuestas reconocen experiencias difíciles y malestar emocional. Conviene explorar su posible relación sin darla por demostrada."
        a["profile"]["description"] = "Has reconocido una experiencia que puedes revisar con acompañamiento. Tus respuestas también muestran malestar que merece entenderse en su contexto."
        self.assertEqual(j.validate_analysis(a, c), a)

    def test_hypotheses_are_allowed_but_diagnosis_causality_false_personal_details_are_rejected(self):
        c = j.validate_payload(sample_payload()); a = sample_analysis(c)
        a["professional"]["hypotheses"] = "Conviene explorar si hay reacciones postraumáticas o ansiedad, sin establecer un diagnóstico desde estos datos."
        self.assertEqual(j.validate_analysis(a, c), a)
        for claim in ("Tienes TEPT y eso explica todo.", "El malestar se debe a las experiencias reconocidas.", "Tu trauma es consecuencia de lo ocurrido.", "Hay recuerdos reprimidos que recuperar.", "Tu madre te hizo daño durante tu infancia.", "La probabilidad de diagnóstico es 90%."):
            a = sample_analysis(c); a["summary"] = claim
            self.assert_code("ai_invalid_response", j.validate_analysis, a, c)

    def test_output_exact_sections_lengths_and_caps_are_enforced(self):
        c = j.validate_payload(sample_payload())
        a = sample_analysis(c); a["professional"]["synthesis"] = "x" * 601
        self.assert_code("ai_invalid_response", j.validate_analysis, a, c)
        a = sample_analysis(c); a["summary"] = "<script>contenido</script>"
        self.assert_code("ai_invalid_response", j.validate_analysis, a, c)
        a = sample_analysis(c); a["profile"]["extra"] = "fabricado"
        self.assert_code("ai_invalid_response", j.validate_analysis, a, c)

    def test_combined_event_anchor_is_named_without_selecting_an_unreported_member(self):
        p = sample_payload(); p["context_answers"].update(E2=0, E7=1)
        c = j.validate_payload(p); a = sample_analysis(c)
        a["patterns"][0]["title"] = "Posible huella de pérdida, separación o abandono"
        self.assertEqual(j.validate_analysis(a, c), a)
        a["patterns"][0]["title"] = "Posible huella de abandono"
        self.assert_code("ai_invalid_response", j.validate_analysis, a, c)
        data = json.loads(j.provider_request(c)["input"][1]["content"][0]["text"])
        self.assertIn({"id": "context:E7", "label": "pérdida, separación o abandono"}, data["event_anchors"])
        p["context_answers"]["E2"] = 1
        c = j.validate_payload(p); a = sample_analysis(c)
        a["patterns"][0]["evidence_ids"] = ["context:E2", "PHQ9:PHQ9_1"]
        a["patterns"][0]["title"] = "Posible huella de pérdida, separación o abandono"
        self.assert_code("ai_invalid_response", j.validate_analysis, a, c)


class ServiceTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = Database(self.tmp.name, str(Path(self.tmp.name) / "key"))
        self.pool = exploration.ExplorationService(self.db)
        self.service = j.JourneyService(self.db, self.pool)
        self.env = patch.dict(os.environ, {"OPENAI_API_KEY": "SYNTHETIC_NOT_A_KEY", "TRAZA_AI_ENABLED": "1", "TRAZA_AI_IP_HOURLY_LIMIT": "5", "TRAZA_AI_DAILY_LIMIT": "40"})
        self.env.start()
        self.calls = []

    async def asyncTearDown(self):
        self.env.stop(); self.tmp.cleanup()

    def client(self, payload=None, status=200, envelope=None):
        analysis = sample_analysis(j.validate_payload(payload or sample_payload()))
        def handler(request):
            self.calls.append(json.loads(request.content))
            return httpx.Response(status, json=envelope if envelope is not None else provider_envelope(analysis))
        return httpx.AsyncClient(transport=httpx.MockTransport(handler))

    async def assert_async_code(self, code, awaitable):
        with self.assertRaises(j.JourneyError) as ctx:
            await awaitable
        self.assertEqual(ctx.exception.code, code)

    async def test_idempotency_one_provider_charge_and_request_conflict(self):
        p = sample_payload()
        async with self.client(p) as client:
            first = await self.service.report(p, "192.0.2.10", client=client)
            second = await self.service.report(p, "192.0.2.10", client=client)
            self.assertEqual(first, second); self.assertEqual(len(self.calls), 1)
            changed = deepcopy(p); changed["forms"]["PHQ9"]["answers"]["PHQ9_1"] = 1
            await self.assert_async_code("request_conflict", self.service.report(changed, "192.0.2.10", client=client))
        self.assertEqual(self.pool.active, 0); self.assertFalse(self.service.inflight)

    async def test_input_consent_safety_and_insufficient_data_precede_budget_and_provider(self):
        for mutate, code in ((lambda p: p["consent"].update(ai=False), "consent_required"),
                             (lambda p: p["context_answers"].update(S3=1), "safety_blocked"),
                             (lambda p: p.update(forms={}), "insufficient_data")):
            p = sample_payload(); mutate(p)
            await self.assert_async_code(code, self.service.report(p, "192.0.2.11"))
        with self.db.connection() as con:
            self.assertEqual(con.execute("SELECT count(*) FROM exploration_usage").fetchone()[0], 0)
        self.assertFalse(self.calls)

    async def test_shared_budget_shared_ip_key_and_concurrency_with_old_exploration(self):
        ip = "192.0.2.12"
        now = j.time.time(); hashed = self.pool.ip_hash(ip, str(int(now // 86400)))
        for _ in range(5): self.pool.consume_budget(hashed, now)
        p = sample_payload()
        await self.assert_async_code("rate_limited", self.service.report(p, ip))
        self.pool.active = 2
        await self.assert_async_code("ai_busy", self.service.report(p, "192.0.2.13"))
        self.pool.active = 0
        self.assertFalse(self.calls)

    async def test_daily_budget_is_shared_across_distinct_ips(self):
        now = j.time.time()
        for index in range(40):
            self.pool.consume_budget(self.pool.ip_hash("192.0.2." + str(index), str(int(now // 86400))), now)
        await self.assert_async_code("rate_limited", self.service.report(sample_payload(), "198.51.100.20"))
        self.assertFalse(self.calls)

    async def test_inflight_idempotency_conflict_and_shared_concurrency(self):
        entered, release = asyncio.Event(), asyncio.Event()
        p = sample_payload(); c = j.validate_payload(p)
        async def handler(request):
            self.calls.append(json.loads(request.content)); entered.set(); await release.wait()
            return httpx.Response(200, json=provider_envelope(sample_analysis(c)))
        async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as client:
            self.pool.active = 1  # One legacy exploration call is already running.
            task = asyncio.create_task(self.service.report(p, "192.0.2.23", client=client))
            await entered.wait()
            try:
                await self.assert_async_code("request_in_progress", self.service.report(p, "192.0.2.23", client=client))
                changed = deepcopy(p); changed["forms"]["PHQ9"]["answers"]["PHQ9_1"] = 1
                await self.assert_async_code("request_conflict", self.service.report(changed, "192.0.2.23", client=client))
                other = deepcopy(p); other["request_id"] = str(uuid.uuid4())
                await self.assert_async_code("ai_busy", self.service.report(other, "192.0.2.24", client=client))
            finally:
                release.set(); await task
                self.pool.active = 0
        self.assertEqual(len(self.calls), 1); self.assertFalse(self.service.inflight)

    async def test_provider_failure_or_invalid_output_never_emits_a_fallback(self):
        for status, envelope, code in ((503, None, "ai_provider_error"),
                    (200, {"status": "incomplete", "output": []}, "ai_invalid_response"),
                    (200, {"status": "completed", "output": [{"type": "message", "content": [{"type": "refusal", "refusal": "synthetic"}]}]}, "ai_provider_error")):
            p = sample_payload()
            async with self.client(p, status, envelope) as client:
                await self.assert_async_code(code, self.service.report(p, "192.0.2.14", client=client))
            self.assertFalse(self.service.cache); self.assertEqual(self.pool.active, 0)

    async def test_valid_signed_export_survives_new_service_and_browser_numeric_roundtrip(self):
        p = sample_payload("intermedio", True)
        async with self.client(p) as client:
            result = await self.service.report(p, "192.0.2.15", client=client)
        # Browser JSON.parse/stringify represents integral means as integers.
        def browser_roundtrip(item):
            if isinstance(item, dict): return {k: browser_roundtrip(v) for k, v in item.items()}
            if isinstance(item, list): return [browser_roundtrip(v) for v in item]
            if type(item) is float and item.is_integer(): return int(item)
            return item
        second = j.JourneyService(self.db, self.pool)
        original = second.verify_signed_report(browser_roundtrip(result))
        self.assertEqual(original["report_id"], result["report"]["report_id"])
        changed = deepcopy(result); changed["report"]["analysis"]["summary"] = "Texto clínico arbitrario modificado en el cliente."
        with self.assertRaises(j.JourneyError) as error: second.verify_signed_report(changed)
        self.assertEqual(error.exception.code, "invalid_signature")
        self.assertEqual(len(self.calls), 1)

    async def test_pdf_uses_verified_report_and_never_calls_provider(self):
        report = sample_report(); signed = {"report": report, "signature": self.service.sign_report(report)}
        rendered = []
        module = types.ModuleType("journey_pdf")
        module.render_report_pdf = lambda r: rendered.append(r) or b"%PDF-1.7\nSYNTHETIC"
        with patch.dict(sys.modules, {"journey_pdf": module}):
            data = await self.service.pdf(signed)
            self.assertTrue(data.startswith(b"%PDF")); self.assertEqual(len(rendered), 1)
            changed = deepcopy(signed); changed["report"]["analysis"]["summary"] = "Modificado por cliente sin autorización del servidor."
            await self.assert_async_code("invalid_signature", self.service.pdf(changed))
            self.assertEqual(len(rendered), 1)
        self.assertFalse(self.calls); self.assertEqual(self.service.pdf_active, 0)

    async def test_report_cache_expires_while_idle_and_is_not_persisted(self):
        p = sample_payload()
        with patch.object(j, "CACHE_TTL_SECONDS", 0.02):
            async with self.client(p) as client:
                await self.service.report(p, "192.0.2.16", client=client)
            self.assertEqual(len(self.service.cache), 1)
            await asyncio.sleep(0.04)
            self.assertFalse(self.service.cache)
        with self.db.connection() as con:
            self.assertEqual(con.execute("SELECT count(*) FROM records").fetchone()[0], 0)
            self.assertEqual(con.execute("SELECT count(*) FROM record_versions").fetchone()[0], 0)
            rows = con.execute("SELECT * FROM exploration_usage").fetchall()
            self.assertEqual(len(rows), 2)
            self.assertNotIn("192.0.2.16", repr([tuple(r) for r in rows]))

    async def test_invalid_signature_size_and_json_numbers_are_rejected_before_render(self):
        self.assertIsInstance(self.service._signing_key, bytes)
        report = sample_report(); signed = {"report": report, "signature": self.service.sign_report(report)}
        changed = deepcopy(signed); changed["signature"] = "v1." + "0" * 64
        with self.assertRaises(j.JourneyError): self.service.verify_signed_report(changed)
        changed = deepcopy(signed); changed["report"]["analysis"]["summary"] = "x" * 270000
        with self.assertRaises(j.JourneyError) as error: self.service.verify_signed_report(changed)
        self.assertEqual(error.exception.code, "payload_too_large")
        changed = deepcopy(signed); changed["report"]["scores"][0]["total"] = float("nan")
        with self.assertRaises(j.JourneyError): self.service.verify_signed_report(changed)


class JourneyAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        cls.tmp = tempfile.TemporaryDirectory()
        cls.db = Database(cls.tmp.name, str(Path(cls.tmp.name) / "key"))
        app = FastAPI()
        app.state.exploration = exploration.ExplorationService(cls.db)
        cls.service = j.attach_journey(app, cls.db)
        cls.client = TestClient(app)

    @classmethod
    def tearDownClass(cls):
        cls.client.close(); cls.tmp.cleanup()

    def test_schema_and_error_contract(self):
        schema = self.client.get("/api/journey/schema").json()
        self.assertEqual(schema["version"], "4.0")
        self.assertEqual(len(schema["routes"]), 3)
        response = self.client.post("/api/journey/report", json={})
        self.assertEqual(response.status_code, 422)
        self.assertEqual(response.json()["code"], "invalid_payload")
        self.assertIsInstance(response.json()["detail"], str)

    def test_signed_report_then_pdf_attachment_without_second_provider_call(self):
        async def fake_provider(clean, **kwargs):
            return sample_analysis(clean)
        module = types.ModuleType("journey_pdf")
        module.render_report_pdf = lambda report: b"%PDF-1.7\nSYNTHETIC"
        with patch.dict(os.environ, {"OPENAI_API_KEY": "SYNTHETIC_NOT_A_KEY", "TRAZA_AI_ENABLED": "1"}), patch.object(j, "provider_analyze", side_effect=fake_provider) as provider:
            response = self.client.post("/api/journey/report", json=sample_payload())
            self.assertEqual(response.status_code, 200, response.text)
            signed = response.json()
            self.assertEqual(set(signed), {"report", "signature"})
            with patch.dict(sys.modules, {"journey_pdf": module}):
                pdf = self.client.post("/api/journey/pdf", json=signed)
            self.assertEqual(pdf.status_code, 200, pdf.text)
            self.assertEqual(pdf.headers["content-type"], "application/pdf")
            self.assertIn("attachment", pdf.headers["content-disposition"])
            self.assertTrue(pdf.content.startswith(b"%PDF"))
            self.assertEqual(provider.call_count, 1)
            signed["report"]["analysis"]["summary"] = "Un texto arbitrario añadido por el cliente después de emitirse."
            rejected = self.client.post("/api/journey/pdf", json=signed)
            self.assertEqual(rejected.status_code, 403)
            self.assertEqual(rejected.json()["code"], "invalid_signature")

    def test_request_sizes_rejected_and_health_answers_never_persisted(self):
        response = self.client.post("/api/journey/report", content="x" * (j.MAX_REQUEST_BYTES + 1))
        self.assertEqual(response.status_code, 413)
        response = self.client.post("/api/journey/pdf", content="x" * (j.MAX_PDF_REQUEST_BYTES + 1))
        self.assertEqual(response.status_code, 413)
        with self.db.connection() as con:
            self.assertEqual(con.execute("SELECT count(*) FROM records").fetchone()[0], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
