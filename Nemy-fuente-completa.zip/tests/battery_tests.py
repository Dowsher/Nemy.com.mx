"""Boundary and reference-case checks for the public instrument battery."""
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
import uuid

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from battery import BatteryInputError, load_bank, score, visible, validate_answers


class BatteryScores(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.forms = {f['id']: f for f in load_bank()['instruments'] if f['status']=='available'}

    def answers(self, ident, maximum=False):
        form=self.forms[ident]
        result={}
        for q in form.get('items',[])+form.get('additional_items',[]):
            if not visible(q,result): continue
            choices=q.get('options',[])
            if q.get('type')=='number': value=q['max'] if maximum else q['min']
            elif q.get('type')=='text':
                if q.get('optional'): continue
                value='Descripción de ejemplo sin datos personales.'
            elif q.get('filter_options_by_answers'):
                choices=[o for o in choices if visible({'show_if':q['filter_options_by_answers'][str(o['value'])]},result)]
                if not choices: continue
                value=choices[-1 if maximum else 0]['value']
            else:
                value=choices[-1 if maximum else 0]['value']
                if q.get('multiple'): value=[value]
            result[q['id']]=value
        return result

    def test_every_available_form_has_exact_items_and_valid_endpoints(self):
        for ident,form in self.forms.items():
            with self.subTest(ident=ident):
                self.assertTrue(form['items'])
                self.assertEqual(len({q['id'] for q in form['items']}),len(form['items']))
                for maximum in (False,True):
                    result=score(form,self.answers(ident,maximum))
                    self.assertTrue(result['complete'],result)
                    self.assertEqual(result['missing_ids'],[])
                    self.assertTrue(result['summary'])

    def test_every_required_missing_answer_never_becomes_zero(self):
        for ident,form in self.forms.items():
            a=self.answers(ident,True)
            required=form.get('scoring',{}).get('required_ids',[q['id'] for q in form['items'] if q.get('required_for_score',True)])
            key=next((key for key in required if key in a),None)
            if not key: continue
            q=next(q for q in form['items'] if q['id']==key)
            for missing in (None,'skipped','unknown') if q.get('type')=='number' else (None,98,99):
                with self.subTest(ident=ident,missing=missing):
                    sample={**a,key:missing}
                    result=score(form,sample)
                    self.assertFalse(result['complete'])
                    self.assertIsNone(result['total'])

    def test_phq_reference_boundaries(self):
        f=self.forms['PHQ9']
        for target,expected in ((0,'Mínimo'),(4,'Mínimo'),(5,'Leve'),(9,'Leve'),(10,'Moderado'),(14,'Moderado'),(15,'Moderadamente alto'),(19,'Moderadamente alto'),(20,'Alto'),(27,'Alto')):
            a=self.answers('PHQ9');left=target
            for i in range(1,10): a[f'PHQ9_{i}']=min(3,left);left-=a[f'PHQ9_{i}']
            self.assertEqual(score(f,a)['band'],expected)
            self.assertEqual(score(f,a)['total'],target)

    def test_gad_reference_boundaries(self):
        f=self.forms['GAD7']
        for target,expected in ((0,'Mínimo'),(5,'Leve'),(10,'Moderado'),(15,'Alto'),(21,'Alto')):
            a=self.answers('GAD7');left=target
            for i in range(1,8): a[f'GAD7_{i}']=min(3,left);left-=a[f'GAD7_{i}']
            self.assertEqual(score(f,a)['band'],expected)

    def test_phq_difficulty_not_in_total_or_required(self):
        a=self.answers('PHQ9');a.pop('PHQ9_DIFFICULTY',None)
        self.assertEqual(score(self.forms['PHQ9'],a)['total'],0)
        a['PHQ9_DIFFICULTY']=3
        self.assertEqual(score(self.forms['PHQ9'],a)['total'],0)

    def test_phq_safety_signal_independent_of_complete_score(self):
        result=score(self.forms['PHQ9'],{'PHQ9_9':1})
        self.assertFalse(result['complete']);self.assertTrue(result['safety']['review']);self.assertFalse(result['safety']['urgent'])

    def test_pc_exposure_gate(self):
        f=self.forms['PCPTSD5']
        self.assertEqual(score(f,{'PCPTSD5_EXPOSURE':0})['total'],0)
        for missing in (None,98,99): self.assertIsNone(score(f,{'PCPTSD5_EXPOSURE':missing})['total'])
        a={'PCPTSD5_EXPOSURE':1,**{f'PCPTSD5_{i}':1 for i in range(1,6)}}
        self.assertEqual(score(f,a)['total'],5)
        a['PCPTSD5_EXPOSURE']=0
        self.assertEqual(score(f,a)['total'],0)
        self.assertEqual(len(score(f,a)['answers']),1)

    def test_itq_cluster_algorithm_includes_impairment_at_two(self):
        f=self.forms['ITQ'];a=self.answers('ITQ')
        for k in ('P1','P3','P5','P7'): a['ITQ_'+k]=2
        r=score(f,a);self.assertTrue(r['algorithm']['ptsd_screen']);self.assertFalse(r['algorithm']['dso_screen'])
        self.assertEqual(r['algorithm']['category'],'PTSD_screen')
        for k in ('C1','C3','C5','C7'):a['ITQ_'+k]=2
        r=score(f,a);self.assertEqual(r['algorithm']['category'],'CPTSD_screen');self.assertIsNone(r['total'])
        a['ITQ_P7']=1
        r=score(f,a);self.assertFalse(r['algorithm']['ptsd_screen']);self.assertEqual(r['algorithm']['category'],'criteria_not_met')

    def test_itq_impairment_not_in_symptom_totals(self):
        a=self.answers('ITQ')
        for prefix in ('P','C'):
            for i in (7,8,9):a[f'ITQ_{prefix}{i}']=4
        r=score(self.forms['ITQ'],a)
        self.assertEqual([s['value'] for s in r['subscales']],[0,0])

    def test_no_coercion_bool_float_text(self):
        f=self.forms['PHQ9']
        for invalid in (True,False,1.0,'1',-1,4,[],{},float('nan')):
            with self.subTest(value=invalid):
                with self.assertRaises(BatteryInputError):score(f,{'PHQ9_1':invalid})

    def test_unknown_fields_rejected(self):
        with self.assertRaises(BatteryInputError):score(self.forms['PHQ9'],{'name':'PERSON'})

    def test_number_98_99_are_real_ages_and_missing_strings_are_not(self):
        a=self.answers('LTC');a['LT1']=98;a['LT2']=99
        r=score(self.forms['LTC'],a);self.assertTrue(r['complete'])
        self.assertEqual(r['answers'][0]['label'],'98')
        for missing in ('skipped','unknown',None):
            r=score(self.forms['LTC'],{**a,'LT1':missing});self.assertFalse(r['complete'])

    def test_conditional_answers_pruned_and_principal_must_be_reported(self):
        a=self.answers('CX17',True)
        a['CX1']='no'
        cleaned=validate_answers(self.forms['CX17'],a)
        self.assertNotIn('CX1_ongoing',cleaned);self.assertNotIn('CX1_timing',cleaned)
        a=self.answers('MFC12');a['MFC1']=2;a['MFC-R']='MFC2'
        with self.assertRaises(BatteryInputError):score(self.forms['MFC12'],a)

    def test_originals_do_not_invent_a_trauma_score(self):
        for ident,f in self.forms.items():
            if f['kind']=='original':self.assertIsNone(score(f,self.answers(ident,True))['total'])

    def test_asrs_shaded_thresholds(self):
        if 'ASRS6' not in self.forms:self.skipTest('ASRS not loaded')
        f=self.forms['ASRS6'];ids=f['scoring']['required_ids']
        a={k:v for k,v in zip(ids,[2,2,2,2,2,2])}
        self.assertEqual(score(f,a)['total'],3)
        a[ids[3]]=3;self.assertEqual(score(f,a)['total'],4)
        self.assertTrue(all('shaded'in o for q in f['items'] for o in q['options']))

    def test_lec_multiple_exposures_not_a_total(self):
        if 'LEC5' not in self.forms:self.skipTest('LEC not loaded')
        f=self.forms['LEC5'];a=self.answers('LEC5')
        q=f['items'][0];a[q['id']]=[q['options'][0]['value'],q['options'][1]['value']]
        r=score(f,a);self.assertIsNone(r['total']);self.assertTrue(r['complete'])
        a[q['id']]=[q['options'][0]['value']]*2
        with self.assertRaises(BatteryInputError):score(f,a)

    def lec_extended_answers(self):
        # Two endorsed categories; the extended part refers to one worst event.
        a={f'LEC5_{i}':[6] for i in range(1,18)}
        a.update({'LEC5_1':[1,2],'LEC5_17':[1],
                  'LEC5_P2_A':'Un acontecimiento de ejemplo.',
                  'LEC5_P2_1':'El mismo acontecimiento de ejemplo.',
                  'LEC5_P2_2':'Hace aproximadamente dos meses.',
                  'LEC5_P2_3':[1,4,5],'LEC5_P2_3_OTHER':'Una forma de exposición de ejemplo.',
                  'LEC5_P2_4':[1,2],'LEC5_P2_5':[1,2],'LEC5_P2_6':1,
                  'LEC5_P2_7':1,'LEC5_P2_8':2,'LEC5_P2_8_TOTAL':'Unas tres veces.'})
        return a

    def test_lec_complete_extended_form_preserves_text_without_counting_it(self):
        f=self.forms['LEC5'];a=self.lec_extended_answers();r=score(f,a)
        self.assertTrue(r['complete']);self.assertTrue(r['inventory']['complete'])
        self.assertEqual(r['required'],23);self.assertEqual(r['inventory']['required'],17)
        self.assertEqual(r['inventory']['counts'],{1:2,2:1,3:0,4:0,5:0,6:15})
        self.assertIsNone(r['total']);self.assertIsNone(r['band'])
        self.assertNotIn('algorithm',r);self.assertFalse(f['scoring']['criterion_a_automated'])
        result_answers={q['id']:q for q in r['answers']}
        self.assertEqual(result_answers['LEC5_P2_2']['value'],a['LEC5_P2_2'])
        self.assertEqual(result_answers['LEC5_P2_8_TOTAL']['label'],a['LEC5_P2_8_TOTAL'])
        self.assertEqual(len(r['answers']),28)

    def test_lec_no_exposure_ends_after_inventory_and_removes_stale_complements(self):
        f=self.forms['LEC5'];a=self.lec_extended_answers()
        a.update({f'LEC5_{i}':[6] for i in range(1,18)})
        cleaned=validate_answers(f,a);r=score(f,a)
        self.assertEqual(set(cleaned),{f'LEC5_{i}' for i in range(1,18)})
        self.assertEqual(len(r['answers']),17);self.assertTrue(r['complete'])
        self.assertEqual(r['required'],17);self.assertEqual(r['inventory']['counts'][6],17)
        self.assertEqual(sum(r['inventory']['counts'].values()),17)
        self.assertIsNone(r['total'])

    def test_lec_missing_complement_retains_complete_inventory_and_no_total(self):
        f=self.forms['LEC5'];a=self.lec_extended_answers();a.pop('LEC5_P2_6')
        r=score(f,a)
        self.assertFalse(r['complete']);self.assertTrue(r['inventory']['complete'])
        self.assertEqual(r['missing_ids'],['LEC5_P2_6'])
        self.assertEqual(r['inventory']['counts'][1],2);self.assertIsNone(r['total'])

    def test_lec_optional_text_never_makes_extended_record_incomplete(self):
        f=self.forms['LEC5'];a=self.lec_extended_answers()
        texts=[q['id'] for q in f['additional_items'] if q.get('type')=='text']
        self.assertEqual(len(texts),5)
        for key in texts:
            self.assertTrue(next(q for q in f['additional_items'] if q['id']==key)['optional'])
            a.pop(key,None)
        r=score(f,a);self.assertTrue(r['complete']);self.assertEqual(r['required'],23)
        for marker in (None,98,99,'   '):
            r=score(f,{**a,'LEC5_P2_1':marker})
            self.assertTrue(r['complete']);self.assertIsNone(r['total'])

    def test_lec_branch_changes_prune_only_inapplicable_fields(self):
        f=self.forms['LEC5'];a=self.lec_extended_answers()
        a['LEC5_17']=[6];a['LEC5_P2_3']=[1];a['LEC5_P2_8']=1
        cleaned=validate_answers(f,a)
        for key in ('LEC5_P2_A','LEC5_P2_3_OTHER','LEC5_P2_8_TOTAL'):
            self.assertNotIn(key,cleaned)
        self.assertEqual(cleaned['LEC5_P2_1'],a['LEC5_P2_1'])
        self.assertTrue(score(f,a)['complete'])

    def test_lec_uncertain_or_missing_exposure_is_not_treated_as_a_negative(self):
        f=self.forms['LEC5'];a={f'LEC5_{i}':[6] for i in range(1,18)}
        for marker in (None,98,99):
            r=score(f,{**a,'LEC5_1':marker})
            self.assertFalse(r['complete']);self.assertFalse(r['inventory']['complete'])
            self.assertEqual(r['inventory']['counts'][6],16)
            self.assertEqual(r['missing_ids'],['LEC5_1'])
            self.assertEqual(len(r['answers']),17)
        r=score(f,{**a,'LEC5_1':[5]})
        self.assertTrue(r['complete']);self.assertEqual(r['inventory']['counts'][5],1)
        self.assertEqual(r['required'],17);self.assertIsNone(r['total'])

    def test_lec_text_is_typed_bounded_and_preserved_without_score_coercion(self):
        f=self.forms['LEC5'];a=self.lec_extended_answers();key='LEC5_P2_1'
        for invalid in (True,False,0,1.0,{},[],['texto'],'x'*501,'texto\x00','texto\x1f','texto\x7f'):
            with self.subTest(value=repr(invalid)):
                with self.assertRaises(BatteryInputError):score(f,{**a,key:invalid})
        r=score(f,{**a,key:'á'*500})
        self.assertTrue(r['complete']);self.assertIsNone(r['total'])
        self.assertEqual(next(q for q in r['answers'] if q['id']==key)['value'],'á'*500)
        cleaned=validate_answers(f,{**a,key:'  texto\ncon\ttabulador  '})
        self.assertEqual(cleaned[key],'texto\ncon\ttabulador')

    def test_lec_version_and_conditions_match_extended_spanish_source(self):
        f=self.forms['LEC5'];r=score(f,self.lec_extended_answers())
        self.assertEqual(f['version_date'],'2018-04-12')
        self.assertEqual(len(f['items']),17);self.assertEqual(len(f['additional_items']),11)
        self.assertEqual(f['scoring']['inventory_ids'],[f'LEC5_{i}' for i in range(1,18)])
        self.assertEqual(f['source']['sha256'],'84c3323807763e8853674b7f852baab5063192c212d166d9d27f8f527e4982e7')
        self.assertIn('no ha sido validada',r['translation_warning'])
        self.assertIn('profesionales de salud cualificados',r['intended_use'])
        self.assertTrue(r['registration']['incorporate_in_web'])
        self.assertTrue(r['registration']['reproduce_questions'])

    def test_socrates_three_sums_no_fake_stage(self):
        for ident in ('SOCRATES8A','SOCRATES'):
            if ident not in self.forms:continue
            f=self.forms[ident]
            low=score(f,self.answers(ident));high=score(f,self.answers(ident,True))
            self.assertEqual([s['value']for s in low['subscales']],[7,4,8])
            self.assertEqual([s['value']for s in high['subscales']],[35,20,40])
            self.assertIsNone(low['total']);self.assertIsNone(low['band'])

    def test_mspss_four_point_form_and_three_dimensions(self):
        if 'MSPSS' not in self.forms:self.skipTest('MSPSS not loaded')
        f=self.forms['MSPSS'];a=self.answers('MSPSS')
        a['MSPSS_1']=4
        r=score(f,a)
        self.assertEqual(r['total'],1.25)
        self.assertEqual([s['value']for s in r['subscales']],[1.75,1,1])
        self.assertEqual(r['range'],[1,4]);self.assertIsNone(r['band'])

    def test_ccq_reverses_four_and_seven_in_four_point_version(self):
        if 'CCQBRIEF' not in self.forms:self.skipTest('CCQ not loaded')
        f=self.forms['CCQBRIEF'];a=self.answers('CCQBRIEF')
        self.assertEqual(score(f,a)['total'],1.6)
        a['CCQBRIEF_4']=4;a['CCQBRIEF_7']=4
        self.assertEqual(score(f,a)['total'],1)
        self.assertEqual(score(f,a)['range'],[1,4])

    def test_ecr12_inverse_item_and_separate_dimensions(self):
        if 'ECR12CL' not in self.forms:self.skipTest('ECR12 not loaded')
        f=self.forms['ECR12CL'];a=self.answers('ECR12CL')
        self.assertEqual([s['value']for s in score(f,a)['subscales']],[1,2])
        a['ECR12CL_11']=7
        self.assertEqual([s['value']for s in score(f,a)['subscales']],[1,1])
        self.assertIsNone(score(f,a)['total'])

    def test_des_t_average_has_no_taxon_or_cutoff(self):
        if 'DEST' not in self.forms:self.skipTest('DES-T not loaded')
        f=self.forms['DEST'];a=self.answers('DEST')
        a[f['items'][0]['id']]=80
        r=score(f,a)
        self.assertEqual(r['total'],10);self.assertEqual(r['range'],[0,100]);self.assertIsNone(r['band'])

    def test_brs_reverses_two_four_six_and_keeps_separate_license(self):
        if 'BRSCL' not in self.forms:self.skipTest('BRS not loaded')
        f=self.forms['BRSCL'];a=self.answers('BRSCL')
        self.assertEqual(score(f,a)['total'],3)
        for i in (2,4,6):a[f'BRSCL_{i}']=5
        r=score(f,a)
        self.assertEqual(r['total'],1);self.assertEqual(r['range'],[1,5])
        self.assertEqual(r['content_license'],'CC-BY-SA-4.0')
        self.assertIn('creativecommons.org',r['attribution'])

    def test_registered_phq_and_gad_use_exact_spanish_mexico_versions(self):
        p=self.forms['PHQ9'];g=self.forms['GAD7']
        self.assertIsNone(p['edition_number']);self.assertIsNone(g['edition_number'])
        for f in (p,g):
            self.assertEqual(f['language'],'es-MX')
            self.assertIn('www.phqscreeners.com/',f['source']['url'])
            self.assertIn('Spanish%20for%20Mexico.pdf',f['source']['url'])
            self.assertEqual(f['registration']['source_url'],f['source']['url'])
        self.assertEqual(p['items'][0]['options'][0]['label'],'Para nada')
        self.assertEqual(g['items'][0]['options'][0]['label'],'Nunca')
        self.assertEqual(g['items'][0]['text'],'Sentirse nervioso/a, intranquilo/a o con los nervios de punta')
        self.assertEqual(g['items'][-1]['text'],'Sentir miedo como si algo terrible pudiera pasar')
        self.assertEqual(len(g['items']),7)
        self.assertEqual(score(g,self.answers('GAD7',True))['total'],21)

    def test_registered_permissions_and_pc_limits_survive_result_export(self):
        for ident in ('PHQ9','GAD7','PCPTSD5','ITQ','LEC5','ASRS6','MSPSS','SOCRATES','SOCRATES8A'):
            f=self.forms[ident];r=score(f,self.answers(ident))
            self.assertTrue(r['registration']['reproduce_questions'])
            self.assertTrue(r['registration']['incorporate_in_web'])
            self.assertEqual(r['registration']['source_url'],f['source']['url'])
        p=self.forms['PCPTSD5']
        self.assertIn('sin validación publicada',p['intro_notice'])
        r=score(p,{'PCPTSD5_EXPOSURE':0})
        self.assertIn('profesionales de salud cualificados',r['intended_use'])
        self.assertIn('no cuenta con validación publicada',r['translation_warning'])

    def test_registered_variants_preserve_scope_and_translation_identification(self):
        self.assertEqual(self.forms['ITQ']['registration']['version_status'],'final_adult')
        self.assertEqual(self.forms['ITQ']['registration']['symptom_item_count'],12)
        self.assertEqual(self.forms['ITQ']['registration']['functional_impairment_item_count'],6)
        a=self.forms['ASRS6']['registration']
        self.assertTrue(a['electronic_reproduction_explicit']);self.assertFalse(a['covers_18_item_form'])
        self.assertEqual(a['question_count'],6)
        m=self.forms['MSPSS']['registration']
        self.assertTrue(m['translation_authors']);self.assertEqual(m['translation_source_url'],self.forms['MSPSS']['source']['url'])
        self.assertEqual(self.forms['SOCRATES']['registration']['variant'],'8D')
        self.assertEqual(self.forms['SOCRATES8A']['registration']['variant'],'8A')
        self.assertEqual(self.forms['SOCRATES']['registration']['question_count'],19)


class BatteryAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary=tempfile.TemporaryDirectory()
        os.environ['TRAZA_DATA_DIR']=cls.temporary.name
        os.environ['TRAZA_KEY_FILE']=str(Path(cls.temporary.name)/'key')
        from server import create_app
        from fastapi.testclient import TestClient
        cls.app=create_app(cls.temporary.name,str(Path(cls.temporary.name)/'key'))
        cls.client=TestClient(cls.app)

    @classmethod
    def tearDownClass(cls):
        cls.client.close();cls.temporary.cleanup()

    def test_catalog_all_registered_instruments_and_no_false_available(self):
        catalog=self.client.get('/api/battery/catalog').json()
        registered=json.loads((Path(__file__).resolve().parents[1]/'instruments.json').read_text(encoding='utf-8'))
        self.assertTrue({f['id']for f in registered['instruments']} <= {f['id']for f in catalog['instruments']})
        for form in catalog['instruments']:
            if form['status']=='available':self.assertGreater(form['item_count'],0)
            else:self.assertEqual(self.client.get('/api/battery/'+form['id']).status_code,409)

    def test_origin_and_input_enforced(self):
        data={'answers':{f'GAD7_{i}':0 for i in range(1,8)},'form_version':self.client.get('/api/battery/GAD7').json()['version']}
        self.assertEqual(self.client.post('/api/battery/GAD7/score',json=data).status_code,403)
        self.assertEqual(self.client.post('/api/battery/GAD7/score',json=data,headers={'Origin':'https://wrong.test'}).status_code,403)
        self.assertEqual(self.client.post('/api/battery/GAD7/score',json=data,headers={'Origin':'http://127.0.0.1:3230'}).status_code,401)
        headers=self.saved_headers('GAD7',data['answers'])
        r=self.client.post('/api/battery/GAD7/score',json=data,headers=headers)
        self.assertEqual(r.status_code,200);self.assertEqual(r.json()['total'],0)
        self.assertIn('no-store',r.headers['cache-control'])
        with self.app.state.db.connection() as con:
            self.assertEqual(con.execute('SELECT count(*) FROM records').fetchone()[0],0)
            self.assertEqual(con.execute('SELECT count(*) FROM record_versions').fetchone()[0],0)

    def test_old_or_unspecified_form_version_cannot_be_relabelled_as_mexico(self):
        headers={'Origin':'http://127.0.0.1:3230'}
        answers={f'GAD7_{i}':0 for i in range(1,8)}
        for extra in ({},{'form_version':'Español para Estados Unidos · UCSF; edición no indicada'}):
            r=self.client.post('/api/battery/GAD7/score',json={'answers':answers,**extra},headers=headers)
            self.assertEqual(r.status_code,409)

    def test_ccq_registered_translation_version_is_required_and_survives_scoring(self):
        headers={'Origin':'http://127.0.0.1:3230'}
        form=self.client.get('/api/battery/CCQBRIEF').json()
        answers={q['id']:1 for q in form['items']}
        for version in (None,'1.0','CCQ-N-10 español 2009'):
            data={'answers':answers}
            if version is not None:data['form_version']=version
            self.assertEqual(self.client.post('/api/battery/CCQBRIEF/score',json=data,headers=headers).status_code,409)
        headers=self.saved_headers('CCQBRIEF',answers)
        response=self.client.post('/api/battery/CCQBRIEF/score',json={'answers':answers,'form_version':form['version']},headers=headers)
        self.assertEqual(response.status_code,200)
        result=response.json()
        self.assertEqual(result['version'],form['version'])
        self.assertEqual(result['total'],1.6)
        self.assertTrue(result['registration']['incorporate_in_web'])
        self.assertEqual(result['content_license'],'CC-BY-4.0')

    def saved_headers(self, form_id, answers):
        headers={'Origin':'http://127.0.0.1:3230'}
        visit=self.client.post('/api/activity/visits',json={'event_id':str(uuid.uuid4()),'device':{'kind':'desktop','os':'Windows','browser':'Chrome'},'viewport':{'width':1400,'height':900},'entry':'battery'},headers=headers)
        self.assertEqual(visit.status_code,200,visit.text)
        headers['X-Traza-Visit']=visit.json()['visit_token']
        session=self.client.post('/api/activity/sessions',json={'event_id':str(uuid.uuid4()),'kind':'battery','route_id':None,'form_id':form_id,'consent':{'adult':True,'storage':True,'version':'5.0'}},headers=headers)
        self.assertEqual(session.status_code,200,session.text)
        sid=session.json()['session_id'];headers['X-Traza-Activity-Session']=sid
        for sequence,(qid,value) in enumerate(answers.items(),1):
            event=self.client.post('/api/activity/sessions/'+sid+'/events',json={'event_id':str(uuid.uuid4()),'sequence':sequence,'type':'answer','form_id':form_id,'question_id':qid,'value':value},headers=headers)
            self.assertEqual(event.status_code,200,event.text)
        return headers


if __name__=='__main__':unittest.main(verbosity=2)
